# Security Specification & Payload-First TDD

## 1. Data Invariants
1. **Super Admin Sovereignty**: Only the verified owner account (`aboodialahmad10@gmail.com` with `email_verified == true`) can create, update, or delete documents in `/admins/{adminEmail}` or list `/admins` and `/users`.
2. **Zero Self-Promotion**: Regular authenticated users cannot create or modify their own `/admins/{email}` record, nor add `role` / `isAdmin` shadow fields to `/users/{userId}`.
3. **Granular Admin Delegation**: Delegated admins in `/admins/{email}` can ONLY modify the subset of `/site_config/main` fields authorized by their boolean flags (`canEditBranding` vs `canEditLinks`), enforced via `affectedKeys().hasOnly(...)`.
4. **PII Isolation**: `/users/{userId}` and `/admins/{adminEmail}` are never listable by regular users; regular users may only `get` their own `/users/{uid}` or check their own `/admins/{theirLowerEmail}` existence.
5. **Temporal & Identity Integrity**: All `createdAt` / `updatedAt` / `lastLoginAt` fields must equal `request.time`; `updatedBy` / `addedBy` / `uid` must match `request.auth.uid`.

## 2. The "Dirty Dozen" Adversarial Payloads (Must All Return PERMISSION_DENIED)
1. **Unverified Email Admin Spoof**: `email = 'aboodialahmad10@gmail.com'`, `email_verified = false` attempts write to `/site_config/main`.
2. **Self-Admin Escalation**: Regular user (`user@example.com`) attempts `create` on `/admins/user@example.com` with `{ canEditBranding: true, canEditLinks: true }`.
3. **Ghost Field Shadow Update on User**: Regular user sends `{ uid, email, displayName, photoURL, createdAt, lastLoginAt, isAdmin: true }` to `/users/{uid}`.
4. **Cross-User Profile Hijack**: Regular user A (`uidA`) attempts `get` or `update` on `/users/uidB`.
5. **Admin List Scraping**: Regular user calls `list` on `/admins` or `/users` to harvest emails.
6. **Delegated Admin Scope Bypass**: Admin with `canEditLinks: true, canEditBranding: false` attempts to update `siteName` or `logoUrl` on `/site_config/main`.
7. **Branding Admin Link Hijack**: Admin with `canEditBranding: true, canEditLinks: false` attempts to modify `buttons` array on `/site_config/main`.
8. **1MB Resource Poisoning**: Admin attempts to write `siteName` with 5000 chars or `configId` with 200 chars (`site_config/xxxx...`).
9. **Client Timestamp Forgery**: Authenticated user sends `createdAt: new Date(2020, 0, 1)` instead of `serverTimestamp()`.
10. **Immutable `createdAt` Mutation**: User attempts to modify `createdAt` during `/users/{uid}` update.
11. **Arbitrary Config Document Creation**: Admin attempts to create `/site_config/backdoor` instead of `/site_config/main`.
12. **Blanket `site_config` Listing**: Unauthenticated or regular user attempts `list` on `/site_config`.
