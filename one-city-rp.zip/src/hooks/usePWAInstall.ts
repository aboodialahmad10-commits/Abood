import { useCallback, useEffect, useState } from 'react';

interface BeforeInstallPromptEvent extends Event {
  readonly platforms: string[];
  readonly userChoice: Promise<{
    outcome: 'accepted' | 'dismissed';
    platform: string;
  }>;
  prompt(): Promise<void>;
}

const INSTALLED_STORAGE_KEY = 'onecity_pwa_installed';
const DISMISSED_SESSION_KEY = 'onecity_pwa_prompt_dismissed_session';

// Capture beforeinstallprompt globally in case it fires before React mounts
let earlyDeferredPrompt: BeforeInstallPromptEvent | null = null;
if (typeof window !== 'undefined') {
  window.addEventListener('beforeinstallprompt', (e: Event) => {
    e.preventDefault();
    earlyDeferredPrompt = e as BeforeInstallPromptEvent;
  });
}

function detectStandaloneMode(): boolean {
  if (typeof window === 'undefined') return false;
  const nav = window.navigator as Navigator & { standalone?: boolean };
  return (
    window.matchMedia('(display-mode: standalone)').matches ||
    window.matchMedia('(display-mode: window-controls-overlay)').matches ||
    nav.standalone === true
  );
}

function detectIOSDevice(): boolean {
  if (typeof window === 'undefined') return false;
  const ua = window.navigator.userAgent;
  const isAppleMobile = /iPhone|iPad|iPod/i.test(ua);
  const isIPadOS =
    window.navigator.platform === 'MacIntel' && (window.navigator.maxTouchPoints || 0) > 1;
  return isAppleMobile || isIPadOS;
}

function detectAndroidDevice(): boolean {
  if (typeof window === 'undefined') return false;
  return /Android/i.test(window.navigator.userAgent);
}

export function usePWAInstall() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(
    () => earlyDeferredPrompt,
  );
  const [isStandalone, setIsStandalone] = useState<boolean>(() => detectStandaloneMode());
  const [isInstalled, setIsInstalled] = useState<boolean>(() => {
    if (detectStandaloneMode()) return true;
    try {
      return window.localStorage.getItem(INSTALLED_STORAGE_KEY) === 'true';
    } catch {
      return false;
    }
  });
  const [isOnline, setIsOnline] = useState<boolean>(() =>
    typeof navigator !== 'undefined' ? navigator.onLine : true,
  );
  const [modalOpen, setModalOpen] = useState(false);
  const [justInstalled, setJustInstalled] = useState(false);

  const isIOS = detectIOSDevice();
  const isAndroid = detectAndroidDevice();
  const isDesktop = !isIOS && !isAndroid;
  const isInIframe = typeof window !== 'undefined' && window.self !== window.top;

  const markInstalled = useCallback((showOpenStep = false) => {
    setIsInstalled(true);
    setDeferredPrompt(null);
    earlyDeferredPrompt = null;
    try {
      window.localStorage.setItem(INSTALLED_STORAGE_KEY, 'true');
    } catch {
      // Ignore storage error
    }
    if (showOpenStep) {
      setJustInstalled(true);
      setModalOpen(true);
    } else {
      setJustInstalled(false);
      setModalOpen(false);
    }
  }, []);

  useEffect(() => {
    const standalone = detectStandaloneMode();
    setIsStandalone(standalone);
    if (standalone) {
      setIsInstalled(true);
      try {
        window.localStorage.setItem(INSTALLED_STORAGE_KEY, 'true');
      } catch {
        // Ignore storage error
      }
    }

    // Check installed related web apps where supported (Chrome / Edge / Android)
    const navWithRelated = navigator as Navigator & {
      getInstalledRelatedApps?: () => Promise<Array<{ platform?: string; url?: string }>>;
    };
    if (typeof navWithRelated.getInstalledRelatedApps === 'function') {
      navWithRelated
        .getInstalledRelatedApps()
        .then((apps) => {
          if (Array.isArray(apps) && apps.length > 0) {
            setIsInstalled(true);
            try {
              window.localStorage.setItem(INSTALLED_STORAGE_KEY, 'true');
            } catch {
              // Ignore
            }
          }
        })
        .catch(() => {
          // Ignore unsupported errors
        });
    }

    const mediaQuery = window.matchMedia('(display-mode: standalone)');
    const handleDisplayChange = (ev: MediaQueryListEvent) => {
      if (ev.matches) {
        setIsStandalone(true);
        markInstalled(false);
      }
    };

    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      const promptEvent = e as BeforeInstallPromptEvent;
      earlyDeferredPrompt = promptEvent;
      setDeferredPrompt(promptEvent);
    };

    const handleAppInstalled = () => {
      markInstalled(true);
    };

    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    mediaQuery.addEventListener('change', handleDisplayChange);

    // Auto-show welcome install prompt ONLY if never installed/downloaded & not dismissed this session
    let autoOpenTimer: number | undefined;
    if (!standalone) {
      let alreadyInstalledFlag = false;
      let dismissedThisSession = false;
      try {
        alreadyInstalledFlag = window.localStorage.getItem(INSTALLED_STORAGE_KEY) === 'true';
        dismissedThisSession =
          window.sessionStorage.getItem(DISMISSED_SESSION_KEY) === '1';
      } catch {
        // Ignore storage errors
      }
      if (!alreadyInstalledFlag && !dismissedThisSession) {
        autoOpenTimer = window.setTimeout(() => {
          setJustInstalled(false);
          setModalOpen(true);
        }, 350);
      }
    }

    return () => {
      if (autoOpenTimer) window.clearTimeout(autoOpenTimer);
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      mediaQuery.removeEventListener('change', handleDisplayChange);
    };
  }, [markInstalled]);

  const dismissModal = useCallback(() => {
    setModalOpen(false);
    setJustInstalled(false);
    try {
      window.sessionStorage.setItem(DISMISSED_SESSION_KEY, '1');
    } catch {
      // Ignore storage error
    }
  }, []);

  const openModal = useCallback(() => {
    if (!isInstalled) {
      setJustInstalled(false);
      setModalOpen(true);
    }
  }, [isInstalled]);

  const triggerNativeInstall = useCallback(async (): Promise<
    'accepted' | 'dismissed' | 'unavailable'
  > => {
    const promptToUse = deferredPrompt || earlyDeferredPrompt;
    if (!promptToUse) {
      return 'unavailable';
    }

    try {
      await promptToUse.prompt();
      const { outcome } = await promptToUse.userChoice;
      if (outcome === 'accepted') {
        markInstalled(true);
        return 'accepted';
      }
      setDeferredPrompt(null);
      earlyDeferredPrompt = null;
      return 'dismissed';
    } catch {
      return 'unavailable';
    }
  }, [deferredPrompt, markInstalled]);

  return {
    isStandalone,
    isInstalled,
    justInstalled,
    isOnline,
    isIOS,
    isAndroid,
    isDesktop,
    isInIframe,
    canPromptNatively: Boolean(deferredPrompt || earlyDeferredPrompt),
    modalOpen,
    openModal,
    dismissModal,
    markInstalled,
    triggerNativeInstall,
  };
}
