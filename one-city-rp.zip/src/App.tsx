import { useEffect, useState } from 'react';
import {
  getRedirectResult,
  onAuthStateChanged,
  sendEmailVerification,
  signOut,
  User,
} from 'firebase/auth';
import { doc, getDoc, onSnapshot, serverTimestamp, setDoc, updateDoc } from 'firebase/firestore';
import {
  ArrowLeft,
  ArrowRight,
  BookOpen,
  Bot,
  Download,
  Gamepad2,
  Globe,
  Home,
  LogIn,
  LogOut,
  MailCheck,
  Newspaper,
  RefreshCw,
  Settings,
  Shield,
} from 'lucide-react';
import { AdminModal } from './components/AdminModal';
import { AiChatPanel } from './components/AiChatPanel';
import { FactionsSection } from './components/FactionsSection';
import { GameGuideSection } from './components/GameGuideSection';
import { LoginModal } from './components/LoginModal';
import { NewsSection } from './components/NewsSection';
import { OfflineIndicator } from './components/OfflineIndicator';
import { PWAInstallModal } from './components/PWAInstallModal';
import { StarfieldCanvas } from './components/StarfieldCanvas';
import { usePWAInstall } from './hooks/usePWAInstall';
import {
  generateFullSingleHtml,
  generateStandaloneHtml,
  preloadStandaloneTemplates,
  resolveLogoAsDataUri,
  StandaloneTemplates,
} from './utils/exportHtml';
import {
  auth,
  db,
  handleFirestoreError,
  OperationType,
  SUPER_ADMIN_EMAIL,
} from './firebase';
import { Language, TRANSLATIONS } from './i18n';
import {
  AdminMember,
  AdminPermissions,
  BotInfo,
  ButtonItem,
  DEFAULT_BOT_INFO,
  DEFAULT_LOGO_PATH,
  DEFAULT_SITE_CONFIG,
  LEGACY_LOGO_PATH,
  SiteConfig,
  UserProfile,
} from './types';

type ActiveView = 'home' | 'news' | 'factions' | 'ai';

const NO_ADMIN_PERMS: AdminPermissions = {
  isSuperAdmin: false,
  isAdmin: false,
  canEditBranding: false,
  canEditLinks: false,
  canEditBot: false,
  canManageAdmins: false,
};

const DEFAULT_BUTTON_EN_MAP: Record<string, { ar: string[]; en: string }> = {
  discord: { ar: ['سيرفر ديسكورد', 'دخول إلى ديسكورد'], en: 'Join Discord' },
  tiktok: { ar: ['حساب تيك توك', 'موقع التيك توك'], en: 'TikTok Page' },
  game: { ar: ['One City RP', 'دخول إلى اللعبة'], en: 'Enter the Game' },
};

function sanitizeExternalUrl(raw: string): string {
  const trimmed = raw.trim();
  if (!trimmed) return '';
  if (/^https?:\/\//i.test(trimmed)) return trimmed;
  return `https://${trimmed}`;
}

export default function App() {
  const [lang, setLang] = useState<Language>(() => {
    try {
      return window.localStorage.getItem('onecity_lang') === 'en' ? 'en' : 'ar';
    } catch {
      return 'ar';
    }
  });

  const [siteConfig, setSiteConfig] = useState<SiteConfig>(DEFAULT_SITE_CONFIG);
  const [configExistsInDb, setConfigExistsInDb] = useState(false);

  const [botInfo, setBotInfo] = useState<BotInfo>(DEFAULT_BOT_INFO);
  const [botInfoExistsInDb, setBotInfoExistsInDb] = useState(false);

  const [user, setUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [permissions, setPermissions] = useState<AdminPermissions>(NO_ADMIN_PERMS);

  const [activeView, setActiveView] = useState<ActiveView>('home');
  const [loginOpen, setLoginOpen] = useState(false);
  const [adminOpen, setAdminOpen] = useState(false);
  const [logoError, setLogoError] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [verifyBusy, setVerifyBusy] = useState(false);
  const [cachedLogoDataUri, setCachedLogoDataUri] = useState<string>('');
  const [cachedTemplates, setCachedTemplates] = useState<StandaloneTemplates | null>(null);
  const [portalOpened, setPortalOpened] = useState(false);
  const [gateDismissed, setGateDismissed] = useState(false);

  const pwa = usePWAInstall();
  const t = TRANSLATIONS[lang];

  useEffect(() => {
    let cancelled = false;
    preloadStandaloneTemplates().then((tpl) => {
      if (!cancelled && tpl) {
        setCachedTemplates(tpl);
      }
    });
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    let cancelled = false;
    resolveLogoAsDataUri(siteConfig.logoUrl || DEFAULT_LOGO_PATH).then((dataUri) => {
      if (!cancelled && dataUri) {
        setCachedLogoDataUri(dataUri);
      }
    });
    return () => {
      cancelled = true;
    };
  }, [siteConfig.logoUrl]);

  const triggerDownloadBlob = (html: string) => {
    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    const blobUrl = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = blobUrl;
    link.download = 'One-City-RP.html';
    link.rel = 'noopener noreferrer';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.setTimeout(() => URL.revokeObjectURL(blobUrl), 10000);
    setToastMessage(t.pwaDownloadedToast);
  };

  const triggerDirectAppDownload = async () => {
    const resolvedLogo =
      cachedLogoDataUri || (await resolveLogoAsDataUri(siteConfig.logoUrl || DEFAULT_LOGO_PATH));
    const templates = cachedTemplates || (await preloadStandaloneTemplates());
    const html = templates
      ? generateFullSingleHtml({
          siteConfig,
          botInfo,
          logoDataUri: resolvedLogo,
          templates,
        })
      : generateStandaloneHtml({
          ...siteConfig,
          logoUrl: resolvedLogo,
        });
    triggerDownloadBlob(html);
    pwa.markInstalled(true);
  };

  // Sync HTML lang, dir, title & persist language choice
  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    try {
      window.localStorage.setItem('onecity_lang', lang);
    } catch {
      // Ignore storage errors
    }
  }, [lang]);

  useEffect(() => {
    document.title = siteConfig.siteName || 'One City RP';
  }, [siteConfig.siteName]);

  useEffect(() => {
    getRedirectResult(auth)
      .then((res) => {
        if (res?.user) {
          setActiveView('news');
          setToastMessage(TRANSLATIONS[lang].loginWelcomeToast);
        }
      })
      .catch((err) => {
        console.error('Google redirect error:', err);
        const msg = err instanceof Error ? err.message : '';
        if (msg) {
          setToastMessage(msg);
        }
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Real-time public site config listener
  useEffect(() => {
    const configRef = doc(db, 'site_config', 'main');
    const unsubscribe = onSnapshot(
      configRef,
      (snapshot) => {
        if (snapshot.exists()) {
          const data = snapshot.data() as Partial<SiteConfig>;
          const rawLogo = data.logoUrl || DEFAULT_SITE_CONFIG.logoUrl;
          const resolvedLogo =
            rawLogo === LEGACY_LOGO_PATH ||
            rawLogo === './assets/crest.jpg' ||
            rawLogo === './assets/logo.png' ||
            rawLogo.startsWith('/assets/aistudio/')
              ? DEFAULT_LOGO_PATH
              : rawLogo;
          setConfigExistsInDb(true);
          setSiteConfig({
            siteName: data.siteName || DEFAULT_SITE_CONFIG.siteName,
            siteSubtitle: data.siteSubtitle ?? DEFAULT_SITE_CONFIG.siteSubtitle,
            logoUrl: resolvedLogo,
            neonColor: data.neonColor || DEFAULT_SITE_CONFIG.neonColor,
            welcomeMessages:
              Array.isArray(data.welcomeMessages) && data.welcomeMessages.length > 0
                ? data.welcomeMessages
                : DEFAULT_SITE_CONFIG.welcomeMessages,
            buttons:
              Array.isArray(data.buttons) && data.buttons.length > 0
                ? data.buttons
                : DEFAULT_SITE_CONFIG.buttons,
          });
          setLogoError(false);
        } else {
          setConfigExistsInDb(false);
          setSiteConfig(DEFAULT_SITE_CONFIG);
        }
      },
      (error) => handleFirestoreError(error, OperationType.GET, 'site_config/main'),
    );

    return () => unsubscribe();
  }, []);

  // Real-time news & factions listener
  useEffect(() => {
    const botRef = doc(db, 'site_config', 'bot_info');
    const unsubscribe = onSnapshot(
      botRef,
      (snapshot) => {
        if (snapshot.exists()) {
          const data = snapshot.data() as Partial<BotInfo>;
          setBotInfoExistsInDb(true);
          setBotInfo({
            news: Array.isArray(data.news) ? data.news : DEFAULT_BOT_INFO.news,
            factions:
              Array.isArray(data.factions) && data.factions.length > 0
                ? data.factions
                : DEFAULT_BOT_INFO.factions,
          });
        } else {
          setBotInfoExistsInDb(false);
          setBotInfo(DEFAULT_BOT_INFO);
        }
      },
      (error) => handleFirestoreError(error, OperationType.GET, 'site_config/bot_info'),
    );

    return () => unsubscribe();
  }, []);

  // Auth state & role resolution
  useEffect(() => {
    let unsubAdminDoc: (() => void) | null = null;

    const unsubAuth = onAuthStateChanged(auth, async (firebaseUser) => {
      if (unsubAdminDoc) {
        unsubAdminDoc();
        unsubAdminDoc = null;
      }

      setUser(firebaseUser);
      setAuthReady(true);

      if (!firebaseUser) {
        setActiveView('home');
      }

      if (!firebaseUser || !firebaseUser.email || !firebaseUser.emailVerified) {
        setPermissions(NO_ADMIN_PERMS);
        setAdminOpen(false);
        return;
      }

      const lowerEmail = firebaseUser.email.toLowerCase();
      let pendingUsername = '';
      try {
        pendingUsername = (
          window.localStorage.getItem(`onecity_pending_username_${firebaseUser.uid}`) || ''
        ).trim();
      } catch {
        // Ignore storage error
      }

      // Record or refresh user profile cleanly with username
      const userRef = doc(db, 'users', firebaseUser.uid);
      try {
        const existingUser = await getDoc(userRef);
        const existingData = existingUser.exists()
          ? (existingUser.data() as Partial<UserProfile>)
          : null;
        const resolvedUsername = (
          pendingUsername ||
          firebaseUser.displayName?.trim() ||
          existingData?.username?.trim() ||
          lowerEmail.split('@')[0] ||
          'member'
        ).slice(0, 50);

        if (existingUser.exists()) {
          await updateDoc(userRef, {
            username: resolvedUsername,
            email: lowerEmail.slice(0, 128),
            displayName: (firebaseUser.displayName || resolvedUsername).slice(0, 100),
            photoURL: (firebaseUser.photoURL || '').slice(0, 500),
            lastLoginAt: serverTimestamp(),
          });
        } else {
          await setDoc(userRef, {
            uid: firebaseUser.uid,
            username: resolvedUsername,
            email: lowerEmail.slice(0, 128),
            displayName: (firebaseUser.displayName || resolvedUsername).slice(0, 100),
            photoURL: (firebaseUser.photoURL || '').slice(0, 500),
            createdAt: serverTimestamp(),
            lastLoginAt: serverTimestamp(),
          });
        }
        if (pendingUsername) {
          try {
            window.localStorage.removeItem(`onecity_pending_username_${firebaseUser.uid}`);
          } catch {
            // Ignore storage error
          }
        }
      } catch (error) {
        console.warn('User profile sync note:', error);
      }

      if (lowerEmail === SUPER_ADMIN_EMAIL) {
        setPermissions({
          isSuperAdmin: true,
          isAdmin: true,
          canEditBranding: true,
          canEditLinks: true,
          canEditBot: true,
          canManageAdmins: true,
        });

        try {
          const configRef = doc(db, 'site_config', 'main');
          const configSnap = await getDoc(configRef);
          if (!configSnap.exists()) {
            await setDoc(configRef, {
              ...DEFAULT_SITE_CONFIG,
              updatedAt: serverTimestamp(),
              updatedBy: firebaseUser.uid,
            });
          } else if (
            configSnap.data()?.logoUrl === LEGACY_LOGO_PATH ||
            String(configSnap.data()?.logoUrl || '').startsWith('/assets/aistudio/')
          ) {
            await updateDoc(configRef, {
              logoUrl: DEFAULT_LOGO_PATH,
              updatedAt: serverTimestamp(),
              updatedBy: firebaseUser.uid,
            });
          }

          const botRef = doc(db, 'site_config', 'bot_info');
          const botSnap = await getDoc(botRef);
          if (!botSnap.exists()) {
            await setDoc(botRef, {
              ...DEFAULT_BOT_INFO,
              updatedAt: serverTimestamp(),
              updatedBy: firebaseUser.uid,
            });
          }
        } catch (error) {
          handleFirestoreError(error, OperationType.WRITE, 'site_config');
        }
      } else {
        const adminRef = doc(db, 'admins', lowerEmail);
        unsubAdminDoc = onSnapshot(
          adminRef,
          (snap) => {
            if (snap.exists()) {
              const adminData = snap.data() as AdminMember;
              const hasAny = Boolean(
                adminData.canEditBranding || adminData.canEditLinks || adminData.canEditBot,
              );
              setPermissions({
                isSuperAdmin: false,
                isAdmin: hasAny,
                canEditBranding: Boolean(adminData.canEditBranding),
                canEditLinks: Boolean(adminData.canEditLinks),
                canEditBot: Boolean(adminData.canEditBot),
                canManageAdmins: false,
              });
              if (!hasAny) {
                setAdminOpen(false);
              }
            } else {
              setPermissions(NO_ADMIN_PERMS);
              setAdminOpen(false);
            }
          },
          (error) => handleFirestoreError(error, OperationType.GET, `admins/${lowerEmail}`),
        );
      }
    });

    return () => {
      if (unsubAdminDoc) unsubAdminDoc();
      unsubAuth();
    };
  }, []);

  useEffect(() => {
    if (!toastMessage) return;
    const timer = window.setTimeout(() => setToastMessage(null), 3200);
    return () => window.clearTimeout(timer);
  }, [toastMessage]);

  const handleSignOut = async () => {
    setAdminOpen(false);
    setActiveView('home');
    await signOut(auth);
  };

  const handleResendVerification = async () => {
    if (!auth.currentUser) return;
    setVerifyBusy(true);
    try {
      await sendEmailVerification(auth.currentUser);
      setToastMessage(t.verifyResentToast);
    } catch (err) {
      setToastMessage(err instanceof Error ? err.message : t.fbSaveError);
    } finally {
      setVerifyBusy(false);
    }
  };

  const handleRefreshVerification = async () => {
    if (!auth.currentUser) return;
    setVerifyBusy(true);
    try {
      await auth.currentUser.reload();
      await auth.currentUser.getIdToken(true);
      const refreshed = auth.currentUser;
      if (refreshed.emailVerified && refreshed.email) {
        setUser({ ...refreshed } as User);
        const lowerEmail = refreshed.email.toLowerCase();
        let pendingUsername = '';
        try {
          pendingUsername = (
            window.localStorage.getItem(`onecity_pending_username_${refreshed.uid}`) || ''
          ).trim();
        } catch {
          // Ignore storage error
        }
        const resolvedUsername = (
          pendingUsername ||
          refreshed.displayName?.trim() ||
          lowerEmail.split('@')[0] ||
          'member'
        ).slice(0, 50);
        const userRef = doc(db, 'users', refreshed.uid);
        const existingUser = await getDoc(userRef);
        if (existingUser.exists()) {
          await updateDoc(userRef, {
            username: resolvedUsername,
            email: lowerEmail.slice(0, 128),
            displayName: (refreshed.displayName || resolvedUsername).slice(0, 100),
            photoURL: (refreshed.photoURL || '').slice(0, 500),
            lastLoginAt: serverTimestamp(),
          });
        } else {
          await setDoc(userRef, {
            uid: refreshed.uid,
            username: resolvedUsername,
            email: lowerEmail.slice(0, 128),
            displayName: (refreshed.displayName || resolvedUsername).slice(0, 100),
            photoURL: (refreshed.photoURL || '').slice(0, 500),
            createdAt: serverTimestamp(),
            lastLoginAt: serverTimestamp(),
          });
        }
        setToastMessage(t.verifyConfirmedToast);
      } else {
        setToastMessage(t.verifyStillPendingToast);
      }
    } catch (err) {
      setToastMessage(err instanceof Error ? err.message : t.fbSaveError);
    } finally {
      setVerifyBusy(false);
    }
  };

  const getLocalizedButtonLabel = (btn: ButtonItem): string => {
    const mapping = DEFAULT_BUTTON_EN_MAP[btn.id];
    if (mapping) {
      if (lang === 'en' && mapping.ar.includes(btn.label)) {
        return mapping.en;
      }
      if (lang === 'ar' && btn.id === 'discord' && btn.label === 'سيرفر ديسكورد') {
        return t.discordDefaultCta;
      }
      if (lang === 'ar' && btn.id === 'tiktok' && btn.label === 'حساب تيك توك') {
        return t.tiktokDefaultCta;
      }
      if (lang === 'ar' && btn.id === 'game' && btn.label === 'One City RP') {
        return t.gameCardCta;
      }
    }
    return btn.label;
  };

  const handleUnsetButtonClick = (btn: ButtonItem) => {
    const displayLabel = getLocalizedButtonLabel(btn);
    setToastMessage(`${t.pendingLinkPrefix} "${displayLabel}" ${t.pendingLinkSuffix}`);
  };

  const toggleLanguage = () => {
    setLang((prev) => (prev === 'ar' ? 'en' : 'ar'));
  };

  const scrollToGameGuide = () => {
    setActiveView('home');
    window.setTimeout(() => {
      document.getElementById('game-guide')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 60);
  };

  const neon = siteConfig.neonColor || '#a855f7';
  const visibleButtons = siteConfig.buttons.filter((b) => b.enabled);
  const discordBtn = visibleButtons.find((b) => b.id === 'discord');
  const tiktokBtn = visibleButtons.find((b) => b.id === 'tiktok');
  const gameBtn = visibleButtons.find((b) => b.id === 'game');
  const extraButtons = visibleButtons.filter(
    (b) => b.id !== 'discord' && b.id !== 'tiktok' && b.id !== 'game',
  );
  const currentView: ActiveView = authReady && user ? activeView : 'home';
  const DirectionalArrow = lang === 'ar' ? ArrowLeft : ArrowRight;

  const isCustomSubtitle =
    Boolean(siteConfig.siteSubtitle?.trim()) &&
    siteConfig.siteSubtitle.trim() !== t.defaultSubtitleAr &&
    siteConfig.siteSubtitle.trim() !== t.defaultSubtitleEn;

  const showFullPortal = Boolean(
    pwa.isStandalone || (pwa.isInstalled && !pwa.justInstalled) || portalOpened || user,
  );

  const logoSrc = siteConfig.logoUrl || DEFAULT_LOGO_PATH;

  return (
    <div className="relative min-h-screen w-full bg-black text-white flex flex-col justify-between overflow-hidden">
      <StarfieldCanvas neonColor={neon} />

      {/* Minimal Streamlined Top Header */}
      <header className="sticky top-0 z-20 w-full backdrop-blur-md bg-[#040610]/70 border-b border-white/[0.08]">
        <div className="max-w-6xl mx-auto flex flex-col gap-2 px-4 sm:px-6 py-2.5">
          <div className="w-full flex items-center justify-between gap-3">
            {/* Brand: Purple 1C Emblem + Wordmark */}
            <button
              type="button"
              onClick={() => setActiveView('home')}
              className="flex items-center gap-2.5 min-w-0 cursor-pointer group shrink-0"
            >
              {!logoError ? (
                <img
                  src={logoSrc}
                  alt={siteConfig.siteName}
                  referrerPolicy="no-referrer"
                  onError={() => setLogoError(true)}
                  className="w-9 h-9 object-contain drop-shadow-[0_0_10px_rgba(168,85,247,0.65)] transition-transform duration-200 group-hover:scale-105"
                />
              ) : null}
              <span className="font-display text-sm sm:text-base font-extrabold tracking-tight text-white whitespace-nowrap">
                {siteConfig.siteName}
              </span>
            </button>

            {/* Center Navigation (Home pill + Member Tabs when signed in) */}
            {showFullPortal && (
              <nav
                aria-label="Primary navigation"
                className="hidden md:flex items-center gap-1.5"
              >
                <button
                  type="button"
                  onClick={() => setActiveView('home')}
                  className={`inline-flex items-center gap-1.5 px-4 py-1.5 min-h-[36px] rounded-full text-xs sm:text-sm font-bold whitespace-nowrap transition-all duration-200 cursor-pointer ${
                    currentView === 'home'
                      ? 'text-white border'
                      : 'text-zinc-300 hover:text-white hover:bg-white/[0.06]'
                  }`}
                  style={
                    currentView === 'home'
                      ? {
                          borderColor: neon,
                          backgroundColor: `${neon}28`,
                          boxShadow: `0 0 18px ${neon}44`,
                        }
                      : undefined
                  }
                >
                  <Home className="w-3.5 h-3.5 shrink-0" />
                  <span>{t.menuHome}</span>
                </button>

                <button
                  type="button"
                  onClick={scrollToGameGuide}
                  className="inline-flex items-center gap-1.5 px-3.5 py-1.5 min-h-[36px] rounded-full text-xs sm:text-sm font-bold whitespace-nowrap transition-all duration-200 cursor-pointer text-zinc-300 hover:text-white hover:bg-white/[0.06]"
                >
                  <BookOpen className="w-3.5 h-3.5 shrink-0" />
                  <span>{t.menuGuide}</span>
                </button>

                {authReady &&
                  user &&
                  (
                    [
                      { id: 'news', label: t.menuNews, Icon: Newspaper },
                      { id: 'factions', label: t.menuFactions, Icon: Shield },
                      { id: 'ai', label: t.menuAi, Icon: Bot },
                    ] as const
                  ).map(({ id, label, Icon }) => {
                    const active = currentView === id;
                    return (
                      <button
                        key={id}
                        type="button"
                        onClick={() => setActiveView(id)}
                        className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 min-h-[36px] rounded-full text-xs sm:text-sm font-bold whitespace-nowrap transition-all duration-200 cursor-pointer ${
                          active
                            ? 'text-white border'
                            : 'text-zinc-300 hover:text-white hover:bg-white/[0.06]'
                        }`}
                        style={
                          active
                            ? {
                                borderColor: neon,
                                backgroundColor: `${neon}28`,
                                boxShadow: `0 0 18px ${neon}44`,
                              }
                            : undefined
                        }
                      >
                        <Icon className="w-3.5 h-3.5 shrink-0" />
                        <span>{label}</span>
                      </button>
                    );
                  })}
              </nav>
            )}

            {/* Compact Right Actions */}
            <div className="flex items-center gap-2 shrink-0">
              {authReady && permissions.isAdmin && (
                <button
                  type="button"
                  onClick={() => setAdminOpen(true)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 min-h-[36px] rounded-full bg-zinc-900/80 hover:bg-zinc-800 border text-xs font-semibold text-white transition-all duration-150 whitespace-nowrap shrink-0 cursor-pointer"
                  style={{
                    borderColor: `${neon}66`,
                    boxShadow: `0 0 14px ${neon}24`,
                  }}
                >
                  <Settings className="w-3.5 h-3.5 shrink-0" style={{ color: neon }} />
                  <span className="hidden sm:inline">{t.adminPanel}</span>
                </button>
              )}

              <button
                type="button"
                onClick={toggleLanguage}
                aria-label={t.switchLangAria}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 min-h-[36px] rounded-full bg-white/[0.04] hover:bg-white/[0.09] border border-white/10 text-xs font-semibold text-zinc-200 hover:text-white transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Globe className="w-3.5 h-3.5 shrink-0" style={{ color: neon }} />
                <span>{lang === 'ar' ? 'EN' : 'AR'}</span>
              </button>

              {authReady && !user && (
                <button
                  type="button"
                  onClick={() => setLoginOpen(true)}
                  className="inline-flex items-center gap-1.5 px-4 py-1.5 min-h-[36px] rounded-full border text-xs font-bold text-white transition-all duration-150 whitespace-nowrap shrink-0 cursor-pointer bg-black/50 hover:bg-white/[0.08]"
                  style={{
                    borderColor: `${neon}80`,
                    boxShadow: `0 0 16px ${neon}30`,
                  }}
                >
                  <LogIn className="w-3.5 h-3.5 shrink-0" style={{ color: neon }} />
                  <span>{t.signIn}</span>
                </button>
              )}

              {authReady && user && (
                <button
                  type="button"
                  onClick={handleSignOut}
                  className="inline-flex items-center gap-1.5 px-3.5 py-1.5 min-h-[36px] rounded-full bg-white/[0.04] hover:bg-white/[0.09] border border-white/10 text-xs font-semibold text-zinc-300 hover:text-white transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5 shrink-0" />
                  <span>{t.signOut}</span>
                </button>
              )}
            </div>
          </div>

          {/* Mobile Member Tabs Row (shown only on small screens when signed in) */}
          {showFullPortal && authReady && user && (
            <nav
              aria-label="Mobile member navigation"
              className="flex md:hidden items-center justify-center gap-1.5 pt-1 overflow-x-auto"
            >
              {(
                [
                  { id: 'home', label: t.menuHome, Icon: Home },
                  { id: 'news', label: t.menuNews, Icon: Newspaper },
                  { id: 'factions', label: t.menuFactions, Icon: Shield },
                  { id: 'ai', label: t.menuAi, Icon: Bot },
                ] as const
              ).map(({ id, label, Icon }) => {
                const active = currentView === id;
                return (
                  <button
                    key={id}
                    type="button"
                    onClick={() => setActiveView(id)}
                    className={`inline-flex items-center gap-1.5 px-3 py-1.5 min-h-[36px] rounded-full text-xs font-bold whitespace-nowrap shrink-0 transition-all cursor-pointer ${
                      active ? 'text-white border' : 'text-zinc-400 hover:text-white'
                    }`}
                    style={
                      active
                        ? {
                            borderColor: neon,
                            backgroundColor: `${neon}28`,
                            boxShadow: `0 0 14px ${neon}44`,
                          }
                        : undefined
                    }
                  >
                    <Icon className="w-3.5 h-3.5 shrink-0" />
                    <span>{label}</span>
                  </button>
                );
              })}
            </nav>
          )}

          <OfflineIndicator isOnline={pwa.isOnline} lang={lang} />

          {/* Email Verification Reminder Banner */}
          {authReady && user && !user.emailVerified && (
            <div className="w-full max-w-2xl mx-auto px-3.5 py-2 rounded-xl bg-amber-950/75 border border-amber-500/40 text-amber-100 text-xs flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2 min-w-0">
                <MailCheck className="w-4 h-4 text-amber-400 shrink-0" />
                <span>{t.verifyBannerText}</span>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  disabled={verifyBusy}
                  onClick={handleResendVerification}
                  className="px-2.5 py-1 rounded-lg bg-amber-500/20 hover:bg-amber-500/35 border border-amber-400/40 text-amber-100 font-semibold cursor-pointer disabled:opacity-50"
                >
                  {t.verifyResendBtn}
                </button>
                <button
                  type="button"
                  disabled={verifyBusy}
                  onClick={handleRefreshVerification}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-600/30 hover:bg-emerald-600/45 border border-emerald-400/40 text-emerald-100 font-semibold cursor-pointer disabled:opacity-50"
                >
                  <RefreshCw className="w-3 h-3" />
                  <span>{t.verifyRefreshBtn}</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </header>

      {/* Main Centered Stage */}
      <main className="relative z-10 flex-1 flex flex-col items-center justify-center px-4 sm:px-6 py-6 sm:py-8">
        {!showFullPortal ? (
          gateDismissed && !pwa.justInstalled && !pwa.modalOpen ? (
            <button
              type="button"
              onClick={() => {
                setGateDismissed(false);
                pwa.openModal();
              }}
              className="inline-flex items-center gap-2.5 px-6 py-3.5 rounded-2xl bg-white text-zinc-900 font-bold text-sm sm:text-base shadow-[0_14px_40px_rgba(0,0,0,0.45)] hover:bg-zinc-100 transition-all cursor-pointer"
            >
              <Download className="w-5 h-5 text-[#0f9d58]" />
              <span>{t.pwaInstallBtn}</span>
            </button>
          ) : (
            <PWAInstallModal
              inlineGate
              isOpen={true}
              justInstalled={pwa.justInstalled}
              onClose={() => {
                if (pwa.justInstalled) {
                  pwa.dismissModal();
                } else {
                  setGateDismissed(true);
                  pwa.dismissModal();
                }
              }}
              onOpenApp={() => {
                setPortalOpened(true);
                pwa.dismissModal();
              }}
              onInstallClick={pwa.triggerNativeInstall}
              onDirectDownload={triggerDirectAppDownload}
              canPromptNatively={pwa.canPromptNatively}
              isIOS={pwa.isIOS}
              isAndroid={pwa.isAndroid}
              isInIframe={pwa.isInIframe}
              neonColor={neon}
              lang={lang}
            />
          )
        ) : (
          <>
            {currentView === 'home' && (
              <div className="w-full max-w-5xl mx-auto flex flex-col items-center">
                {/* Purple 1C Crest Hero Showcase */}
                <div className="relative flex flex-col items-center text-center mb-7">
                  <div
                    aria-hidden="true"
                    className="absolute -inset-x-16 -top-8 bottom-0 rounded-full blur-3xl animate-neon-breath pointer-events-none"
                    style={{
                      background: `radial-gradient(circle, ${neon}44 0%, ${neon}14 48%, transparent 74%)`,
                    }}
                  />

                  {/* Uncropped Floating Purple 1C Emblem */}
                  <div className="relative animate-crest-float mb-2">
                    {!logoError ? (
                      <img
                        src={logoSrc}
                        alt={siteConfig.siteName}
                        referrerPolicy="no-referrer"
                        onError={() => setLogoError(true)}
                        className="w-32 h-32 sm:w-40 sm:h-40 object-contain select-none"
                        style={{
                          filter: `drop-shadow(0 0 28px ${neon}aa) drop-shadow(0 8px 20px rgba(0,0,0,0.9))`,
                        }}
                      />
                    ) : (
                      <div className="w-32 h-32 flex items-center justify-center">
                        <Gamepad2 className="w-16 h-16" style={{ color: neon }} />
                      </div>
                    )}
                  </div>

                  {/* Stylized Brand Lockup */}
                  <h1
                    className="relative font-display text-3xl sm:text-5xl font-black tracking-tight text-white italic text-balance"
                    style={{
                      textShadow: `0 4px 24px rgba(0,0,0,0.95), 0 0 28px ${neon}80`,
                    }}
                  >
                    {siteConfig.siteName}
                  </h1>

                  {/* Tagline with flanking neon lines */}
                  <div className="relative flex items-center justify-center gap-3 sm:gap-4 mt-3 w-full max-w-xl">
                    <span
                      aria-hidden="true"
                      className="h-[2px] w-10 sm:w-20 rounded-full"
                      style={{
                        background: `linear-gradient(90deg, transparent, ${neon})`,
                        boxShadow: `0 0 10px ${neon}`,
                      }}
                    />
                    <p className="text-lg sm:text-2xl font-extrabold text-white tracking-tight whitespace-nowrap">
                      <span>{t.heroTaglineStart} </span>
                      <span
                        style={{
                          color: neon,
                          textShadow: `0 0 18px ${neon}cc`,
                        }}
                      >
                        {t.heroTaglineAccent}
                      </span>
                      <span> {t.heroTaglineEnd}</span>
                    </p>
                    <span
                      aria-hidden="true"
                      className="h-[2px] w-10 sm:w-20 rounded-full"
                      style={{
                        background: `linear-gradient(270deg, transparent, ${neon})`,
                        boxShadow: `0 0 10px ${neon}`,
                      }}
                    />
                  </div>

                  {/* Sub-caption */}
                  <p className="relative mt-2.5 text-xs sm:text-sm font-medium text-zinc-300/90 max-w-lg px-2">
                    {isCustomSubtitle ? siteConfig.siteSubtitle : t.heroSubline}
                  </p>
                </div>

                {/* Animated Side-by-Side Discord & TikTok Buttons */}
                {(discordBtn || tiktokBtn) && (
                  <div className="w-full max-w-xl flex flex-col sm:flex-row items-stretch sm:items-center justify-center gap-3.5 mb-8">
                    {discordBtn &&
                      (() => {
                        const label = getLocalizedButtonLabel(discordBtn);
                        const url = sanitizeExternalUrl(discordBtn.url);
                        const btnClasses =
                          'group relative overflow-hidden flex-1 min-h-[50px] px-6 py-3 rounded-xl font-bold text-sm sm:text-base text-white flex items-center justify-center gap-3 border transition-transform duration-200 hover:-translate-y-1 animate-btn-pulse cursor-pointer whitespace-nowrap';
                        const btnStyle = {
                          borderColor: neon,
                          background: `linear-gradient(135deg, ${neon}, #5b21b6)`,
                        };
                        const inner = (
                          <>
                            <span
                              aria-hidden="true"
                              className="pointer-events-none absolute inset-y-0 w-1/2 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-btn-sheen"
                            />
                            <svg
                              viewBox="0 0 24 24"
                              className="relative w-5 h-5 fill-current shrink-0 transition-transform duration-200 group-hover:scale-110"
                              aria-hidden="true"
                            >
                              <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994.021-.041.001-.09-.041-.106a13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.061 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.028ZM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418Zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418Z" />
                            </svg>
                            <span className="relative">{label}</span>
                            <DirectionalArrow className="relative w-4 h-4 shrink-0 transition-transform duration-200 group-hover:translate-x-[-3px]" />
                          </>
                        );
                        return url ? (
                          <a
                            key={discordBtn.id}
                            href={url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className={btnClasses}
                            style={btnStyle}
                          >
                            {inner}
                          </a>
                        ) : (
                          <button
                            key={discordBtn.id}
                            type="button"
                            onClick={() => handleUnsetButtonClick(discordBtn)}
                            className={btnClasses}
                            style={btnStyle}
                          >
                            {inner}
                          </button>
                        );
                      })()}

                    {tiktokBtn &&
                      (() => {
                        const label = getLocalizedButtonLabel(tiktokBtn);
                        const url = sanitizeExternalUrl(tiktokBtn.url);
                        const btnClasses =
                          'group relative overflow-hidden flex-1 min-h-[50px] px-6 py-3 rounded-xl font-bold text-sm sm:text-base text-white bg-[#070a18]/80 backdrop-blur-xl flex items-center justify-center gap-3 border transition-all duration-200 hover:-translate-y-1 hover:bg-[#0d1229]/90 cursor-pointer whitespace-nowrap';
                        const btnStyle = {
                          borderColor: `${neon}66`,
                          boxShadow: `0 0 20px ${neon}26, inset 0 0 14px ${neon}14`,
                        };
                        const inner = (
                          <>
                            <span
                              aria-hidden="true"
                              className="pointer-events-none absolute inset-y-0 w-1/2 bg-gradient-to-r from-transparent via-purple-300/20 to-transparent animate-btn-sheen"
                              style={{ animationDelay: '1.6s' }}
                            />
                            <svg
                              viewBox="0 0 24 24"
                              className="relative w-5 h-5 shrink-0 transition-transform duration-200 group-hover:scale-110"
                              aria-hidden="true"
                            >
                              <path
                                fill="#25F4EE"
                                d="M16.6 5.82s.51.5 0 0A4.278 4.278 0 0 1 15.54 3h-3.09v12.4a2.592 2.592 0 0 1-2.59 2.5c-1.42 0-2.6-1.16-2.6-2.6 0-1.72 1.66-3.01 3.37-2.48V9.66c-3.45-.46-6.47 2.22-6.47 5.64 0 3.33 2.76 5.7 5.69 5.7 3.14 0 5.69-2.55 5.69-5.7V9.01a7.35 7.35 0 0 0 4.3 1.38V7.3s-1.88.09-3.24-1.48z"
                                transform="translate(-0.7 -0.6)"
                              />
                              <path
                                fill="#FE2C55"
                                d="M16.6 5.82s.51.5 0 0A4.278 4.278 0 0 1 15.54 3h-3.09v12.4a2.592 2.592 0 0 1-2.59 2.5c-1.42 0-2.6-1.16-2.6-2.6 0-1.72 1.66-3.01 3.37-2.48V9.66c-3.45-.46-6.47 2.22-6.47 5.64 0 3.33 2.76 5.7 5.69 5.7 3.14 0 5.69-2.55 5.69-5.7V9.01a7.35 7.35 0 0 0 4.3 1.38V7.3s-1.88.09-3.24-1.48z"
                                transform="translate(0.7 0.6)"
                              />
                              <path
                                fill="#FFFFFF"
                                d="M16.6 5.82s.51.5 0 0A4.278 4.278 0 0 1 15.54 3h-3.09v12.4a2.592 2.592 0 0 1-2.59 2.5c-1.42 0-2.6-1.16-2.6-2.6 0-1.72 1.66-3.01 3.37-2.48V9.66c-3.45-.46-6.47 2.22-6.47 5.64 0 3.33 2.76 5.7 5.69 5.7 3.14 0 5.69-2.55 5.69-5.7V9.01a7.35 7.35 0 0 0 4.3 1.38V7.3s-1.88.09-3.24-1.48z"
                              />
                            </svg>
                            <span className="relative">{label}</span>
                            <DirectionalArrow className="relative w-4 h-4 shrink-0 text-zinc-300 transition-transform duration-200 group-hover:translate-x-[-3px]" />
                          </>
                        );
                        return url ? (
                          <a
                            key={tiktokBtn.id}
                            href={url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className={btnClasses}
                            style={btnStyle}
                          >
                            {inner}
                          </a>
                        ) : (
                          <button
                            key={tiktokBtn.id}
                            type="button"
                            onClick={() => handleUnsetButtonClick(tiktokBtn)}
                            className={btnClasses}
                            style={btnStyle}
                          >
                            {inner}
                          </button>
                        );
                      })()}
                  </div>
                )}

                {/* Any extra custom buttons added by admin */}
                {extraButtons.length > 0 && (
                  <div className="flex flex-wrap items-center justify-center gap-2.5 mb-7">
                    {extraButtons.map((btn) => {
                      const safeUrl = sanitizeExternalUrl(btn.url);
                      const label = getLocalizedButtonLabel(btn);
                      const cls =
                        'inline-flex items-center gap-2 px-4 py-2 min-h-[42px] rounded-xl bg-zinc-950/75 hover:bg-zinc-900/90 border border-white/15 text-xs sm:text-sm font-bold text-white transition-all hover:-translate-y-0.5 cursor-pointer';
                      return safeUrl ? (
                        <a
                          key={btn.id}
                          href={safeUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className={cls}
                        >
                          <span aria-hidden="true">{btn.icon}</span>
                          <span>{label}</span>
                        </a>
                      ) : (
                        <button
                          key={btn.id}
                          type="button"
                          onClick={() => handleUnsetButtonClick(btn)}
                          className={cls}
                        >
                          <span aria-hidden="true">{btn.icon}</span>
                          <span>{label}</span>
                        </button>
                      );
                    })}
                  </div>
                )}

                {/* Bottom Game Portal Showcase Card (موقع اللعبة) */}
                {gameBtn && (
                  <section
                    aria-label={t.gameCardTitle}
                    className="relative w-full max-w-4xl rounded-2xl overflow-hidden bg-[#050816]/80 backdrop-blur-xl border transition-all duration-300"
                    style={{
                      borderColor: `${neon}66`,
                      boxShadow: `0 18px 50px rgba(0,0,0,0.72), 0 0 34px ${neon}24`,
                    }}
                  >
                    <div className="grid grid-cols-1 md:grid-cols-[1.05fr_0.95fr] items-stretch">
                      {/* Visual Cityscape & Purple 1C Crest Panel */}
                      <div className="relative min-h-[170px] sm:min-h-[210px] overflow-hidden bg-gradient-to-br from-[#0d0824] via-[#060918] to-[#03050d] flex items-center justify-center border-b md:border-b-0 md:border-e border-white/[0.08]">
                        <div
                          aria-hidden="true"
                          className="absolute inset-0 opacity-60 pointer-events-none"
                          style={{
                            background: `radial-gradient(circle at 45% 40%, ${neon}38 0%, transparent 65%)`,
                          }}
                        />
                        {/* Skyline Silhouette */}
                        <svg
                          viewBox="0 0 600 220"
                          preserveAspectRatio="none"
                          className="absolute inset-x-0 bottom-0 w-full h-36 opacity-55 pointer-events-none"
                          aria-hidden="true"
                        >
                          <path
                            d="M0 220V165h28v-35h22v35h16V98h34v67h18v-48h26v48h20V72h42v93h16v-55h30v55h22V86h36v79h18v-42h28v42h20V60h40v105h18v-44h28v44h22v-65h34v65h24v-28h30v55H0Z"
                            fill="#090d1f"
                          />
                          <path
                            d="M0 206h600"
                            stroke={neon}
                            strokeWidth="2"
                            strokeOpacity="0.65"
                          />
                        </svg>

                        {/* Floating Purple 1C Crest Preview */}
                        {!logoError && (
                          <img
                            src={logoSrc}
                            alt=""
                            aria-hidden="true"
                            className="relative z-10 w-28 h-28 sm:w-36 sm:h-36 object-contain opacity-95"
                            style={{
                              filter: `drop-shadow(0 0 24px ${neon}aa)`,
                            }}
                          />
                        )}
                      </div>

                      {/* Game Info & Enter Button */}
                      <div className="relative flex flex-col items-center justify-center text-center px-6 py-7 sm:py-8">
                        <span
                          className="font-display text-[11px] font-bold tracking-[0.26em] uppercase mb-1.5"
                          style={{ color: neon }}
                        >
                          {siteConfig.siteName}
                        </span>

                        <div className="flex items-center justify-center gap-3 mb-2.5">
                          <span className="flex items-center gap-1" aria-hidden="true">
                            <span
                              className="w-2.5 h-3.5 -skew-x-12 rounded-[2px]"
                              style={{ backgroundColor: neon }}
                            />
                            <span
                              className="w-2.5 h-3.5 -skew-x-12 rounded-[2px] opacity-60"
                              style={{ backgroundColor: neon }}
                            />
                          </span>
                          <h2 className="text-xl sm:text-2xl font-extrabold text-white">
                            {t.gameCardTitle}
                          </h2>
                          <span className="flex items-center gap-1" aria-hidden="true">
                            <span
                              className="w-2.5 h-3.5 -skew-x-12 rounded-[2px] opacity-60"
                              style={{ backgroundColor: neon }}
                            />
                            <span
                              className="w-2.5 h-3.5 -skew-x-12 rounded-[2px]"
                              style={{ backgroundColor: neon }}
                            />
                          </span>
                        </div>

                        <p className="text-xs sm:text-sm text-zinc-300/90 leading-relaxed max-w-sm mb-5">
                          {t.gameCardDesc}
                        </p>

                        {(() => {
                          const safeGameUrl = sanitizeExternalUrl(gameBtn.url);
                          const gameCtaLabel = getLocalizedButtonLabel(gameBtn) || t.gameCardCta;
                          const ctaCls =
                            'group relative overflow-hidden inline-flex items-center justify-center gap-2.5 px-7 py-2.5 min-h-[44px] rounded-full border text-sm font-bold text-white bg-black/50 hover:bg-white/[0.08] transition-all duration-200 hover:-translate-y-0.5 cursor-pointer';
                          const ctaStyle = {
                            borderColor: neon,
                            boxShadow: `0 0 20px ${neon}38`,
                          };
                          const ctaInner = (
                            <>
                              <span
                                aria-hidden="true"
                                className="pointer-events-none absolute inset-y-0 w-1/2 bg-gradient-to-r from-transparent via-white/20 to-transparent animate-btn-sheen"
                                style={{ animationDelay: '0.8s' }}
                              />
                              <span className="relative">{gameCtaLabel}</span>
                              <DirectionalArrow className="relative w-4 h-4 shrink-0 transition-transform duration-200 group-hover:translate-x-[-3px]" />
                            </>
                          );
                          return safeGameUrl ? (
                            <a
                              href={safeGameUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className={ctaCls}
                              style={ctaStyle}
                            >
                              {ctaInner}
                            </a>
                          ) : (
                            <button
                              type="button"
                              onClick={() => handleUnsetButtonClick(gameBtn)}
                              className={ctaCls}
                              style={ctaStyle}
                            >
                              {ctaInner}
                            </button>
                          );
                        })()}
                      </div>
                    </div>
                  </section>
                )}

                <GameGuideSection
                  neonColor={neon}
                  lang={lang}
                  siteName={siteConfig.siteName}
                />
              </div>
            )}

            {currentView === 'news' && (
              <NewsSection news={botInfo.news} neonColor={neon} lang={lang} />
            )}

            {currentView === 'factions' && (
              <FactionsSection factions={botInfo.factions} neonColor={neon} lang={lang} />
            )}

            {currentView === 'ai' && (
              <AiChatPanel
                siteName={siteConfig.siteName}
                neonColor={neon}
                botInfo={botInfo}
                buttons={siteConfig.buttons}
                lang={lang}
              />
            )}
          </>
        )}
      </main>

      {/* Subtle Neon-Flanked Footer */}
      {showFullPortal && (
        <footer className="relative z-10 py-4 px-6 flex items-center justify-center gap-4 text-[11px] font-display tracking-[0.28em] uppercase text-zinc-400">
          <span
            aria-hidden="true"
            className="h-[1px] w-16 sm:w-28"
            style={{ background: `linear-gradient(90deg, transparent, ${neon}99)` }}
          />
          <span style={{ color: neon }}>{siteConfig.siteName}</span>
          <span
            aria-hidden="true"
            className="h-[1px] w-16 sm:w-28"
            style={{ background: `linear-gradient(270deg, transparent, ${neon}99)` }}
          />
        </footer>
      )}

      {/* Toast Notification */}
      {toastMessage && (
        <div
          role="status"
          className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40 px-5 py-3 rounded-xl bg-zinc-950/95 border text-xs sm:text-sm font-semibold text-white shadow-2xl backdrop-blur-md whitespace-nowrap"
          style={{
            borderColor: `${neon}80`,
            boxShadow: `0 0 24px ${neon}44`,
          }}
        >
          {toastMessage}
        </div>
      )}

      {/* Email/Password & Google Login Modal */}
      <LoginModal
        isOpen={loginOpen}
        onClose={() => setLoginOpen(false)}
        onLoginSuccess={(info) => {
          setPortalOpened(true);
          setActiveView('news');
          setToastMessage(
            info?.emailVerificationPending ? t.verifyResentToast : t.loginWelcomeToast,
          );
        }}
        neonColor={neon}
        lang={lang}
      />

      {/* PWA Install Modal overlay (when opened inside full portal before full dismiss) */}
      {showFullPortal && (
        <PWAInstallModal
          isOpen={pwa.modalOpen && (!pwa.isInstalled || pwa.justInstalled)}
          justInstalled={pwa.justInstalled}
          onClose={pwa.dismissModal}
          onOpenApp={() => {
            setPortalOpened(true);
            pwa.dismissModal();
          }}
          onInstallClick={pwa.triggerNativeInstall}
          onDirectDownload={triggerDirectAppDownload}
          canPromptNatively={pwa.canPromptNatively}
          isIOS={pwa.isIOS}
          isAndroid={pwa.isAndroid}
          isInIframe={pwa.isInIframe}
          neonColor={neon}
          lang={lang}
        />
      )}

      {/* Admin Management Modal (Strictly hidden unless permissions.isAdmin === true) */}
      {permissions.isAdmin && (
        <AdminModal
          isOpen={adminOpen}
          onClose={() => setAdminOpen(false)}
          siteConfig={siteConfig}
          configExistsInDb={configExistsInDb}
          botInfo={botInfo}
          botInfoExistsInDb={botInfoExistsInDb}
          permissions={permissions}
          lang={lang}
        />
      )}
    </div>
  );
}
