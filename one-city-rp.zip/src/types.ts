export interface ButtonItem {
  id: string;
  label: string;
  url: string;
  icon: string;
  enabled: boolean;
}

export interface SiteConfig {
  siteName: string;
  siteSubtitle: string;
  logoUrl: string;
  neonColor: string;
  welcomeMessages: string[];
  buttons: ButtonItem[];
  updatedAt?: unknown;
  updatedBy?: string;
}

export interface NewsItem {
  id: string;
  title: string;
  content: string;
  date: string;
  imageUrl?: string;
}

export type FactionStatus = 'مفتوح' | 'مغلق' | 'قريباً';

export interface FactionItem {
  id: string;
  name: string;
  icon: string;
  status: FactionStatus;
  description: string;
}

export interface BotInfo {
  news: NewsItem[];
  factions: FactionItem[];
  updatedAt?: unknown;
  updatedBy?: string;
}

export interface AdminMember {
  email: string;
  displayName: string;
  canEditBranding: boolean;
  canEditLinks: boolean;
  canEditBot?: boolean;
  addedBy: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface UserProfile {
  uid: string;
  username?: string;
  email: string;
  displayName: string;
  photoURL: string;
  createdAt?: unknown;
  lastLoginAt?: unknown;
}

export interface AdminPermissions {
  isSuperAdmin: boolean;
  isAdmin: boolean;
  canEditBranding: boolean;
  canEditLinks: boolean;
  canEditBot: boolean;
  canManageAdmins: boolean;
}

export const LEGACY_LOGO_PATH = '/src/assets/images/one_city_rp_crest_1795201248077.jpg';
export const DEFAULT_LOGO_PATH = '/assets/logo.png';

export const DEFAULT_SITE_CONFIG: SiteConfig = {
  siteName: 'One City RP',
  siteSubtitle: 'عالم الحياة الواقعية',
  logoUrl: DEFAULT_LOGO_PATH,
  neonColor: '#a855f7',
  welcomeMessages: [
    'مرحباً بكم في One City RP — تجربة حياة واقعية متكاملة',
    'انضم إلى مجتمعنا الآن واكتشف مدينة بلا حدود',
    'أجواء سينمائية واحترافية في انتظارك',
  ],
  buttons: [
    {
      id: 'discord',
      label: 'دخول إلى ديسكورد',
      url: 'https://discord.gg/aUzckMe3qY',
      icon: '🌐',
      enabled: true,
    },
    {
      id: 'tiktok',
      label: 'موقع التيك توك',
      url: 'https://www.tiktok.com/@onecityrp8?_r=1&_t=ZS-9BZOJHD47RV',
      icon: '🎵',
      enabled: true,
    },
    {
      id: 'game',
      label: 'دخول إلى اللعبة',
      url: '',
      icon: '🎮',
      enabled: true,
    },
  ],
};

export const DEFAULT_BOT_INFO: BotInfo = {
  news: [
    {
      id: 'news_1',
      title: 'افتتاح التقديم على الفصائل الرسمية',
      content: 'التقديم متاح الآن لقطاعات الشرطة والطب والجيش عبر سيرفر الديسكورد الرسمي.',
      date: '2026-11-20',
    },
    {
      id: 'news_2',
      title: 'تحديث المساعد الذكي لمجتمع One City RP',
      content: 'يمكنك الآن متابعة آخر الأخبار والتحديثات ومعرفة الفصائل المتاحة مباشرة داخل البوت.',
      date: '2026-11-20',
    },
  ],
  factions: [
    {
      id: 'police',
      name: 'الشرطة',
      icon: '🚓',
      status: 'مفتوح',
      description: 'حفظ الأمن والنظام داخل المدينة وملاحقة الخارجين عن القانون.',
    },
    {
      id: 'ems',
      name: 'الطب',
      icon: '🚑',
      status: 'مفتوح',
      description: 'تقديم الإسعافات الأولية والرعاية الطبية العاجلة لجميع المواطنين.',
    },
    {
      id: 'army',
      name: 'الجيش',
      icon: '🪖',
      status: 'مفتوح',
      description: 'حماية الحدود والمناطق الاستراتيجية ومساندة القوات الأمنية.',
    },
  ],
};
