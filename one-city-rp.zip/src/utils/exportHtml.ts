import { BotInfo, DEFAULT_LOGO_PATH, SiteConfig } from '../types';

export interface StandaloneTemplates {
  html: string;
  css: string;
  i18nJs: string;
  starfieldJs: string;
  aiJs: string;
  appJs: string;
  pwaIconDataUri: string;
}

let cachedTemplatesPromise: Promise<StandaloneTemplates | null> | null = null;

export function preloadStandaloneTemplates(): Promise<StandaloneTemplates | null> {
  if (cachedTemplatesPromise) return cachedTemplatesPromise;
  cachedTemplatesPromise = (async () => {
    try {
      const origin = window.location.origin;
      const [htmlRes, cssRes, i18nRes, starRes, aiRes, appRes, pwaIcon] = await Promise.all([
        fetch(`${origin}/standalone/index.html`),
        fetch(`${origin}/standalone/css/style.css`),
        fetch(`${origin}/standalone/js/i18n.js`),
        fetch(`${origin}/standalone/js/starfield.js`),
        fetch(`${origin}/standalone/js/ai.js`),
        fetch(`${origin}/standalone/js/app.js`),
        resolveLogoAsDataUri('/pwa-192x192.png'),
      ]);
      if (!htmlRes.ok || !cssRes.ok || !i18nRes.ok || !starRes.ok || !aiRes.ok || !appRes.ok) {
        return null;
      }
      const [html, css, i18nJs, starfieldJs, aiJs, appJs] = await Promise.all([
        htmlRes.text(),
        cssRes.text(),
        i18nRes.text(),
        starRes.text(),
        aiRes.text(),
        appRes.text(),
      ]);
      return { html, css, i18nJs, starfieldJs, aiJs, appJs, pwaIconDataUri: pwaIcon };
    } catch {
      return null;
    }
  })();
  return cachedTemplatesPromise;
}

function escapeHtml(value: string): string {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function resolveLogoForHtml(logoUrl: string): string {
  const trimmed = (logoUrl || DEFAULT_LOGO_PATH).trim();
  if (trimmed.startsWith('/')) {
    return `${window.location.origin}${trimmed}`;
  }
  return trimmed;
}

export async function resolveLogoAsDataUri(logoUrl: string): Promise<string> {
  const trimmed = (logoUrl || DEFAULT_LOGO_PATH).trim();
  if (trimmed.startsWith('data:')) {
    return trimmed;
  }
  try {
    const fetchUrl = trimmed.startsWith('/') ? `${window.location.origin}${trimmed}` : trimmed;
    const response = await fetch(fetchUrl);
    if (!response.ok) return trimmed;
    const blob = await response.blob();
    return await new Promise<string>((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(typeof reader.result === 'string' ? reader.result : trimmed);
      reader.onerror = () => resolve(trimmed);
      reader.readAsDataURL(blob);
    });
  } catch {
    return trimmed.startsWith('/') ? `${window.location.origin}${trimmed}` : trimmed;
  }
}

function stripLocalImportsAndExports(source: string): {
  externalImports: string[];
  body: string;
} {
  const externalImports: string[] = [];
  let cleaned = source.replace(
    /^import\s+[\s\S]*?\s+from\s+['"](https?:\/\/[^'"]+)['"];?\s*$/gm,
    (full) => {
      externalImports.push(full.trim());
      return '';
    },
  );
  cleaned = cleaned.replace(
    /^import\s+[\s\S]*?\s+from\s+['"]\.\/[^'"]+['"];?\s*$/gm,
    '',
  );
  cleaned = cleaned.replace(
    /^export\s+(?=(?:const|let|var|function|async\s+function)\b)/gm,
    '',
  );
  return { externalImports, body: cleaned.trim() };
}

export function generateFullSingleHtml(params: {
  siteConfig: SiteConfig;
  botInfo: BotInfo;
  logoDataUri: string;
  templates: StandaloneTemplates;
}): string {
  const { siteConfig, botInfo, logoDataUri, templates } = params;
  const embeddedLogo = logoDataUri || DEFAULT_LOGO_PATH;
  const embeddedPwaIcon = templates.pwaIconDataUri || embeddedLogo;

  const safeJson = (val: unknown) =>
    JSON.stringify(val, null, 2).replace(/<\//g, '<\\/');

  const liveSiteConfig: SiteConfig = {
    siteName: siteConfig.siteName || 'One City RP',
    siteSubtitle: siteConfig.siteSubtitle ?? '',
    logoUrl: embeddedLogo,
    neonColor: siteConfig.neonColor || '#a855f7',
    welcomeMessages: siteConfig.welcomeMessages,
    buttons: siteConfig.buttons,
  };

  const liveBotInfo: BotInfo = {
    news: botInfo.news,
    factions: botInfo.factions,
  };

  const configCode = `
const FIREBASE_CONFIG = {
  projectId: 'restful-subject-jmn89',
  appId: '1:1056900357351:web:2ed1df0ea7bbce5a9b9642',
  apiKey: 'AIzaSyByekX1Gip_KiMAme7WC4_rlOkHpe3tSoE',
  authDomain: 'restful-subject-jmn89.firebaseapp.com',
  firestoreDatabaseId: 'ai-studio-6005a356-06a5-43ca-b9b0-f4178128a37a',
  storageBucket: 'restful-subject-jmn89.firebasestorage.app',
  messagingSenderId: '1056900357351',
};
const SUPER_ADMIN_EMAIL = 'aboodialahmad10@gmail.com';
const AI_API_ENDPOINT = '';
const DEFAULT_LOGO_PATH = ${safeJson(embeddedLogo)};
const DEFAULT_SITE_CONFIG = ${safeJson(liveSiteConfig)};
const DEFAULT_BOT_INFO = ${safeJson(liveBotInfo)};
`.trim();

  const pI18n = stripLocalImportsAndExports(templates.i18nJs);
  const pStar = stripLocalImportsAndExports(templates.starfieldJs);
  const pAi = stripLocalImportsAndExports(templates.aiJs);
  const pApp = stripLocalImportsAndExports(templates.appJs);

  const allImports = [
    ...pI18n.externalImports,
    ...pStar.externalImports,
    ...pAi.externalImports,
    ...pApp.externalImports,
  ].join('\n');

  const mergedScript = [
    allImports,
    configCode,
    pI18n.body,
    pStar.body,
    pAi.body,
    pApp.body,
  ]
    .join('\n\n')
    .replace(/<\/script/gi, '<\\/script');

  const safeCss = templates.css.replace(/<\/style/gi, '<\\/style');

  let out = templates.html;
  out = out.replace(/<link\s+rel="manifest"[^>]*>/i, '');
  out = out.replace(/\.\/assets\/pwa-192x192\.png/g, embeddedPwaIcon);
  out = out.replace(/\.\/assets\/apple-touch-icon\.png/g, embeddedPwaIcon);
  out = out.replace(/\.\/assets\/pwa-512x512\.png/g, embeddedPwaIcon);
  out = out.replace(/\.\/assets\/logo\.png/g, embeddedLogo);
  out = out.replace(
    /<link\s+rel="stylesheet"\s+href="\.\/css\/style\.css"\s*\/?>/i,
    () => `<style>\n${safeCss}\n</style>`,
  );
  out = out.replace(
    /<script\s+type="module"\s+src="\.\/js\/app\.js"><\/script>/i,
    () => `<script type="module">\n${mergedScript}\n</script>`,
  );

  return out;
}

export function generateStandaloneHtml(config: SiteConfig): string {
  const neon = /^#[0-9a-fA-F]{6}$/.test(config.neonColor) ? config.neonColor : '#a855f7';
  const siteName = escapeHtml(config.siteName || 'One City RP');
  const rawSub = (config.siteSubtitle || '').trim();
  const isDefaultSub =
    !rawSub ||
    rawSub === 'بوابة المجتمع الرسمية' ||
    rawSub === 'Official Community Portal';
  const sublineText = escapeHtml(
    isDefaultSub
      ? 'انضم إلى عالمنا الواقعي في One City RP واستمتع بتجربة لعب فريدة من نوعها'
      : rawSub,
  );
  const logoSrc = escapeHtml(resolveLogoForHtml(config.logoUrl));

  const discordSvg =
    '<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true"><path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994.021-.041.001-.09-.041-.106a13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.061 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.028ZM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418Zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418Z"/></svg>';
  const tiktokSvg =
    '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path fill="#25F4EE" transform="translate(-0.7 -0.6)" d="M16.6 5.82s.51.5 0 0A4.278 4.278 0 0 1 15.54 3h-3.09v12.4a2.592 2.592 0 0 1-2.59 2.5c-1.42 0-2.6-1.16-2.6-2.6 0-1.72 1.66-3.01 3.37-2.48V9.66c-3.45-.46-6.47 2.22-6.47 5.64 0 3.33 2.76 5.7 5.69 5.7 3.14 0 5.69-2.55 5.69-5.7V9.01a7.35 7.35 0 0 0 4.3 1.38V7.3s-1.88.09-3.24-1.48z"/><path fill="#FE2C55" transform="translate(0.7 0.6)" d="M16.6 5.82s.51.5 0 0A4.278 4.278 0 0 1 15.54 3h-3.09v12.4a2.592 2.592 0 0 1-2.59 2.5c-1.42 0-2.6-1.16-2.6-2.6 0-1.72 1.66-3.01 3.37-2.48V9.66c-3.45-.46-6.47 2.22-6.47 5.64 0 3.33 2.76 5.7 5.69 5.7 3.14 0 5.69-2.55 5.69-5.7V9.01a7.35 7.35 0 0 0 4.3 1.38V7.3s-1.88.09-3.24-1.48z"/><path fill="#FFFFFF" d="M16.6 5.82s.51.5 0 0A4.278 4.278 0 0 1 15.54 3h-3.09v12.4a2.592 2.592 0 0 1-2.59 2.5c-1.42 0-2.6-1.16-2.6-2.6 0-1.72 1.66-3.01 3.37-2.48V9.66c-3.45-.46-6.47 2.22-6.47 5.64 0 3.33 2.76 5.7 5.69 5.7 3.14 0 5.69-2.55 5.69-5.7V9.01a7.35 7.35 0 0 0 4.3 1.38V7.3s-1.88.09-3.24-1.48z"/></svg>';

  const enabled = config.buttons.filter((b) => b.enabled);
  const discordBtn = enabled.find((b) => b.id === 'discord');
  const tiktokBtn = enabled.find((b) => b.id === 'tiktok');
  const gameBtn = enabled.find((b) => b.id === 'game');
  const extraBtns = enabled.filter(
    (b) => b.id !== 'discord' && b.id !== 'tiktok' && b.id !== 'game',
  );

  const normalizeUrl = (raw?: string) => {
    const trimmed = (raw || '').trim();
    if (!trimmed) return '';
    return /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
  };

  const renderPrimaryBtn = (b: typeof discordBtn, cls: string, svg: string, fallback: string) => {
    if (!b) return '';
    const rawLabel =
      b.id === 'discord' && b.label === 'سيرفر ديسكورد'
        ? fallback
        : b.id === 'tiktok' && b.label === 'حساب تيك توك'
          ? fallback
          : b.label || fallback;
    const label = escapeHtml(rawLabel);
    const url = normalizeUrl(b.url);
    const inner = `<span class="hero-btn-sheen" aria-hidden="true"></span>${svg}<span>${label}</span><span aria-hidden="true">←</span>`;
    return url
      ? `        <a class="hero-action-btn ${cls}" href="${escapeHtml(url)}" target="_blank" rel="noopener noreferrer">${inner}</a>`
      : `        <button type="button" class="hero-action-btn ${cls}" data-pending-label="${label}">${inner}</button>`;
  };

  const primaryButtonsHtml = [
    renderPrimaryBtn(discordBtn, 'discord-btn', discordSvg, 'دخول إلى ديسكورد'),
    renderPrimaryBtn(tiktokBtn, 'tiktok-btn', tiktokSvg, 'موقع التيك توك'),
  ]
    .filter(Boolean)
    .join('\n');

  const extraButtonsHtml = extraBtns
    .map((b) => {
      const label = escapeHtml(b.label);
      const icon = escapeHtml(b.icon || '🔗');
      const url = normalizeUrl(b.url);
      return url
        ? `      <a class="extra-chip" href="${escapeHtml(url)}" target="_blank" rel="noopener noreferrer"><span>${icon}</span><span>${label}</span></a>`
        : `      <button type="button" class="extra-chip" data-pending-label="${label}"><span>${icon}</span><span>${label}</span></button>`;
    })
    .join('\n');

  const gameCtaLabel = escapeHtml(
    gameBtn && gameBtn.label && gameBtn.label !== 'One City RP' ? gameBtn.label : 'دخول إلى اللعبة',
  );
  const gameUrl = normalizeUrl(gameBtn?.url);
  const gameActionHtml = gameBtn
    ? gameUrl
      ? `<a class="game-enter-btn" href="${escapeHtml(gameUrl)}" target="_blank" rel="noopener noreferrer"><span class="hero-btn-sheen" aria-hidden="true"></span><span>${gameCtaLabel}</span><span aria-hidden="true">←</span></a>`
      : `<button type="button" class="game-enter-btn" data-pending-label="${gameCtaLabel}"><span class="hero-btn-sheen" aria-hidden="true"></span><span>${gameCtaLabel}</span><span aria-hidden="true">←</span></button>`
    : '';

  return `<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover" />
  <title>${siteName}</title>
  <meta name="theme-color" content="#000000" />
  <meta name="mobile-web-app-capable" content="yes" />
  <meta name="apple-mobile-web-app-capable" content="yes" />
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
  <meta name="application-name" content="${siteName}" />
  <meta name="apple-mobile-web-app-title" content="${siteName}" />
  <link rel="icon" type="image/png" href="${logoSrc}" />
  <link rel="apple-touch-icon" href="${logoSrc}" />
  <meta name="description" content="الموقع الرسمي لمجتمع ${siteName} — بوابة الأخبار والفصائل والروابط الرسمية." />
  <meta property="og:site_name" content="${siteName}" />
  <meta property="og:title" content="${siteName}" />
  <meta property="og:description" content="الموقع الرسمي لمجتمع ${siteName} — بوابة الأخبار والفصائل والروابط الرسمية." />
  <meta property="og:type" content="website" />
  <meta name="twitter:card" content="summary_large_image" />
  <meta name="twitter:title" content="${siteName}" />
  <meta name="twitter:description" content="الموقع الرسمي لمجتمع ${siteName} — بوابة الأخبار والفصائل والروابط الرسمية." />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&family=Outfit:wght@600;700;800;900&display=swap" rel="stylesheet" />
  <style>
    :root { --neon: ${neon}; }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body { min-height: 100%; background: #000000; color: #ffffff; font-family: 'Cairo', system-ui, sans-serif; overflow-x: hidden; }
    #starfield { position: fixed; inset: 0; width: 100%; height: 100%; z-index: 0; pointer-events: none; }
    .cosmic-glow { position: fixed; inset: 0; z-index: 1; pointer-events: none; background: radial-gradient(circle at 50% 38%, ${neon}26 0%, ${neon}0d 28%, rgba(0,0,0,0) 64%); }
    .top-header { position: sticky; top: 0; z-index: 10; padding: 12px 24px; background: rgba(4,6,16,0.72); backdrop-filter: blur(12px); border-bottom: 1px solid rgba(255,255,255,0.08); display: flex; align-items: center; justify-content: space-between; }
    .brand { display: inline-flex; align-items: center; gap: 10px; font-family: 'Outfit','Cairo',sans-serif; font-weight: 800; font-size: 1rem; color: #fff; }
    .brand img { width: 34px; height: 34px; object-fit: contain; filter: drop-shadow(0 0 10px ${neon}aa); }
    main { position: relative; z-index: 2; min-height: calc(100vh - 110px); display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 32px 18px; }
    .hero-showcase { position: relative; display: flex; flex-direction: column; align-items: center; text-align: center; margin-bottom: 28px; width: 100%; max-width: 720px; }
    .hero-aura { position: absolute; inset: -32px -64px 0; border-radius: 9999px; filter: blur(42px); background: radial-gradient(circle, ${neon}55 0%, ${neon}18 50%, transparent 74%); animation: breath 4.5s ease-in-out infinite; pointer-events: none; }
    .hero-crest { position: relative; animation: crestFloat 5s ease-in-out infinite; margin-bottom: 8px; }
    .hero-crest img { width: 152px; height: 152px; object-fit: contain; filter: drop-shadow(0 0 28px ${neon}aa) drop-shadow(0 8px 20px rgba(0,0,0,0.9)); }
    .hero-title { position: relative; font-family: 'Outfit','Cairo',sans-serif; font-size: clamp(1.9rem,4.2vw,3rem); font-weight: 900; font-style: italic; text-shadow: 0 4px 24px rgba(0,0,0,0.95), 0 0 28px ${neon}80; }
    .tagline-row { position: relative; display: flex; align-items: center; justify-content: center; gap: 14px; margin-top: 12px; }
    .tagline-line { height: 2px; width: 70px; border-radius: 9999px; background: linear-gradient(90deg, transparent, ${neon}); box-shadow: 0 0 10px ${neon}; }
    .tagline-line.end { background: linear-gradient(270deg, transparent, ${neon}); }
    .tagline-text { font-size: clamp(1.1rem,2.5vw,1.48rem); font-weight: 800; white-space: nowrap; }
    .tagline-accent { color: ${neon}; text-shadow: 0 0 18px ${neon}cc; }
    .subline { position: relative; margin-top: 10px; font-size: 0.88rem; color: rgba(212,212,216,0.9); max-width: 520px; }
    .buttons-stack { width: 100%; max-width: 560px; display: flex; align-items: stretch; justify-content: center; gap: 14px; margin-bottom: 28px; }
    .hero-action-btn { position: relative; overflow: hidden; flex: 1; min-height: 50px; padding: 12px 22px; border-radius: 13px; color: #fff; text-decoration: none; font-family: inherit; font-size: 0.95rem; font-weight: 700; display: inline-flex; align-items: center; justify-content: center; gap: 10px; white-space: nowrap; cursor: pointer; transition: transform 0.2s ease; }
    .hero-action-btn:hover { transform: translateY(-3px); }
    .discord-btn { border: 1px solid ${neon}; background: linear-gradient(135deg, ${neon}, #5b21b6); animation: btnNeonPulse 2.8s ease-in-out infinite; }
    .tiktok-btn { border: 1px solid ${neon}73; background: rgba(7,10,24,0.82); backdrop-filter: blur(16px); box-shadow: 0 0 20px ${neon}28, inset 0 0 14px ${neon}18; }
    .hero-btn-sheen { position: absolute; inset-block: 0; width: 50%; background: linear-gradient(90deg, transparent, rgba(255,255,255,0.28), transparent); pointer-events: none; animation: btnSheen 3.6s ease-in-out infinite; }
    .tiktok-btn .hero-btn-sheen { animation-delay: 1.6s; }
    .extra-row { display: flex; flex-wrap: wrap; justify-content: center; gap: 10px; margin-bottom: 24px; }
    .extra-chip { display: inline-flex; align-items: center; gap: 8px; padding: 8px 16px; min-height: 42px; border-radius: 12px; background: rgba(9,9,11,0.78); border: 1px solid rgba(255,255,255,0.14); color: #fff; text-decoration: none; font-family: inherit; font-size: 0.84rem; font-weight: 700; cursor: pointer; }
    .game-card { width: 100%; max-width: 896px; border-radius: 18px; overflow: hidden; background: rgba(5,8,22,0.82); backdrop-filter: blur(18px); border: 1px solid ${neon}6b; box-shadow: 0 18px 50px rgba(0,0,0,0.72), 0 0 34px ${neon}28; }
    .game-grid { display: grid; grid-template-columns: 1.05fr 0.95fr; }
    .game-visual { position: relative; min-height: 205px; overflow: hidden; background: linear-gradient(135deg, #0d0824, #060918, #03050d); display: flex; align-items: center; justify-content: center; border-inline-end: 1px solid rgba(255,255,255,0.08); }
    .game-visual svg { position: absolute; inset-inline: 0; bottom: 0; width: 100%; height: 140px; opacity: 0.58; pointer-events: none; }
    .game-visual img { position: relative; z-index: 2; width: 132px; height: 132px; object-fit: contain; filter: drop-shadow(0 0 24px ${neon}aa); }
    .game-content { display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center; padding: 28px 24px; }
    .game-eyebrow { font-family: 'Outfit','Cairo',sans-serif; font-size: 0.7rem; font-weight: 800; letter-spacing: 0.26em; text-transform: uppercase; color: ${neon}; margin-bottom: 6px; }
    .game-heading { display: flex; align-items: center; gap: 12px; margin-bottom: 10px; }
    .game-heading h2 { font-size: 1.5rem; font-weight: 800; }
    .slashes { display: flex; gap: 4px; }
    .slash { width: 10px; height: 14px; border-radius: 2px; background: ${neon}; transform: skewX(-14deg); }
    .slash.dim { opacity: 0.55; }
    .game-desc { font-size: 0.85rem; color: rgba(212,212,216,0.9); line-height: 1.7; max-width: 340px; margin-bottom: 20px; }
    .game-enter-btn { position: relative; overflow: hidden; display: inline-flex; align-items: center; gap: 10px; min-height: 44px; padding: 10px 28px; border-radius: 9999px; border: 1px solid ${neon}; background: rgba(0,0,0,0.52); color: #fff; text-decoration: none; font-family: inherit; font-size: 0.9rem; font-weight: 700; box-shadow: 0 0 20px ${neon}38; cursor: pointer; }
    .guide-card { width: 100%; max-width: 896px; margin-top: 28px; border-radius: 18px; overflow: hidden; background: rgba(5,8,22,0.84); backdrop-filter: blur(18px); border: 1px solid rgba(255,255,255,0.1); box-shadow: 0 18px 46px rgba(0,0,0,0.68); }
    .guide-head { padding: 22px 26px; border-bottom: 1px solid rgba(255,255,255,0.08); display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 14px; }
    .guide-head h2 { font-size: clamp(1.12rem,2.4vw,1.45rem); font-weight: 800; }
    .guide-head p { margin-top: 4px; font-size: 0.83rem; color: #a1a1aa; }
    .guide-tabs { display: inline-flex; flex-wrap: wrap; gap: 6px; padding: 5px; border-radius: 12px; background: rgba(0,0,0,0.55); border: 1px solid rgba(255,255,255,0.08); }
    .guide-tab { padding: 7px 12px; min-height: 36px; border-radius: 8px; border: 1px solid transparent; background: transparent; color: #a1a1aa; font-family: inherit; font-size: 0.78rem; font-weight: 700; cursor: pointer; }
    .guide-tab.active { color: #fff; background: ${neon}36; border-color: ${neon}80; }
    .guide-body { padding: 22px 26px 26px; }
    .guide-panel { display: none; }
    .guide-panel.active { display: block; }
    .guide-lead { font-size: 0.94rem; color: #e4e4e7; line-height: 1.75; margin-bottom: 18px; padding-bottom: 16px; border-bottom: 1px solid rgba(255,255,255,0.07); }
    .guide-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 14px; }
    .guide-item { padding: 16px; border-radius: 14px; background: rgba(255,255,255,0.025); border: 1px solid rgba(255,255,255,0.08); }
    .guide-item-head { display: flex; align-items: baseline; justify-content: space-between; gap: 8px; margin-bottom: 6px; }
    .guide-item h3 { font-size: 0.94rem; font-weight: 700; }
    .guide-num { font-family: 'Outfit', monospace; font-size: 0.78rem; font-weight: 800; color: ${neon}; }
    .guide-item p { font-size: 0.82rem; color: #a1a1aa; line-height: 1.65; }
    .site-footer { position: relative; z-index: 2; padding: 18px 24px; display: flex; align-items: center; justify-content: center; gap: 14px; font-family: 'Outfit','Cairo',sans-serif; font-size: 0.74rem; font-weight: 800; letter-spacing: 0.28em; text-transform: uppercase; color: ${neon}; }
    .footer-line { height: 1px; width: 64px; background: linear-gradient(90deg, transparent, ${neon}99); }
    .footer-line.end { background: linear-gradient(270deg, transparent, ${neon}99); }
    .toast { position: fixed; bottom: 24px; left: 50%; transform: translateX(-50%); z-index: 20; padding: 12px 20px; border-radius: 12px; background: rgba(9,9,11,0.95); border: 1px solid ${neon}80; box-shadow: 0 0 24px ${neon}44; color: #fff; font-size: 0.85rem; font-weight: 600; display: none; }
    @keyframes breath { 0%,100%{transform:scale(1);opacity:.78} 50%{transform:scale(1.03);opacity:1} }
    @keyframes crestFloat { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-8px)} }
    @keyframes btnSheen { 0%{transform:translateX(-160%) skewX(-18deg)} 55%,100%{transform:translateX(260%) skewX(-18deg)} }
    @keyframes btnNeonPulse { 0%,100%{box-shadow:0 0 18px ${neon}55,inset 0 0 12px ${neon}26} 50%{box-shadow:0 0 32px ${neon}99,inset 0 0 20px ${neon}44} }
    @media (max-width: 720px) { .game-grid, .guide-grid { grid-template-columns: 1fr; } .game-visual { min-height: 165px; border-inline-end: none; border-bottom: 1px solid rgba(255,255,255,0.08); } }
    @media (max-width: 600px) { .buttons-stack { flex-direction: column; max-width: 340px; } .tagline-line { width: 34px; } }
    @media (prefers-reduced-motion: reduce) { .hero-aura, .hero-crest, .hero-btn-sheen, .discord-btn { animation: none !important; } }
  </style>
</head>
<body>
  <canvas id="starfield"></canvas>
  <div class="cosmic-glow"></div>
  <header class="top-header">
    <div class="brand">
      <img src="${logoSrc}" alt="${siteName}" referrerpolicy="no-referrer" />
      <span>${siteName}</span>
    </div>
  </header>
  <main>
    <div class="hero-showcase">
      <div class="hero-aura"></div>
      <div class="hero-crest">
        <img src="${logoSrc}" alt="${siteName}" referrerpolicy="no-referrer" />
      </div>
      <h1 class="hero-title">${siteName}</h1>
      <div class="tagline-row">
        <span class="tagline-line" aria-hidden="true"></span>
        <p class="tagline-text">مدينتك .. <span class="tagline-accent">قصتك</span> .. عالمك</p>
        <span class="tagline-line end" aria-hidden="true"></span>
      </div>
      <p class="subline">${sublineText}</p>
    </div>
    <nav class="buttons-stack" aria-label="${siteName}">
${primaryButtonsHtml}
    </nav>
    ${extraButtonsHtml ? `<div class="extra-row">\n${extraButtonsHtml}\n    </div>` : ''}
    ${
      gameBtn
        ? `<section class="game-card" aria-label="موقع اللعبة">
      <div class="game-grid">
        <div class="game-visual">
          <svg viewBox="0 0 600 220" preserveAspectRatio="none" aria-hidden="true">
            <path d="M0 220V165h28v-35h22v35h16V98h34v67h18v-48h26v48h20V72h42v93h16v-55h30v55h22V86h36v79h18v-42h28v42h20V60h40v105h18v-44h28v44h22v-65h34v65h24v-28h30v55H0Z" fill="#090d1f"/>
            <path d="M0 206h600" stroke="${neon}" stroke-width="2" stroke-opacity="0.65"/>
          </svg>
          <img src="${logoSrc}" alt="" aria-hidden="true" />
        </div>
        <div class="game-content">
          <span class="game-eyebrow">${siteName}</span>
          <div class="game-heading">
            <span class="slashes" aria-hidden="true"><span class="slash"></span><span class="slash dim"></span></span>
            <h2>موقع اللعبة</h2>
            <span class="slashes" aria-hidden="true"><span class="slash dim"></span><span class="slash"></span></span>
          </div>
          <p class="game-desc">ادخل إلى عالم One City RP الآن وابدأ رحلتك في مدينة متكاملة مليئة بالحياة، الأدوار، والمغامرات.</p>
          ${gameActionHtml}
        </div>
      </div>
    </section>`
        : ''
    }
    <section class="guide-card" aria-label="شرح اللعبة">
      <div class="guide-head">
        <div>
          <h2>شرح لعبة ${siteName}</h2>
          <p>دليل شامل يشرح فكرة السيرفر، خطوات البدء، قوانين الرول بلاي، ومسارات اللعب المتاحة.</p>
        </div>
        <div class="guide-tabs" role="tablist">
          <button type="button" class="guide-tab active" data-gtab="overview">عن اللعبة</button>
          <button type="button" class="guide-tab" data-gtab="start">كيف تبدأ</button>
          <button type="button" class="guide-tab" data-gtab="rules">القوانين الأساسية</button>
          <button type="button" class="guide-tab" data-gtab="careers">الوظائف والمسارات</button>
        </div>
      </div>
      <div class="guide-body">
        <div class="guide-panel active" data-gpanel="overview">
          <p class="guide-lead">One City RP هي مدينة حياة واقعية (Roleplay) يعيش فيها كل لاعب دور شخصية متكاملة بقصة ومسيرة ومهنة خاصة، ضمن مجتمع متفاعل وأنظمة تحاكي الواقع في العمل، القانون، التجارة، والمغامرات.</p>
          <div class="guide-grid">
            <div class="guide-item"><div class="guide-item-head"><h3><span class="guide-num">01.</span> تقمص الأدوار الواقعي</h3></div><p>تصنع اسم شخصيتك وتاريخها وتتصرف داخل المدينة بواقعية تامة مع بقية اللاعبين في كل موقف.</p></div>
            <div class="guide-item"><div class="guide-item-head"><h3><span class="guide-num">02.</span> اقتصاد ووظائف متنوعة</h3></div><p>نظام مالي متوازن يتيح لك العمل، امتلاك المركبات والمشاريع، وتطوير مستواك خطوة بخطوة.</p></div>
            <div class="guide-item"><div class="guide-item-head"><h3><span class="guide-num">03.</span> فصائل وقطاعات رسمية</h3></div><p>انضم للشرطة أو الإسعاف أو الجيش عبر تدرج إداري منظم وقيادة متفاعلة داخل السيرفر.</p></div>
            <div class="guide-item"><div class="guide-item-head"><h3><span class="guide-num">04.</span> مجتمع وفعاليات مستمرة</h3></div><p>تحديثات دورية، قصص مدينة متجددة، ودعم فني مستمر عبر سيرفر الديسكورد الرسمي.</p></div>
          </div>
        </div>
        <div class="guide-panel" data-gpanel="start">
          <div class="guide-grid">
            <div class="guide-item"><div class="guide-item-head"><h3><span class="guide-num">01</span> الانضمام إلى الديسكورد الرسمي</h3></div><p>ابدأ بالدخول إلى سيرفر الديسكورد من الزر في الأعلى لمتابعة القوانين والإعلانات وحالة التقديم.</p></div>
            <div class="guide-item"><div class="guide-item-head"><h3><span class="guide-num">02</span> قراءة القوانين وإتمام التفعيل</h3></div><p>اطّلع على قواعد الحياة الواقعية في الروم المخصص، ثم قدّم طلب التفعيل أو أجب عن الأسئلة الأساسية.</p></div>
            <div class="guide-item"><div class="guide-item-head"><h3><span class="guide-num">03</span> تجهيز قصة وشخصية RP</h3></div><p>اختر اسماً واقعياً لشخصيتك وحدّد خلفيتها وطموحها قبل الدخول.</p></div>
            <div class="guide-item"><div class="guide-item-head"><h3><span class="guide-num">04</span> الدخول إلى المدينة والانطلاق</h3></div><p>استخدم زر «دخول إلى اللعبة» للانضمام للسيرفر، احصل على وظيفتك الأولى وابدأ ببناء قصتك.</p></div>
          </div>
        </div>
        <div class="guide-panel" data-gpanel="rules">
          <div class="guide-grid">
            <div class="guide-item"><div class="guide-item-head"><h3>الالتزام بالشخصية (IC)</h3><span class="guide-num">RP / IC & OOC</span></div><p>كل ما يحدث داخل المدينة يعتبر واقعياً؛ يُمنع التحدث بأمور خارج اللعبة (OOC) عبر الصوت العام.</p></div>
            <div class="guide-item"><div class="guide-item-head"><h3>تقدير الحياة</h3><span class="guide-num">Fear RP</span></div><p>عند تعرض شخصيتك للتهديد المباشر بالسلاح أو الخطر، يجب التصرف بخوف واقعي وعدم الاستهتار بالحياة.</p></div>
            <div class="guide-item"><div class="guide-item-head"><h3>منع القتل والدهس العشوائي</h3><span class="guide-num">RDM / VDM</span></div><p>يُمنع قتل اللاعبين أو دهسهم بالمركبات بدون سبب رول بلاي منطقي وتدرج واضح بالسيناريو.</p></div>
            <div class="guide-item"><div class="guide-item-head"><h3>منع الميتا والباور جيمنج</h3><span class="guide-num">MG / PG</span></div><p>يُمنع استخدام معلومات من البثوث أو الديسكورد داخل اللعب، كما يمنع فرض أفعال غير واقعية.</p></div>
          </div>
        </div>
        <div class="guide-panel" data-gpanel="careers">
          <div class="guide-grid">
            <div class="guide-item"><div class="guide-item-head"><h3>الشرطة والجيش</h3><span class="guide-num">الأمن والدفاع</span></div><p>حفظ الأمن، تنظيم الدوريات، حماية الحدود والمناطق الحساسة، وملاحقة الخارجين عن القانون باحترافية.</p></div>
            <div class="guide-item"><div class="guide-item-head"><h3>قطاع الطب والإسعاف</h3><span class="guide-num">الصحة والإنقاذ</span></div><p>الاستجابة السريعة للبلاغات الطبية، إسعاف المصابين، وإدارة المستشفى بكوادر طبية متخصصة.</p></div>
            <div class="guide-item"><div class="guide-item-head"><h3>التجارة والوظائف المدنية</h3><span class="guide-num">الأعمال الحرة</span></div><p>العمل في النقل، الميكانيكا، الخدمات اللوجستية، أو إدارة المتاجر والمشاريع لبناء ثروة نظيفة.</p></div>
            <div class="guide-item"><div class="guide-item-head"><h3>المسار غير القانوني</h3><span class="guide-num">العصابات</span></div><p>تشكيل تحالفات وسيناريوهات تخطيط متكاملة تخضع لقوانين الاشتباك والمفاوضات داخل المدينة.</p></div>
          </div>
        </div>
      </div>
    </section>
  </main>
  <footer class="site-footer">
    <span class="footer-line" aria-hidden="true"></span>
    <span>${siteName}</span>
    <span class="footer-line end" aria-hidden="true"></span>
  </footer>
  <div id="toast" class="toast" role="status"></div>
  <script>
    (function () {
      var canvas = document.getElementById('starfield');
      var ctx = canvas.getContext('2d');
      var reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      var w = (canvas.width = window.innerWidth);
      var h = (canvas.height = window.innerHeight);
      var count = Math.min(220, Math.max(95, Math.floor((w * h) / 7500)));
      var stars = Array.from({ length: count }, function () {
        var layer = Math.random();
        return {
          x: Math.random() * w,
          y: Math.random() * h,
          r: layer < 0.65 ? 0.8 + Math.random() * 0.7 : 1.4 + Math.random() * 1.1,
          a: 0.25 + Math.random() * 0.75,
          da: (Math.random() * 0.014 + 0.004) * (Math.random() > 0.5 ? 1 : -1),
          vx: (Math.random() - 0.5) * (layer < 0.65 ? 0.14 : 0.3),
          vy: -(0.08 + Math.random() * (layer < 0.65 ? 0.18 : 0.36))
        };
      });
      function draw() {
        ctx.fillStyle = '#000000';
        ctx.fillRect(0, 0, w, h);
        for (var i = 0; i < stars.length; i++) {
          var s = stars[i];
          if (!reduced) {
            s.x += s.vx;
            s.y += s.vy;
            s.a += s.da;
            if (s.a >= 1 || s.a <= 0.18) s.da *= -1;
            if (s.y < -4) { s.y = h + 4; s.x = Math.random() * w; }
            if (s.x < -4) s.x = w + 4;
            if (s.x > w + 4) s.x = -4;
          }
          ctx.beginPath();
          ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
          ctx.fillStyle = 'rgba(255,255,255,' + s.a.toFixed(3) + ')';
          ctx.fill();
        }
        if (!reduced) requestAnimationFrame(draw);
      }
      window.addEventListener('resize', function () {
        w = canvas.width = window.innerWidth;
        h = canvas.height = window.innerHeight;
        if (reduced) draw();
      });
      draw();

      var toast = document.getElementById('toast');
      var toastTimer;
      document.querySelectorAll('[data-pending-label]').forEach(function (btn) {
        btn.addEventListener('click', function () {
          toast.textContent = 'سيتم تفعيل رابط "' + btn.getAttribute('data-pending-label') + '" قريباً — ترقبوا التحديث.';
          toast.style.display = 'block';
          clearTimeout(toastTimer);
          toastTimer = setTimeout(function () { toast.style.display = 'none'; }, 3000);
        });
      });

      document.querySelectorAll('[data-gtab]').forEach(function (tabBtn) {
        tabBtn.addEventListener('click', function () {
          var target = tabBtn.getAttribute('data-gtab');
          document.querySelectorAll('[data-gtab]').forEach(function (b) { b.classList.remove('active'); });
          document.querySelectorAll('[data-gpanel]').forEach(function (p) {
            p.classList.toggle('active', p.getAttribute('data-gpanel') === target);
          });
          tabBtn.classList.add('active');
        });
      });
    })();
  </script>
</body>
</html>`;
}
