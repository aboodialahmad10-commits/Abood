import { BotInfo, DEFAULT_LOGO_PATH, LEGACY_LOGO_PATH, SiteConfig } from '../types';
import { resolveLogoAsDataUri } from './exportHtml';

interface ZipEntryInput {
  path: string;
  data: Uint8Array;
}

const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) {
      c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    table[n] = c >>> 0;
  }
  return table;
})();

function crc32(bytes: Uint8Array): number {
  let crc = 0xffffffff;
  for (let i = 0; i < bytes.length; i++) {
    crc = CRC_TABLE[(crc ^ bytes[i]) & 0xff] ^ (crc >>> 8);
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function buildZip(entries: ZipEntryInput[]): Blob {
  const encoder = new TextEncoder();
  const localChunks: Uint8Array[] = [];
  const centralChunks: Uint8Array[] = [];
  let offset = 0;

  for (const entry of entries) {
    const nameBytes = encoder.encode(entry.path);
    const data = entry.data;
    const crc = crc32(data);

    // Local file header (30 bytes + filename)
    const localHeader = new Uint8Array(30 + nameBytes.length);
    const lv = new DataView(localHeader.buffer);
    lv.setUint32(0, 0x04034b50, true); // signature
    lv.setUint16(4, 20, true); // version needed
    lv.setUint16(6, 0x0800, true); // UTF-8 filename flag
    lv.setUint16(8, 0, true); // compression: STORE (0)
    lv.setUint16(10, 0, true); // mod time
    lv.setUint16(12, 0x5421, true); // mod date
    lv.setUint32(14, crc, true);
    lv.setUint32(18, data.length, true);
    lv.setUint32(22, data.length, true);
    lv.setUint16(26, nameBytes.length, true);
    lv.setUint16(28, 0, true); // extra len
    localHeader.set(nameBytes, 30);

    localChunks.push(localHeader, data);

    // Central directory header (46 bytes + filename)
    const centralHeader = new Uint8Array(46 + nameBytes.length);
    const cv = new DataView(centralHeader.buffer);
    cv.setUint32(0, 0x02014b50, true);
    cv.setUint16(4, 20, true);
    cv.setUint16(6, 20, true);
    cv.setUint16(8, 0x0800, true);
    cv.setUint16(10, 0, true);
    cv.setUint16(12, 0, true);
    cv.setUint16(14, 0x5421, true);
    cv.setUint32(16, crc, true);
    cv.setUint32(20, data.length, true);
    cv.setUint32(24, data.length, true);
    cv.setUint16(28, nameBytes.length, true);
    cv.setUint16(30, 0, true);
    cv.setUint16(32, 0, true);
    cv.setUint16(34, 0, true);
    cv.setUint16(36, 0, true);
    cv.setUint32(38, 0, true);
    cv.setUint32(42, offset, true);
    centralHeader.set(nameBytes, 46);

    centralChunks.push(centralHeader);
    offset += localHeader.length + data.length;
  }

  let centralSize = 0;
  for (const chunk of centralChunks) centralSize += chunk.length;

  const eocd = new Uint8Array(22);
  const ev = new DataView(eocd.buffer);
  ev.setUint32(0, 0x06054b50, true);
  ev.setUint16(4, 0, true);
  ev.setUint16(6, 0, true);
  ev.setUint16(8, entries.length, true);
  ev.setUint16(10, entries.length, true);
  ev.setUint32(12, centralSize, true);
  ev.setUint32(16, offset, true);
  ev.setUint16(20, 0, true);

  const parts = [...localChunks, ...centralChunks, eocd] as BlobPart[];
  return new Blob(parts, { type: 'application/zip' });
}

function buildConfigJs(siteConfig: SiteConfig, botInfo: BotInfo, resolvedLogoUrl: string): string {
  const exportedConfig: SiteConfig = {
    siteName: siteConfig.siteName || 'One City RP',
    siteSubtitle: siteConfig.siteSubtitle || '',
    logoUrl: resolvedLogoUrl,
    neonColor: siteConfig.neonColor || '#a855f7',
    welcomeMessages: siteConfig.welcomeMessages,
    buttons: siteConfig.buttons,
  };

  const exportedBot: BotInfo = {
    news: botInfo.news,
    factions: botInfo.factions,
  };

  return `export const FIREBASE_CONFIG = {
  projectId: 'restful-subject-jmn89',
  appId: '1:1056900357351:web:2ed1df0ea7bbce5a9b9642',
  apiKey: 'AIzaSyByekX1Gip_KiMAme7WC4_rlOkHpe3tSoE',
  authDomain: 'restful-subject-jmn89.firebaseapp.com',
  firestoreDatabaseId: 'ai-studio-6005a356-06a5-43ca-b9b0-f4178128a37a',
  storageBucket: 'restful-subject-jmn89.firebasestorage.app',
  messagingSenderId: '1056900357351',
};

export const SUPER_ADMIN_EMAIL = 'aboodialahmad10@gmail.com';
export const AI_API_ENDPOINT = '';
export const DEFAULT_LOGO_PATH = './assets/logo.png';

export const DEFAULT_SITE_CONFIG = ${JSON.stringify(exportedConfig, null, 2)};

export const DEFAULT_BOT_INFO = ${JSON.stringify(exportedBot, null, 2)};
`;
}

export async function exportStandaloneProjectZip(
  siteConfig: SiteConfig,
  botInfo: BotInfo,
): Promise<Blob> {
  const encoder = new TextEncoder();
  const textPaths = [
    'index.html',
    'manifest.json',
    'sw.js',
    'css/style.css',
    'js/i18n.js',
    'js/starfield.js',
    'js/ai.js',
    'js/app.js',
    'README.md',
  ];

  const entries: ZipEntryInput[] = [];

  for (const relPath of textPaths) {
    const res = await fetch(`/standalone/${relPath}`);
    if (!res.ok) {
      throw new Error(`Failed to bundle ${relPath}`);
    }
    const content = await res.text();
    entries.push({
      path: `OneCityRP/${relPath}`,
      data: encoder.encode(content),
    });
  }

  const binaryAssetPaths = [
    'assets/logo.png',
    'assets/pwa-192x192.png',
    'assets/pwa-512x512.png',
    'assets/pwa-maskable-512x512.png',
    'assets/apple-touch-icon.png',
  ];

  for (const assetRel of binaryAssetPaths) {
    const assetRes = await fetch(`/standalone/${assetRel}`);
    if (assetRes.ok) {
      const assetBuf = new Uint8Array(await assetRes.arrayBuffer());
      entries.push({
        path: `OneCityRP/${assetRel}`,
        data: assetBuf,
      });
    }
  }

  // Preserve custom uploaded logo or external URL cleanly
  const rawLogo = (siteConfig.logoUrl || '').trim();
  const isDefaultLogo =
    !rawLogo ||
    rawLogo === DEFAULT_LOGO_PATH ||
    rawLogo === LEGACY_LOGO_PATH ||
    rawLogo.startsWith('/assets/aistudio/') ||
    rawLogo.startsWith('/src/assets/images/');
  const exportedLogo = isDefaultLogo ? './assets/logo.png' : await resolveLogoAsDataUri(rawLogo);

  const configContent = buildConfigJs(siteConfig, botInfo, exportedLogo);
  entries.push({
    path: 'OneCityRP/js/config.js',
    data: encoder.encode(configContent),
  });

  return buildZip(entries);
}
