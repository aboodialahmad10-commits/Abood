import { Shield } from 'lucide-react';
import { Language, TRANSLATIONS } from '../i18n';
import { FactionItem } from '../types';

interface FactionsSectionProps {
  factions: FactionItem[];
  neonColor: string;
  lang: Language;
}

const DEFAULT_FACTION_EN: Record<string, { name: string; description: string; arName: string; arDesc: string }> = {
  police: {
    arName: 'الشرطة',
    name: 'Police Department',
    arDesc: 'حفظ الأمن والنظام داخل المدينة وملاحقة الخارجين عن القانون.',
    description: 'Maintaining law and order in the city and responding to emergencies.',
  },
  ems: {
    arName: 'الطب',
    name: 'Medical Services (EMS)',
    arDesc: 'تقديم الإسعافات الأولية والرعاية الطبية العاجلة لجميع المواطنين.',
    description: 'Providing rapid emergency response and medical care for all citizens.',
  },
  army: {
    arName: 'الجيش',
    name: 'Armed Forces',
    arDesc: 'حماية الحدود والمناطق الاستراتيجية ومساندة القوات الأمنية.',
    description: 'Protecting borders, strategic zones, and supporting security forces.',
  },
};

export function FactionsSection({ factions, neonColor, lang }: FactionsSectionProps) {
  const t = TRANSLATIONS[lang];

  return (
    <section
      aria-label={t.factionsTitle}
      className="w-full max-w-3xl mx-auto rounded-2xl border bg-zinc-950/85 backdrop-blur-xl p-5 sm:p-6 space-y-5"
      style={{
        borderColor: `${neonColor}44`,
        boxShadow: `0 12px 42px rgba(0,0,0,0.55), 0 0 32px ${neonColor}1e`,
      }}
    >
      <div className="flex items-center justify-between gap-3 border-b border-white/10 pb-4">
        <div className="flex items-center gap-3">
          <div
            className="w-9 h-9 rounded-xl flex items-center justify-center border shrink-0"
            style={{
              borderColor: `${neonColor}44`,
              backgroundColor: `${neonColor}18`,
            }}
          >
            <Shield className="w-4 h-4 shrink-0" style={{ color: neonColor }} />
          </div>
          <h2 className="text-base sm:text-lg font-bold text-white text-balance">{t.factionsTitle}</h2>
        </div>
        <span className="text-xs font-mono tabular-nums text-zinc-400 whitespace-nowrap">
          {factions.length} {t.factionsCountUnit}
        </span>
      </div>

      {factions.length === 0 ? (
        <div className="py-12 text-center space-y-2">
          <Shield className="w-8 h-8 text-zinc-600 mx-auto" />
          <p className="text-sm text-zinc-400">{t.factionsEmpty}</p>
        </div>
      ) : (
        <div className="clean-scroll grid grid-cols-1 sm:grid-cols-2 gap-3.5 max-h-[60vh] overflow-y-auto px-1">
          {factions.map((faction) => {
            const statusColor =
              faction.status === 'مفتوح'
                ? 'text-emerald-400'
                : faction.status === 'مغلق'
                ? 'text-rose-400'
                : 'text-amber-400';
            const statusGlyph =
              faction.status === 'مفتوح' ? '●' : faction.status === 'مغلق' ? '✖' : '▲';
            const statusText = t.statusMap[faction.status] || faction.status;

            const enMatch = lang === 'en' ? DEFAULT_FACTION_EN[faction.id] : undefined;
            const displayName =
              enMatch && faction.name === enMatch.arName ? enMatch.name : faction.name;
            const displayDesc =
              enMatch && faction.description === enMatch.arDesc
                ? enMatch.description
                : faction.description;

            return (
              <div
                key={faction.id}
                className="p-4 rounded-xl bg-black/55 border border-white/[0.08] space-y-2.5 flex flex-col justify-between"
              >
                <div className="flex items-start justify-between gap-2.5">
                  <div className="flex items-center gap-3 min-w-0">
                    <span
                      className="w-10 h-10 rounded-xl bg-white/[0.04] border border-white/10 flex items-center justify-center text-xl leading-none shrink-0"
                      aria-hidden="true"
                    >
                      {faction.icon}
                    </span>
                    <h3 className="text-sm sm:text-base font-bold text-white truncate">
                      {displayName}
                    </h3>
                  </div>
                  <span
                    className={`text-xs font-bold whitespace-nowrap shrink-0 pt-1 ${statusColor}`}
                  >
                    {statusGlyph} {t.applyStatusPrefix} {statusText}
                  </span>
                </div>
                {displayDesc && (
                  <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed">
                    {displayDesc}
                  </p>
                )}
              </div>
            );
          })}
        </div>
      )}
    </section>
  );
}
