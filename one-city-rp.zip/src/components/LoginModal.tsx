import React, { useState } from 'react';
import {
  createUserWithEmailAndPassword,
  sendEmailVerification,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signInWithPopup,
  signInWithRedirect,
  updateProfile,
} from 'firebase/auth';
import { Eye, EyeOff, Lock, Mail, User as UserIcon, X } from 'lucide-react';
import { auth, googleProvider } from '../firebase';
import { Language } from '../i18n';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess?: (info?: { emailVerificationPending?: boolean; username?: string }) => void;
  neonColor: string;
  lang: Language;
}

function getAuthErrorCode(error: unknown): string {
  return typeof error === 'object' && error !== null && 'code' in error
    ? String((error as { code: unknown }).code)
    : '';
}

function isInsideIframe(): boolean {
  try {
    return window.self !== window.top;
  } catch {
    return true;
  }
}

function canUseRedirectFallback(): boolean {
  return window.location.protocol.startsWith('http') && !isInsideIframe();
}

function mapFirebaseAuthError(error: unknown, lang: Language): string {
  const code = getAuthErrorCode(error);
  const ar = lang === 'ar';

  switch (code) {
    case 'auth/invalid-credential':
    case 'auth/wrong-password':
    case 'auth/user-not-found':
      return ar
        ? 'البريد الإلكتروني أو كلمة المرور غير صحيحة.'
        : 'Invalid email or password.';
    case 'auth/invalid-email':
      return ar
        ? 'يرجى إدخال بريد إلكتروني صحيح.'
        : 'Please enter a valid email address.';
    case 'auth/email-already-in-use':
      return ar
        ? 'يوجد حساب مسجل بهذا البريد الإلكتروني بالفعل. يمكنك تسجيل الدخول أو استعادة كلمة المرور.'
        : 'An account with this email already exists. Try signing in or resetting your password.';
    case 'auth/weak-password':
      return ar
        ? 'كلمة المرور ضعيفة جداً — يجب أن تتكون من 6 أحرف على الأقل.'
        : 'Password must be at least 6 characters.';
    case 'auth/too-many-requests':
      return ar
        ? 'محاولات كثيرة جداً خلال وقت قصير. يرجى الانتظار قليلاً ثم المحاولة مجدداً.'
        : 'Too many attempts. Please wait a moment and try again.';
    case 'auth/user-disabled':
      return ar
        ? 'تم تعطيل هذا الحساب مؤقتاً من قبل الإدارة.'
        : 'This account has been disabled.';
    case 'auth/operation-not-allowed':
      return ar
        ? 'مزوّد البريد وكلمة المرور غير مفعّل في مشروع Firebase حتى الآن. فعّل خيار Email/Password من إعدادات Firebase بالأسفل، أو سجّل الدخول مباشرة باستخدام زر Google.'
        : 'Email/Password sign-in is disabled in Firebase Console. Enable Email/Password below, or sign in immediately with Google.';
    case 'auth/popup-blocked':
      return ar
        ? 'المتصفح منع فتح نافذة تسجيل الدخول عبر Google. افتح الصفحة في نافذة متصفح مستقلة أو اسمح بالنوافذ المنبثقة ثم حاول مجدداً.'
        : 'Popup was blocked by your browser. Open in a standalone browser tab or allow popups and try again.';
    case 'auth/popup-closed-by-user':
    case 'auth/cancelled-popup-request':
      return ar
        ? 'تم إغلاق نافذة Google قبل إكمال تسجيل الدخول. حاول مرة أخرى.'
        : 'Google sign-in window was closed before completing sign-in. Please try again.';
    case 'auth/unauthorized-domain':
      return ar
        ? `النطاق "${window.location.hostname}" غير مضاف في Authorized domains داخل إعدادات Firebase.`
        : `Domain "${window.location.hostname}" is not authorized in Firebase Console -> Authentication -> Settings -> Authorized domains.`;
    case 'auth/operation-not-supported-in-this-environment':
      return ar
        ? 'يرجى فتح الموقع عبر HTTPS في متصفح Chrome أو Safari لإكمال تسجيل الدخول.'
        : 'Please open the site in Chrome or Safari over HTTPS (not file://) to sign in.';
    case 'auth/network-request-failed':
      return ar
        ? 'تعذر الاتصال بالشبكة. تأكد من اتصالك بالإنترنت وحاول مرة أخرى.'
        : 'Network error. Please check your internet connection and try again.';
    case 'auth/internal-error':
      return ar
        ? 'المتصفح حظر نافذة Google داخل المعاينة المدمجة — اضغط الزر أدناه لفتح الصفحة في المتصفح وإكمال الدخول بـ Google.'
        : 'Browser blocked Google sign-in inside the embedded preview frame. Tap below to open in a browser tab.';
    default: {
      const raw = error instanceof Error ? error.message : '';
      if (raw) return code ? `${raw} (${code})` : raw;
      return ar ? 'فشل تسجيل الدخول. يرجى المحاولة مرة أخرى.' : 'Authentication failed. Please try again.';
    }
  }
}

export function LoginModal({
  isOpen,
  onClose,
  onLoginSuccess,
  neonColor,
  lang,
}: LoginModalProps) {
  const [mode, setMode] = useState<'signin' | 'signup'>('signin');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [resetLoading, setResetLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [errorCode, setErrorCode] = useState<string>('');
  const [infoMsg, setInfoMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const isAr = lang === 'ar';

  const switchMode = (nextMode: 'signin' | 'signup') => {
    setMode(nextMode);
    setErrorMsg(null);
    setErrorCode('');
    setInfoMsg(null);
  };

  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setInfoMsg(null);

    const cleanEmail = email.trim().toLowerCase();
    const cleanUsername = username.trim().slice(0, 32);

    if (mode === 'signup' && cleanUsername.length < 2) {
      setErrorMsg(
        isAr
          ? 'يجب أن يتكون اسم المستخدم من حرفين على الأقل.'
          : 'Username must be at least 2 characters.',
      );
      return;
    }
    if (!cleanEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      setErrorMsg(
        isAr ? 'يرجى إدخال بريد إلكتروني صحيح.' : 'Please enter a valid email address.',
      );
      return;
    }
    if (password.length < 6) {
      setErrorMsg(
        isAr
          ? 'كلمة المرور يجب أن تكون 6 أحرف على الأقل.'
          : 'Password must be at least 6 characters.',
      );
      return;
    }

    setErrorCode('');
    setLoading(true);
    try {
      if (mode === 'signin') {
        const cred = await signInWithEmailAndPassword(auth, cleanEmail, password);
        onLoginSuccess?.({ emailVerificationPending: !cred.user.emailVerified });
        onClose();
      } else {
        const cred = await createUserWithEmailAndPassword(auth, cleanEmail, password);
        try {
          window.localStorage.setItem(`onecity_pending_username_${cred.user.uid}`, cleanUsername);
        } catch {
          // Ignore storage error
        }
        try {
          await updateProfile(cred.user, { displayName: cleanUsername });
          await cred.user.reload();
        } catch {
          // Non-fatal if profile update fails
        }
        try {
          await sendEmailVerification(cred.user);
          setInfoMsg(
            isAr
              ? 'تم إنشاء الحساب وإرسال رابط التفعيل إلى بريدك الإلكتروني.'
              : 'Account created! A verification link has been sent to your email.',
          );
        } catch {
          setInfoMsg(
            isAr ? 'تم إنشاء الحساب بنجاح.' : 'Account created successfully.',
          );
        }
        onLoginSuccess?.({
          emailVerificationPending: !cred.user.emailVerified,
          username: cleanUsername,
        });
        onClose();
      }
    } catch (error) {
      setErrorCode(getAuthErrorCode(error));
      setErrorMsg(mapFirebaseAuthError(error, lang));
    } finally {
      setLoading(false);
    }
  };

  const handlePasswordReset = async () => {
    setErrorMsg(null);
    setErrorCode('');
    setInfoMsg(null);
    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      setErrorMsg(
        isAr
          ? 'اكتب بريدك الإلكتروني في الحقل أولاً لإرسال رابط استعادة كلمة المرور.'
          : 'Enter your email above first to receive a password reset link.',
      );
      return;
    }
    setResetLoading(true);
    try {
      await sendPasswordResetEmail(auth, cleanEmail);
      setInfoMsg(
        isAr
          ? 'تم إرسال رابط إعادة تعيين كلمة المرور إلى بريدك الإلكتروني.'
          : 'Password reset link sent to your email inbox.',
      );
    } catch (error) {
      setErrorCode(getAuthErrorCode(error));
      setErrorMsg(mapFirebaseAuthError(error, lang));
    } finally {
      setResetLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setErrorMsg(null);
    setErrorCode('');
    setInfoMsg(null);
    setGoogleLoading(true);
    try {
      await signInWithPopup(auth, googleProvider);
      onLoginSuccess?.({ emailVerificationPending: false });
      onClose();
    } catch (error) {
      console.error('Google Sign-In error:', error);
      const code = getAuthErrorCode(error);
      if (
        (code === 'auth/popup-blocked' ||
          code === 'auth/operation-not-supported-in-this-environment' ||
          code === 'auth/internal-error' ||
          code === 'auth/cancelled-popup-request') &&
        canUseRedirectFallback()
      ) {
        try {
          await signInWithRedirect(auth, googleProvider);
          return;
        } catch (redirectError) {
          setErrorCode(getAuthErrorCode(redirectError));
          setErrorMsg(mapFirebaseAuthError(redirectError, lang));
          return;
        }
      }
      setErrorCode(code);
      setErrorMsg(mapFirebaseAuthError(error, lang));
    } finally {
      setGoogleLoading(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md"
      role="dialog"
      aria-modal="true"
      aria-label={mode === 'signin' ? (isAr ? 'تسجيل الدخول' : 'Sign In') : isAr ? 'إنشاء حساب' : 'Create Account'}
    >
      <div
        dir={isAr ? 'rtl' : 'ltr'}
        className="relative w-full max-w-sm rounded-2xl border bg-zinc-950/95 p-6 text-white shadow-2xl"
        style={{
          borderColor: `${neonColor}55`,
          boxShadow: `0 0 42px ${neonColor}2e`,
        }}
      >
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display text-xl font-bold tracking-tight text-white">
            {mode === 'signin'
              ? isAr
                ? 'تسجيل الدخول'
                : 'Sign In'
              : isAr
              ? 'إنشاء حساب جديد'
              : 'Create Account'}
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label={isAr ? 'إغلاق' : 'Close'}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-900 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Clear Mode Switch Tabs */}
        <div className="grid grid-cols-2 gap-1.5 p-1 rounded-xl bg-black border border-zinc-800 mb-4">
          <button
            type="button"
            onClick={() => switchMode('signin')}
            className={`py-2 px-3 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              mode === 'signin' ? 'text-white' : 'text-zinc-400 hover:text-white'
            }`}
            style={
              mode === 'signin'
                ? { backgroundColor: neonColor, boxShadow: `0 0 14px ${neonColor}44` }
                : undefined
            }
          >
            {isAr ? 'تسجيل الدخول' : 'Sign In'}
          </button>
          <button
            type="button"
            onClick={() => switchMode('signup')}
            className={`py-2 px-3 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              mode === 'signup' ? 'text-white' : 'text-zinc-400 hover:text-white'
            }`}
            style={
              mode === 'signup'
                ? { backgroundColor: neonColor, boxShadow: `0 0 14px ${neonColor}44` }
                : undefined
            }
          >
            {isAr ? 'إنشاء حساب' : 'Create Account'}
          </button>
        </div>

        {errorMsg && (
          <div className="mb-4 px-3.5 py-2.5 rounded-xl bg-rose-950/70 border border-rose-500/40 text-xs font-medium text-rose-200 leading-relaxed space-y-2">
            <p>{errorMsg}</p>
            {errorCode === 'auth/operation-not-allowed' && (
              <a
                href="https://console.firebase.google.com/project/restful-subject-jmn89/authentication/providers"
                target="_blank"
                rel="noopener noreferrer"
                className="block w-full text-center py-2 px-3 rounded-lg bg-white/10 hover:bg-white/20 text-white font-bold transition-colors"
              >
                {isAr
                  ? 'فتح إعدادات Firebase لتفعيل Email/Password ←'
                  : 'Open Firebase Console to Enable Email/Password ->'}
              </a>
            )}
            {isInsideIframe() &&
              (errorCode === 'auth/popup-blocked' ||
                errorCode === 'auth/internal-error' ||
                errorCode === 'auth/operation-not-supported-in-this-environment' ||
                errorCode === 'auth/cancelled-popup-request') && (
                <a
                  href={typeof window !== 'undefined' ? window.location.href : '/'}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block w-full text-center py-2 px-3 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold transition-colors"
                >
                  {isAr
                    ? 'فتح في نافذة متصفح مستقلة لتسجيل الدخول بـ Google'
                    : 'Open in Standalone Browser Tab for Google Sign-In'}
                </a>
              )}
          </div>
        )}

        {infoMsg && (
          <div className="mb-4 px-3.5 py-2.5 rounded-xl bg-emerald-950/70 border border-emerald-500/40 text-xs font-medium text-emerald-200 leading-relaxed">
            {infoMsg}
          </div>
        )}

        <form onSubmit={handleEmailSubmit} className="space-y-3.5">
          {mode === 'signup' && (
            <div className="space-y-1.5">
              <label htmlFor="auth-username" className="block text-xs font-semibold text-zinc-300">
                {isAr ? 'اسم المستخدم' : 'Username'} <span className="text-rose-400">*</span>
              </label>
              <div className="relative">
                <UserIcon className="w-4 h-4 text-zinc-500 absolute start-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  id="auth-username"
                  type="text"
                  required
                  minLength={2}
                  maxLength={32}
                  autoComplete="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder={isAr ? 'اكتب اسمك في السيرفر' : 'Your username'}
                  className="w-full ps-10 pe-3.5 py-2.5 rounded-xl bg-black border border-zinc-800 focus:border-purple-500 focus:outline-none text-sm text-white placeholder:text-zinc-600"
                />
              </div>
            </div>
          )}

          <div className="space-y-1.5">
            <label htmlFor="auth-email" className="block text-xs font-semibold text-zinc-300">
              {isAr ? 'البريد الإلكتروني' : 'Email'} <span className="text-rose-400">*</span>
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-zinc-500 absolute start-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                id="auth-email"
                type="email"
                dir="ltr"
                required
                autoComplete="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="example@gmail.com"
                className="w-full ps-10 pe-3.5 py-2.5 rounded-xl bg-black border border-zinc-800 focus:border-purple-500 focus:outline-none text-sm text-white placeholder:text-zinc-600"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <div className="flex items-center justify-between gap-2">
              <label htmlFor="auth-password" className="block text-xs font-semibold text-zinc-300">
                {isAr ? 'كلمة المرور' : 'Password'} <span className="text-rose-400">*</span>
              </label>
              {mode === 'signin' && (
                <button
                  type="button"
                  disabled={resetLoading || loading || googleLoading}
                  onClick={handlePasswordReset}
                  className="text-[11px] font-medium text-purple-400 hover:text-purple-300 transition-colors cursor-pointer disabled:opacity-50"
                >
                  {resetLoading
                    ? isAr
                      ? 'جاري الإرسال...'
                      : 'Sending...'
                    : isAr
                    ? 'نسيت كلمة المرور؟'
                    : 'Forgot password?'}
                </button>
              )}
            </div>
            <div className="relative">
              <Lock className="w-4 h-4 text-zinc-500 absolute start-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                id="auth-password"
                type={showPassword ? 'text' : 'password'}
                dir="ltr"
                required
                minLength={6}
                autoComplete={mode === 'signin' ? 'current-password' : 'new-password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full ps-10 pe-10 py-2.5 rounded-xl bg-black border border-zinc-800 focus:border-purple-500 focus:outline-none text-sm text-white placeholder:text-zinc-600"
              />
              <button
                type="button"
                onClick={() => setShowPassword((prev) => !prev)}
                aria-label={showPassword ? (isAr ? 'إخفاء كلمة المرور' : 'Hide password') : isAr ? 'إظهار كلمة المرور' : 'Show password'}
                className="absolute end-3 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-zinc-200 transition-colors cursor-pointer"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={loading || googleLoading}
            className="w-full min-h-[44px] py-2.5 px-4 rounded-xl text-sm font-bold text-white transition-all cursor-pointer disabled:opacity-60"
            style={{
              backgroundColor: neonColor,
              boxShadow: `0 0 22px ${neonColor}55`,
            }}
          >
            {loading
              ? isAr
                ? 'جاري المتابعة...'
                : 'Please wait...'
              : mode === 'signin'
              ? isAr
                ? 'تسجيل الدخول'
                : 'Sign In'
              : isAr
              ? 'إنشاء الحساب'
              : 'Create Account'}
          </button>
        </form>

        <div className="my-4 flex items-center gap-3">
          <div className="flex-1 h-px bg-zinc-800" />
          <span className="text-xs font-medium text-zinc-500 uppercase">
            {isAr ? 'أو' : 'or'}
          </span>
          <div className="flex-1 h-px bg-zinc-800" />
        </div>

        <button
          type="button"
          onClick={handleGoogleSignIn}
          disabled={loading || googleLoading}
          className="w-full min-h-[44px] py-2.5 px-4 rounded-xl bg-white hover:bg-zinc-100 text-zinc-900 text-sm font-bold flex items-center justify-center gap-2.5 transition-colors cursor-pointer disabled:opacity-60"
        >
          <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24" aria-hidden="true">
            <path
              fill="#4285F4"
              d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17Z"
            />
            <path
              fill="#34A853"
              d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.11-6.72-4.96H1.29v3.14C3.26 21.3 7.31 24 12 24Z"
            />
            <path
              fill="#FBBC05"
              d="M5.28 14.24c-.24-.72-.38-1.49-.38-2.24s.14-1.52.38-2.24V6.62H1.29C.47 8.24 0 10.06 0 12s.47 3.76 1.29 5.38l3.99-3.14Z"
            />
            <path
              fill="#EA4335"
              d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.31 0 3.26 2.7 1.29 6.62l3.99 3.14c.95-2.85 3.6-4.96 6.72-4.96Z"
            />
          </svg>
          <span>
            {googleLoading
              ? isAr
                ? 'جاري الاتصال بـ Google...'
                : 'Connecting to Google...'
              : isAr
              ? 'المتابعة باستخدام Google'
              : 'Continue with Google'}
          </span>
        </button>
      </div>
    </div>
  );
}
