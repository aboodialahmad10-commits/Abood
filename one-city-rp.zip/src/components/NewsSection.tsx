import { Newspaper } from 'lucide-react';
import { Language, TRANSLATIONS } from '../i18n';
import { NewsItem } from '../types';

interface NewsSectionProps {
  news: NewsItem[];
  neonColor: string;
  lang: Language;
}

export function sanitizeNewsImageUrl(raw?: string): string {
  const trimmed = (raw || '').trim();
  if (!trimmed) return '';
  if (
    /^https?:\/\//i.test(trimmed) ||
    trimmed.startsWith('/assets/') ||
    trimmed.startsWith('./assets/') ||
    /^data:image\/(?:png|jpeg|jpg|webp|gif);base64,/i.test(trimmed)
  ) {
    return trimmed;
  }
  return '';
}

export function NewsSection({ news, neonColor, lang }: NewsSectionProps) {
  const t = TRANSLATIONS[lang];

  return (
    <section
      aria-label={t.newsTitle}
      className="w-full max-w-3xl mx-auto rounded-2xl border bg-zinc-950/85 backdrop-blur-xl p-5 sm:p-6 space-y-5"
      style={{
        borderColor: `${neonColor}44`,
        boxShadow: `0 12px 42px rgba(0,0,0,0.55), 0 0 32px ${neonColor}1e`,
      }}
    >
      <div className="flex items-center justify-between gap-3 border-b border-white/10 pb-4">
        <div className="flex items-center gap-3">
          <div
            className="w-9 h-9 rounded-xl flex items-center justify-center border shrink-0"
            style={{
              borderColor: `${neonColor}44`,
              backgroundColor: `${neonColor}18`,
            }}
          >
            <Newspaper className="w-4 h-4 shrink-0" style={{ color: neonColor }} />
          </div>
          <h2 className="text-base sm:text-lg font-bold text-white text-balance">{t.newsTitle}</h2>
        </div>
        <span className="text-xs font-mono tabular-nums text-zinc-400 whitespace-nowrap">
          {news.length} {t.newsCountUnit}
        </span>
      </div>

      {news.length === 0 ? (
        <div className="py-12 text-center space-y-2">
          <Newspaper className="w-8 h-8 text-zinc-600 mx-auto" />
          <p className="text-sm text-zinc-400">{t.newsEmpty}</p>
        </div>
      ) : (
        <div className="clean-scroll divide-y divide-white/[0.08] max-h-[60vh] overflow-y-auto px-1">
          {news.map((item) => {
            const safeImg = sanitizeNewsImageUrl(item.imageUrl);
            return (
              <article
                key={item.id}
                className="py-5 first:pt-1 last:pb-1 space-y-3"
              >
                {safeImg && (
                  <div className="relative w-full overflow-hidden rounded-xl border border-white/10 bg-black">
                    <img
                      src={safeImg}
                      alt={item.title}
                      referrerPolicy="no-referrer"
                      loading="lazy"
                      onError={(e) => {
                        e.currentTarget.parentElement?.classList.add('hidden');
                      }}
                      className="w-full max-h-72 object-cover"
                    />
                    <div
                      aria-hidden="true"
                      className="pointer-events-none absolute inset-x-0 bottom-0 h-16 bg-gradient-to-t from-black/70 to-transparent"
                    />
                  </div>
                )}
                <div className="flex items-start justify-between gap-3">
                  <h3 className="text-sm sm:text-base font-bold text-white leading-snug text-balance">
                    {item.title}
                  </h3>
                  {item.date && (
                    <time className="text-xs font-mono tabular-nums text-zinc-400 whitespace-nowrap shrink-0">
                      {item.date}
                    </time>
                  )}
                </div>
                <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed whitespace-pre-wrap">
                  {item.content}
                </p>
              </article>
            );
          })}
        </div>
      )}
    </section>
  );
}
