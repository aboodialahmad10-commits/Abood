import { useEffect, useRef } from 'react';

interface Star {
  x: number;
  y: number;
  radius: number;
  alpha: number;
  alphaDelta: number;
  vx: number;
  vy: number;
}

interface StarfieldCanvasProps {
  neonColor: string;
}

export function StarfieldCanvas({ neonColor }: StarfieldCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const starCount = Math.min(220, Math.max(95, Math.floor((width * height) / 7500)));
    const stars: Star[] = Array.from({ length: starCount }, () => {
      const layer = Math.random();
      return {
        x: Math.random() * width,
        y: Math.random() * height,
        radius: layer < 0.65 ? 0.8 + Math.random() * 0.7 : 1.4 + Math.random() * 1.1,
        alpha: 0.25 + Math.random() * 0.75,
        alphaDelta: (Math.random() * 0.014 + 0.004) * (Math.random() > 0.5 ? 1 : -1),
        vx: (Math.random() - 0.5) * (layer < 0.65 ? 0.14 : 0.3),
        vy: -(0.08 + Math.random() * (layer < 0.65 ? 0.18 : 0.36)),
      };
    });

    let animationFrameId = 0;

    const drawFrame = () => {
      ctx.fillStyle = '#000000';
      ctx.fillRect(0, 0, width, height);

      for (let i = 0; i < stars.length; i++) {
        const s = stars[i];
        if (!prefersReducedMotion) {
          s.x += s.vx;
          s.y += s.vy;
          s.alpha += s.alphaDelta;

          if (s.alpha >= 1) {
            s.alpha = 1;
            s.alphaDelta *= -1;
          } else if (s.alpha <= 0.18) {
            s.alpha = 0.18;
            s.alphaDelta *= -1;
          }

          if (s.y < -4) {
            s.y = height + 4;
            s.x = Math.random() * width;
          }
          if (s.x < -4) s.x = width + 4;
          if (s.x > width + 4) s.x = -4;
        }

        ctx.beginPath();
        ctx.arc(s.x, s.y, s.radius, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(255, 255, 255, ${s.alpha.toFixed(3)})`;
        ctx.fill();

        if (s.radius > 1.7) {
          ctx.beginPath();
          ctx.arc(s.x, s.y, s.radius * 2.3, 0, Math.PI * 2);
          ctx.fillStyle = `rgba(255, 255, 255, ${(s.alpha * 0.12).toFixed(3)})`;
          ctx.fill();
        }
      }

      if (!prefersReducedMotion) {
        animationFrameId = window.requestAnimationFrame(drawFrame);
      }
    };

    const handleResize = () => {
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
      if (prefersReducedMotion) {
        drawFrame();
      }
    };

    window.addEventListener('resize', handleResize);
    drawFrame();

    return () => {
      window.removeEventListener('resize', handleResize);
      if (animationFrameId) {
        window.cancelAnimationFrame(animationFrameId);
      }
    };
  }, []);

  return (
    <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden bg-black">
      <canvas ref={canvasRef} className="block w-full h-full" />
      <div
        className="absolute inset-0 transition-opacity duration-700"
        style={{
          background: `radial-gradient(circle at 50% 38%, ${neonColor}26 0%, ${neonColor}0d 28%, rgba(0,0,0,0) 64%)`,
        }}
      />
      <div
        className="absolute inset-0"
        style={{
          background:
            'radial-gradient(circle at 50% 100%, rgba(139, 92, 246, 0.08) 0%, rgba(0,0,0,0) 48%)',
        }}
      />
    </div>
  );
}
