import React, { useEffect, useRef, useState } from 'react';
import { Bot, Send, Sparkles } from 'lucide-react';
import { Language, TRANSLATIONS } from '../i18n';
import { BotInfo, ButtonItem } from '../types';

interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}

interface AiChatPanelProps {
  siteName: string;
  neonColor: string;
  botInfo: BotInfo;
  buttons: ButtonItem[];
  lang: Language;
}

export function AiChatPanel({ siteName, neonColor, botInfo, buttons, lang }: AiChatPanelProps) {
  const t = TRANSLATIONS[lang];
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: 'model',
      text: t.aiWelcome(siteName),
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const bottomRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    setMessages((prev) => {
      if (prev.length === 1 && prev[0].role === 'model') {
        return [{ role: 'model', text: t.aiWelcome(siteName) }];
      }
      return prev;
    });
  }, [lang, siteName, t]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length, loading, error]);

  const sendMessage = async (textToSend: string) => {
    const trimmed = textToSend.trim();
    if (!trimmed || loading) return;

    setError(null);
    const nextHistory = messages.slice(1);
    setMessages((prev) => [...prev, { role: 'user', text: trimmed }]);
    setInput('');
    setLoading(true);

    try {
      const response = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: trimmed,
          history: nextHistory,
          siteName,
          botContext: {
            news: botInfo.news,
            factions: botInfo.factions,
            links: buttons
              .filter((b) => b.enabled && b.url.trim().length > 0)
              .map((b) => ({ label: b.label, url: b.url.trim(), icon: b.icon })),
          },
        }),
      });

      const data = (await response.json()) as { reply?: string; error?: string };
      if (!response.ok || !data.reply) {
        throw new Error(data.error || t.aiErrorFallback);
      }

      setMessages((prev) => [...prev, { role: 'model', text: data.reply as string }]);
    } catch (err) {
      setError(err instanceof Error ? err.message : t.aiConnectError);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    void sendMessage(input);
  };

  return (
    <section
      aria-label={t.menuAi}
      className="w-full max-w-3xl mx-auto h-[560px] max-h-[76vh] flex flex-col rounded-2xl border bg-zinc-950/85 backdrop-blur-xl text-white overflow-hidden"
      style={{
        borderColor: `${neonColor}44`,
        boxShadow: `0 12px 42px rgba(0,0,0,0.55), 0 0 32px ${neonColor}1e`,
      }}
    >
      {/* Header */}
      <div className="flex items-center gap-3 px-5 py-4 border-b border-white/10 bg-black/45">
        <div
          className="w-10 h-10 rounded-xl flex items-center justify-center border shrink-0"
          style={{
            borderColor: `${neonColor}55`,
            backgroundColor: `${neonColor}18`,
          }}
        >
          <Bot className="w-5 h-5" style={{ color: neonColor }} />
        </div>
        <div className="min-w-0">
          <h2 className="text-base font-bold leading-tight truncate">{siteName} AI</h2>
          <p className="text-xs text-zinc-400 truncate">{t.aiSubtitle}</p>
        </div>
      </div>

      {/* Messages */}
      <div className="clean-scroll flex-1 overflow-y-auto p-4 sm:p-5 space-y-3.5">
        {messages.map((msg, idx) => (
          <div
            key={idx}
            className={`flex ${msg.role === 'user' ? 'justify-start' : 'justify-end'}`}
          >
            <div
              className={`max-w-[85%] rounded-2xl px-4 py-3 text-xs sm:text-sm leading-relaxed whitespace-pre-wrap ${
                msg.role === 'user'
                  ? 'border text-white'
                  : 'bg-zinc-900/90 border border-white/10 text-zinc-100'
              }`}
              style={
                msg.role === 'user'
                  ? {
                      backgroundColor: `${neonColor}24`,
                      borderColor: `${neonColor}55`,
                    }
                  : undefined
              }
            >
              {msg.text}
            </div>
          </div>
        ))}

        {loading && (
          <div className="flex justify-end">
            <div className="px-4 py-2.5 rounded-2xl bg-zinc-900/90 border border-white/10 text-xs text-zinc-400">
              {t.aiThinking}
            </div>
          </div>
        )}

        {error && (
          <div className="px-3.5 py-2.5 rounded-xl bg-rose-950/60 border border-rose-500/40 text-xs text-rose-200">
            {error}
          </div>
        )}

        <div ref={bottomRef} />
      </div>

      {/* Quick prompts */}
      {messages.length <= 1 && (
        <div className="px-4 pb-3 flex flex-wrap gap-2">
          {t.aiPrompts.map((prompt) => (
            <button
              key={prompt}
              type="button"
              onClick={() => void sendMessage(prompt)}
              className="inline-flex items-center gap-1.5 px-3 py-2 min-h-[38px] rounded-xl bg-white/[0.04] hover:bg-white/[0.09] border border-white/10 text-xs text-zinc-200 hover:text-white transition-colors cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 shrink-0" style={{ color: neonColor }} />
              <span>{prompt}</span>
            </button>
          ))}
        </div>
      )}

      {/* Input */}
      <form
        onSubmit={handleSubmit}
        className="p-3.5 border-t border-white/10 bg-black/65 flex items-center gap-2.5"
      >
        <input
          type="text"
          value={input}
          maxLength={2000}
          onChange={(e) => setInput(e.target.value)}
          placeholder={t.aiPlaceholder}
          className="flex-1 min-h-[44px] px-4 py-2.5 rounded-xl bg-zinc-900/90 border border-white/10 focus:border-purple-500 focus:outline-none text-sm text-white placeholder:text-zinc-500"
        />
        <button
          type="submit"
          disabled={loading || input.trim().length === 0}
          aria-label={t.aiSend}
          className="min-h-[44px] px-4 py-2.5 rounded-xl text-white font-bold text-sm inline-flex items-center gap-1.5 transition-opacity disabled:opacity-40 cursor-pointer shrink-0"
          style={{ backgroundColor: neonColor }}
        >
          <Send className="w-4 h-4" />
          <span className="hidden sm:inline">{t.aiSend}</span>
        </button>
      </form>
    </section>
  );
}
