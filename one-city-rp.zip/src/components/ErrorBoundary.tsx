import React from 'react';

interface ErrorBoundaryState {
  hasError: boolean;
  errorMessage: string;
}

export class ErrorBoundary extends React.Component<
  { children: React.ReactNode },
  ErrorBoundaryState
> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, errorMessage: '' };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return {
      hasError: true,
      errorMessage: error.message || 'حدث خطأ غير متوقع',
    };
  }

  override render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-black text-white flex items-center justify-center p-6 text-center">
          <div className="max-w-md w-full rounded-2xl border border-purple-500/30 bg-zinc-950/90 p-6 space-y-4">
            <h2 className="text-xl font-bold text-white">تعذر تحميل الصفحة</h2>
            <p className="text-sm text-zinc-400 leading-relaxed">
              حدث خلل مؤقت أثناء الاتصال بالخدمة. يرجى إعادة تحديث الصفحة والمحاولة مجدداً.
            </p>
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-sm font-semibold transition-colors cursor-pointer"
            >
              إعادة تحميل الموقع
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
