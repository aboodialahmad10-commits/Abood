import React, { useEffect, useRef, useState } from 'react';
import {
  collection,
  deleteDoc,
  doc,
  onSnapshot,
  serverTimestamp,
  setDoc,
  updateDoc,
} from 'firebase/firestore';
import {
  Copy,
  Download,
  FolderArchive,
  Image as ImageIcon,
  Link as LinkIcon,
  Newspaper,
  Plus,
  RotateCcw,
  Save,
  Shield,
  Trash2,
  Upload,
  User as UserIcon,
  Users,
  X,
} from 'lucide-react';
import { auth, db, handleFirestoreError, OperationType, SUPER_ADMIN_EMAIL } from '../firebase';
import { Language, TRANSLATIONS } from '../i18n';
import {
  AdminMember,
  AdminPermissions,
  BotInfo,
  ButtonItem,
  DEFAULT_BOT_INFO,
  DEFAULT_LOGO_PATH,
  DEFAULT_SITE_CONFIG,
  FactionItem,
  FactionStatus,
  NewsItem,
  SiteConfig,
  UserProfile,
} from '../types';
import {
  generateFullSingleHtml,
  generateStandaloneHtml,
  preloadStandaloneTemplates,
  resolveLogoAsDataUri,
} from '../utils/exportHtml';
import { exportStandaloneProjectZip } from '../utils/exportProjectZip';
import { sanitizeNewsImageUrl } from './NewsSection';

interface AdminModalProps {
  isOpen: boolean;
  onClose: () => void;
  siteConfig: SiteConfig;
  configExistsInDb: boolean;
  botInfo: BotInfo;
  botInfoExistsInDb: boolean;
  permissions: AdminPermissions;
  lang: Language;
}

type AdminTab = 'branding' | 'links' | 'bot' | 'admins';

const NEON_PRESETS = [
  { labelAr: 'بنفسجي ملكي', labelEn: 'Royal Purple', value: '#a855f7' },
  { labelAr: 'أرجواني نيون', labelEn: 'Neon Violet', value: '#c084fc' },
  { labelAr: 'نيلي عميق', labelEn: 'Deep Indigo', value: '#818cf8' },
  { labelAr: 'وردي نيون', labelEn: 'Neon Pink', value: '#ec4899' },
  { labelAr: 'سماوي فضائي', labelEn: 'Cosmic Cyan', value: '#38bdf8' },
];

async function compressLogoFile(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Failed to read image file'));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error('Invalid image file'));
      img.onload = () => {
        const maxSize = 320;
        const scale = Math.min(1, maxSize / Math.max(img.width, img.height));
        const targetW = Math.max(1, Math.round(img.width * scale));
        const targetH = Math.max(1, Math.round(img.height * scale));
        const canvas = document.createElement('canvas');
        canvas.width = targetW;
        canvas.height = targetH;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('Canvas context unavailable'));
          return;
        }
        ctx.drawImage(img, 0, 0, targetW, targetH);
        const compressed = canvas.toDataURL('image/webp', 0.86);
        if (compressed.length > 220000) {
          resolve(canvas.toDataURL('image/jpeg', 0.78));
        } else {
          resolve(compressed);
        }
      };
      img.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  });
}

async function compressNewsImageFile(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Failed to read image file'));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error('Invalid image file'));
      img.onload = () => {
        const maxSize = 640;
        const scale = Math.min(1, maxSize / Math.max(img.width, img.height));
        const targetW = Math.max(1, Math.round(img.width * scale));
        const targetH = Math.max(1, Math.round(img.height * scale));
        const canvas = document.createElement('canvas');
        canvas.width = targetW;
        canvas.height = targetH;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('Canvas context unavailable'));
          return;
        }
        ctx.drawImage(img, 0, 0, targetW, targetH);
        const qualities = [0.78, 0.62, 0.45];
        for (const q of qualities) {
          const webp = canvas.toDataURL('image/webp', q);
          if (webp.length <= 75000) {
            resolve(webp);
            return;
          }
        }
        resolve(canvas.toDataURL('image/jpeg', 0.52));
      };
      img.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  });
}

export function AdminModal({
  isOpen,
  onClose,
  siteConfig,
  configExistsInDb,
  botInfo,
  botInfoExistsInDb,
  permissions,
  lang,
}: AdminModalProps) {
  const t = TRANSLATIONS[lang];

  const initialTab: AdminTab =
    permissions.canEditBranding || permissions.isSuperAdmin
      ? 'branding'
      : permissions.canEditLinks
      ? 'links'
      : permissions.canEditBot
      ? 'bot'
      : 'admins';

  const [activeTab, setActiveTab] = useState<AdminTab>(initialTab);
  const [siteName, setSiteName] = useState(siteConfig.siteName);
  const [siteSubtitle, setSiteSubtitle] = useState(siteConfig.siteSubtitle);
  const [logoUrl, setLogoUrl] = useState(siteConfig.logoUrl);
  const [neonColor, setNeonColor] = useState(siteConfig.neonColor);
  const [welcomeMessages, setWelcomeMessages] = useState<string[]>(siteConfig.welcomeMessages);
  const [buttons, setButtons] = useState<ButtonItem[]>(siteConfig.buttons);

  // Bot news & factions state
  const [newsItems, setNewsItems] = useState<NewsItem[]>(botInfo.news);
  const [factions, setFactions] = useState<FactionItem[]>(botInfo.factions);
  const [newNewsTitle, setNewNewsTitle] = useState('');
  const [newNewsContent, setNewNewsContent] = useState('');
  const [newNewsImageUrl, setNewNewsImageUrl] = useState('');

  const [saving, setSaving] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(
    null,
  );

  // Super Admin only: admins list & signed-in users list
  const [adminsList, setAdminsList] = useState<AdminMember[]>([]);
  const [usersList, setUsersList] = useState<UserProfile[]>([]);
  const [newAdminEmail, setNewAdminEmail] = useState('');
  const [newAdminName, setNewAdminName] = useState('');
  const [newCanBranding, setNewCanBranding] = useState(true);
  const [newCanLinks, setNewCanLinks] = useState(true);
  const [newCanBot, setNewCanBot] = useState(true);
  const [adminSaving, setAdminSaving] = useState(false);

  const wasOpenRef = useRef(false);

  useEffect(() => {
    if (!isOpen) {
      wasOpenRef.current = false;
      return;
    }
    if (wasOpenRef.current) return;
    wasOpenRef.current = true;

    setSiteName(siteConfig.siteName);
    setSiteSubtitle(siteConfig.siteSubtitle);
    setLogoUrl(siteConfig.logoUrl);
    setNeonColor(siteConfig.neonColor);
    setWelcomeMessages(
      siteConfig.welcomeMessages.length > 0
        ? siteConfig.welcomeMessages
        : DEFAULT_SITE_CONFIG.welcomeMessages,
    );
    setButtons(siteConfig.buttons.length > 0 ? siteConfig.buttons : DEFAULT_SITE_CONFIG.buttons);
    setNewsItems(botInfo.news);
    setFactions(botInfo.factions.length > 0 ? botInfo.factions : DEFAULT_BOT_INFO.factions);
    setFeedback(null);
  }, [isOpen, siteConfig, botInfo]);

  useEffect(() => {
    if (!isOpen || !permissions.isSuperAdmin) return;

    const unsubAdmins = onSnapshot(
      collection(db, 'admins'),
      (snap) => {
        const items: AdminMember[] = snap.docs.map((d) => d.data() as AdminMember);
        setAdminsList(items);
      },
      (error) => handleFirestoreError(error, OperationType.LIST, 'admins'),
    );

    const unsubUsers = onSnapshot(
      collection(db, 'users'),
      (snap) => {
        const items: UserProfile[] = snap.docs.map((d) => d.data() as UserProfile);
        setUsersList(items);
      },
      (error) => handleFirestoreError(error, OperationType.LIST, 'users'),
    );

    return () => {
      unsubAdmins();
      unsubUsers();
    };
  }, [isOpen, permissions.isSuperAdmin]);

  if (!isOpen || !permissions.isAdmin) return null;

  const getMemberUsername = (u: UserProfile): string =>
    u.username?.trim() || u.displayName?.trim() || t.memberFallbackName;

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      setFeedback(null);
      const dataUri = await compressLogoFile(file);
      if (dataUri.length > 240000) {
        setFeedback({ type: 'error', text: t.fbImageTooLarge });
        return;
      }
      setLogoUrl(dataUri);
      setFeedback({ type: 'success', text: t.fbImageReady });
    } catch (err) {
      setFeedback({
        type: 'error',
        text: err instanceof Error ? err.message : t.fbImageLoadErr,
      });
    }
  };

  const handleSaveSiteConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    const uid = auth.currentUser?.uid;
    if (!uid) return;

    const cleanName = siteName.trim().slice(0, 60);
    const cleanSubtitle = siteSubtitle.trim().slice(0, 80);
    const cleanLogo = (logoUrl.trim() || DEFAULT_LOGO_PATH).slice(0, 250000);
    const cleanNeon = /^#[0-9a-fA-F]{6}$/.test(neonColor) ? neonColor : '#a855f7';
    const cleanMessages = welcomeMessages
      .map((m) => m.trim().slice(0, 160))
      .filter((m) => m.length > 0)
      .slice(0, 8);
    if (cleanMessages.length === 0) {
      cleanMessages.push('مرحباً بكم في One City RP');
    }

    const cleanButtons = buttons
      .map((b, idx) => {
        const rawUrl = b.url.trim().slice(0, 500);
        const normalizedUrl = rawUrl
          ? /^https?:\/\//i.test(rawUrl)
            ? rawUrl
            : `https://${rawUrl}`
          : '';
        return {
          id: (b.id || `btn_${idx + 1}`).replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 40) || `btn_${idx + 1}`,
          label: b.label.trim().slice(0, 60) || 'Link',
          url: normalizedUrl.slice(0, 500),
          icon: (b.icon.trim() || '🔗').slice(0, 20),
          enabled: Boolean(b.enabled),
        };
      })
      .slice(0, 8);

    if (cleanName.length === 0) {
      setFeedback({ type: 'error', text: t.fbSiteNameRequired });
      return;
    }
    if (cleanButtons.length === 0) {
      setFeedback({ type: 'error', text: t.fbOneBtnRequired });
      return;
    }

    setSaving(true);
    setFeedback(null);
    const docRef = doc(db, 'site_config', 'main');

    try {
      if (!configExistsInDb) {
        if (!permissions.isSuperAdmin) {
          setFeedback({ type: 'error', text: t.fbOwnerFirst });
          setSaving(false);
          return;
        }
        await setDoc(docRef, {
          siteName: cleanName,
          siteSubtitle: cleanSubtitle,
          logoUrl: cleanLogo,
          neonColor: cleanNeon,
          welcomeMessages: cleanMessages,
          buttons: cleanButtons,
          updatedAt: serverTimestamp(),
          updatedBy: uid,
        });
      } else {
        const updatePayload: Record<string, unknown> = {
          updatedAt: serverTimestamp(),
          updatedBy: uid,
        };

        if (permissions.isSuperAdmin || permissions.canEditBranding) {
          updatePayload.siteName = cleanName;
          updatePayload.siteSubtitle = cleanSubtitle;
          updatePayload.logoUrl = cleanLogo;
          updatePayload.neonColor = cleanNeon;
          updatePayload.welcomeMessages = cleanMessages;
        }

        if (permissions.isSuperAdmin || permissions.canEditLinks) {
          updatePayload.buttons = cleanButtons;
        }

        await updateDoc(docRef, updatePayload);
      }

      if (permissions.isSuperAdmin || permissions.canEditLinks) {
        setButtons(cleanButtons);
      }
      setFeedback({ type: 'success', text: t.fbConfigSaved });
    } catch (error) {
      console.error('Failed to save site_config/main:', error);
      setFeedback({ type: 'error', text: t.fbSaveError });
    } finally {
      setSaving(false);
    }
  };

  const persistBotInfo = async (
    targetNews: NewsItem[],
    targetFactions: FactionItem[],
    successText: string,
  ): Promise<boolean> => {
    const uid = auth.currentUser?.uid;
    if (!uid) {
      setFeedback({ type: 'error', text: t.fbSaveError });
      return false;
    }

    const cleanNews: NewsItem[] = targetNews
      .filter((n) => n.title.trim().length > 0 && n.content.trim().length > 0)
      .map((n, idx) => {
        const cleanImg = sanitizeNewsImageUrl((n.imageUrl || '').slice(0, 80000));
        const base: NewsItem = {
          id:
            (n.id || `news_${idx + 1}`).replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 40) ||
            `news_${idx + 1}`,
          title: n.title.trim().slice(0, 80),
          content: n.content.trim().slice(0, 300),
          date: (n.date || new Date().toISOString().slice(0, 10)).trim().slice(0, 30),
        };
        if (cleanImg) {
          base.imageUrl = cleanImg;
        }
        return base;
      })
      .slice(0, 15);

    const cleanFactions: FactionItem[] = targetFactions
      .filter((f) => f.name.trim().length > 0)
      .map((f, idx) => ({
        id:
          (f.id || `faction_${idx + 1}`).replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 40) ||
          `faction_${idx + 1}`,
        name: f.name.trim().slice(0, 50),
        icon: (f.icon.trim() || '🛡️').slice(0, 16),
        status: (['مفتوح', 'مغلق', 'قريباً'].includes(f.status) ? f.status : 'مفتوح') as FactionStatus,
        description: f.description.trim().slice(0, 200),
      }))
      .slice(0, 12);

    setSaving(true);
    setFeedback(null);
    const botRef = doc(db, 'site_config', 'bot_info');

    try {
      if (!botInfoExistsInDb) {
        await setDoc(botRef, {
          news: cleanNews,
          factions: cleanFactions,
          updatedAt: serverTimestamp(),
          updatedBy: uid,
        });
      } else {
        await updateDoc(botRef, {
          news: cleanNews,
          factions: cleanFactions,
          updatedAt: serverTimestamp(),
          updatedBy: uid,
        });
      }
      setNewsItems(cleanNews);
      setFactions(cleanFactions);
      setFeedback({ type: 'success', text: successText });
      return true;
    } catch (error) {
      console.error('Failed to save site_config/bot_info:', error);
      setFeedback({ type: 'error', text: t.fbSaveError });
      return false;
    } finally {
      setSaving(false);
    }
  };

  const handleSaveBotInfo = async (e: React.FormEvent) => {
    e.preventDefault();
    const pendingTitle = newNewsTitle.trim();
    const pendingContent = newNewsContent.trim();

    if ((pendingTitle && !pendingContent) || (!pendingTitle && pendingContent)) {
      setFeedback({ type: 'error', text: t.fbNewsFieldsRequired });
      return;
    }

    let nextNews = newsItems;
    if (pendingTitle && pendingContent) {
      if (newsItems.length >= 15) {
        setFeedback({ type: 'error', text: t.fbMaxNews });
        return;
      }
      const today = new Date().toISOString().slice(0, 10);
      const pendingImg = newNewsImageUrl.trim().slice(0, 80000);
      nextNews = [
        {
          id: `news_${Date.now()}`,
          title: pendingTitle.slice(0, 80),
          content: pendingContent.slice(0, 300),
          date: today,
          ...(pendingImg ? { imageUrl: pendingImg } : {}),
        },
        ...newsItems,
      ];
    }

    const ok = await persistBotInfo(nextNews, factions, t.fbBotSaved);
    if (ok && pendingTitle && pendingContent) {
      setNewNewsTitle('');
      setNewNewsContent('');
      setNewNewsImageUrl('');
    }
  };

  const handleNewsImageUpload = async (
    e: React.ChangeEvent<HTMLInputElement>,
    onResult: (dataUri: string) => void,
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      setFeedback(null);
      const dataUri = await compressNewsImageFile(file);
      if (dataUri.length > 78000) {
        setFeedback({ type: 'error', text: t.fbImageTooLarge });
        return;
      }
      onResult(dataUri);
      setFeedback({ type: 'success', text: t.newsImageReady });
    } catch (err) {
      setFeedback({
        type: 'error',
        text: err instanceof Error ? err.message : t.fbImageLoadErr,
      });
    } finally {
      e.target.value = '';
    }
  };

  const handleAddNewsQuick = async () => {
    const title = newNewsTitle.trim();
    const content = newNewsContent.trim();
    if (!title || !content) {
      setFeedback({ type: 'error', text: t.fbNewsFieldsRequired });
      return;
    }
    if (newsItems.length >= 15) {
      setFeedback({ type: 'error', text: t.fbMaxNews });
      return;
    }
    const today = new Date().toISOString().slice(0, 10);
    const pendingImg = newNewsImageUrl.trim().slice(0, 80000);
    const nextNews: NewsItem[] = [
      {
        id: `news_${Date.now()}`,
        title: title.slice(0, 80),
        content: content.slice(0, 300),
        date: today,
        ...(pendingImg ? { imageUrl: pendingImg } : {}),
      },
      ...newsItems,
    ];
    const ok = await persistBotInfo(nextNews, factions, t.fbNewsQueued);
    if (ok) {
      setNewNewsTitle('');
      setNewNewsContent('');
      setNewNewsImageUrl('');
    }
  };

  const handleAddAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!permissions.isSuperAdmin || !auth.currentUser) return;

    const normalizedEmail = newAdminEmail.trim().toLowerCase();
    const emailRegex = /^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$/;

    if (!emailRegex.test(normalizedEmail)) {
      setFeedback({ type: 'error', text: t.fbInvalidEmail });
      return;
    }
    if (normalizedEmail === SUPER_ADMIN_EMAIL) {
      setFeedback({ type: 'error', text: t.fbOwnerAlready });
      return;
    }

    setAdminSaving(true);
    setFeedback(null);
    const adminRef = doc(db, 'admins', normalizedEmail);
    const existingAdmin = adminsList.find((a) => a.email === normalizedEmail);
    const matchedMember = usersList.find((u) => u.email.toLowerCase() === normalizedEmail);
    const resolvedName =
      newAdminName.trim().slice(0, 80) ||
      (matchedMember ? getMemberUsername(matchedMember) : '');

    try {
      if (existingAdmin) {
        await updateDoc(adminRef, {
          displayName: resolvedName,
          canEditBranding: newCanBranding,
          canEditLinks: newCanLinks,
          canEditBot: newCanBot,
          addedBy: auth.currentUser.uid,
          updatedAt: serverTimestamp(),
        });
      } else {
        await setDoc(adminRef, {
          email: normalizedEmail,
          displayName: resolvedName,
          canEditBranding: newCanBranding,
          canEditLinks: newCanLinks,
          canEditBot: newCanBot,
          addedBy: auth.currentUser.uid,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      }

      setNewAdminEmail('');
      setNewAdminName('');
      setFeedback({ type: 'success', text: t.fbAdminGranted });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `admins/${normalizedEmail}`);
    } finally {
      setAdminSaving(false);
    }
  };

  const handleToggleAdminPerm = async (
    admin: AdminMember,
    field: 'canEditBranding' | 'canEditLinks' | 'canEditBot',
  ) => {
    if (!permissions.isSuperAdmin || !auth.currentUser) return;
    try {
      await updateDoc(doc(db, 'admins', admin.email), {
        [field]: !Boolean(admin[field]),
        addedBy: auth.currentUser.uid,
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `admins/${admin.email}`);
    }
  };

  const handleRemoveAdmin = async (email: string) => {
    if (!permissions.isSuperAdmin) return;
    try {
      await deleteDoc(doc(db, 'admins', email));
      setFeedback({ type: 'success', text: t.fbAdminRemoved });
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `admins/${email}`);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md"
      role="dialog"
      aria-modal="true"
      aria-label={t.adminTitle}
    >
      <div className="relative w-full max-w-2xl max-h-[90vh] flex flex-col rounded-2xl border border-purple-500/35 bg-zinc-950 text-white shadow-[0_0_50px_rgba(168,85,247,0.22)] overflow-hidden">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-2 px-5 py-4 border-b border-zinc-800/80">
          <div className="flex items-center gap-2.5">
            <Shield className="w-5 h-5 text-purple-400 shrink-0" />
            <h2 className="text-base sm:text-lg font-bold">{t.adminTitle}</h2>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={async () => {
                const url = `${window.location.origin}/One.City.html`;
                try {
                  await navigator.clipboard.writeText(url);
                  setFeedback({ type: 'success', text: `${t.fbHtmlCopied} ${url}` });
                } catch {
                  setFeedback({ type: 'success', text: `${t.fbHtmlDirect} ${url}` });
                }
              }}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-xs font-semibold text-zinc-200 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Copy className="w-3.5 h-3.5 text-purple-400" />
              <span>{t.copyHtmlLink}</span>
            </button>
            <button
              type="button"
              onClick={async () => {
                const currentCfg: SiteConfig = {
                  siteName,
                  siteSubtitle,
                  logoUrl,
                  neonColor,
                  welcomeMessages,
                  buttons,
                };
                const currentBot: BotInfo = {
                  news: newsItems,
                  factions,
                };
                const [embeddedLogo, templates] = await Promise.all([
                  resolveLogoAsDataUri(logoUrl),
                  preloadStandaloneTemplates(),
                ]);
                const html = templates
                  ? generateFullSingleHtml({
                      siteConfig: currentCfg,
                      botInfo: currentBot,
                      logoDataUri: embeddedLogo,
                      templates,
                    })
                  : generateStandaloneHtml({
                      ...currentCfg,
                      logoUrl: embeddedLogo,
                    });
                const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
                const blobUrl = URL.createObjectURL(blob);
                const anchor = document.createElement('a');
                anchor.href = blobUrl;
                anchor.download = 'One.City.html';
                anchor.click();
                window.setTimeout(() => URL.revokeObjectURL(blobUrl), 10000);
                setFeedback({ type: 'success', text: t.fbHtmlDownloaded });
              }}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-purple-600/20 hover:bg-purple-600/35 border border-purple-500/40 text-xs font-semibold text-purple-200 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{t.downloadHtml}</span>
            </button>
            <button
              type="button"
              onClick={async () => {
                try {
                  const zipBlob = await exportStandaloneProjectZip(
                    {
                      siteName,
                      siteSubtitle,
                      logoUrl,
                      neonColor,
                      welcomeMessages,
                      buttons,
                    },
                    {
                      news: newsItems,
                      factions,
                    },
                  );
                  const blobUrl = URL.createObjectURL(zipBlob);
                  const anchor = document.createElement('a');
                  anchor.href = blobUrl;
                  anchor.download = 'OneCityRP-Website.zip';
                  anchor.click();
                  URL.revokeObjectURL(blobUrl);
                  setFeedback({ type: 'success', text: t.fbZipDownloaded });
                } catch {
                  setFeedback({ type: 'error', text: t.fbZipError });
                }
              }}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/35 border border-emerald-500/40 text-xs font-semibold text-emerald-200 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <FolderArchive className="w-3.5 h-3.5" />
              <span>{t.exportZip}</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              aria-label={t.closeAdminAria}
              className="p-2 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-900 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-1.5 px-5 py-3 border-b border-zinc-800/80 bg-zinc-950/80 overflow-x-auto">
          {(permissions.isSuperAdmin || permissions.canEditBranding) && (
            <button
              type="button"
              onClick={() => setActiveTab('branding')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs sm:text-sm font-semibold whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                activeTab === 'branding'
                  ? 'bg-purple-600 text-white'
                  : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
              }`}
            >
              <ImageIcon className="w-4 h-4" />
              <span>{t.tabBranding}</span>
            </button>
          )}
          {(permissions.isSuperAdmin || permissions.canEditLinks) && (
            <button
              type="button"
              onClick={() => setActiveTab('links')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs sm:text-sm font-semibold whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                activeTab === 'links'
                  ? 'bg-purple-600 text-white'
                  : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
              }`}
            >
              <LinkIcon className="w-4 h-4" />
              <span>{t.tabLinks}</span>
            </button>
          )}
          {(permissions.isSuperAdmin || permissions.canEditBot) && (
            <button
              type="button"
              onClick={() => setActiveTab('bot')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs sm:text-sm font-semibold whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                activeTab === 'bot'
                  ? 'bg-purple-600 text-white'
                  : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
              }`}
            >
              <Newspaper className="w-4 h-4" />
              <span>{t.tabBot}</span>
            </button>
          )}
          {permissions.isSuperAdmin && (
            <button
              type="button"
              onClick={() => setActiveTab('admins')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs sm:text-sm font-semibold whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                activeTab === 'admins'
                  ? 'bg-purple-600 text-white'
                  : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
              }`}
            >
              <Users className="w-4 h-4" />
              <span>{t.tabAdmins}</span>
            </button>
          )}
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-5">
          {feedback && (
            <div
              className={`px-4 py-3 rounded-xl text-xs sm:text-sm font-medium border ${
                feedback.type === 'success'
                  ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-200'
                  : 'bg-rose-950/60 border-rose-500/40 text-rose-200'
              }`}
            >
              {feedback.text}
            </div>
          )}

          {activeTab === 'branding' && (permissions.isSuperAdmin || permissions.canEditBranding) && (
            <form onSubmit={handleSaveSiteConfig} className="space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold text-zinc-300">
                    {t.siteNameLabel}
                  </label>
                  <input
                    type="text"
                    value={siteName}
                    maxLength={60}
                    onChange={(e) => setSiteName(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 focus:border-purple-500 focus:outline-none text-sm text-white"
                    placeholder="One City RP"
                    required
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold text-zinc-300">
                    {t.siteSubtitleLabel}
                  </label>
                  <input
                    type="text"
                    value={siteSubtitle}
                    maxLength={80}
                    onChange={(e) => setSiteSubtitle(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 focus:border-purple-500 focus:outline-none text-sm text-white"
                    placeholder={t.siteSubtitlePlaceholder}
                  />
                </div>
              </div>

              {/* Logo Picker */}
              <div className="space-y-2.5">
                <label className="block text-xs font-semibold text-zinc-300">
                  {t.logoPickerLabel}
                </label>
                <div className="flex flex-col sm:flex-row items-center gap-4 p-3.5 rounded-xl bg-zinc-900/70 border border-zinc-800">
                  <div
                    className="w-20 h-20 rounded-full overflow-hidden shrink-0 border-2 bg-black flex items-center justify-center"
                    style={{ borderColor: neonColor }}
                  >
                    <img
                      src={logoUrl || DEFAULT_LOGO_PATH}
                      alt={siteName}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-contain p-1.5"
                    />
                  </div>
                  <div className="flex-1 w-full space-y-2.5">
                    <input
                      type="text"
                      value={logoUrl}
                      onChange={(e) => setLogoUrl(e.target.value)}
                      dir="ltr"
                      className="w-full px-3 py-2 rounded-lg bg-black border border-zinc-800 focus:border-purple-500 focus:outline-none text-xs text-zinc-200"
                      placeholder={t.logoUrlPlaceholder}
                    />
                    <div className="flex flex-wrap items-center gap-2">
                      <label className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-purple-600/20 hover:bg-purple-600/35 border border-purple-500/40 text-xs font-semibold text-purple-200 cursor-pointer transition-colors">
                        <Upload className="w-3.5 h-3.5" />
                        <span>{t.uploadFromDevice}</span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleImageUpload}
                          className="hidden"
                        />
                      </label>
                      <button
                        type="button"
                        onClick={() => setLogoUrl(DEFAULT_LOGO_PATH)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-medium text-zinc-300 cursor-pointer transition-colors"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>{t.restoreDefaultLogo}</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Neon Color */}
              <div className="space-y-2">
                <label className="block text-xs font-semibold text-zinc-300">{t.neonColorLabel}</label>
                <div className="flex flex-wrap items-center gap-2.5">
                  {NEON_PRESETS.map((preset) => (
                    <button
                      key={preset.value}
                      type="button"
                      onClick={() => setNeonColor(preset.value)}
                      className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs font-medium transition-all cursor-pointer ${
                        neonColor.toLowerCase() === preset.value.toLowerCase()
                          ? 'border-white bg-zinc-800 text-white'
                          : 'border-zinc-800 bg-zinc-900 text-zinc-400 hover:text-white'
                      }`}
                    >
                      <span
                        className="w-3 h-3 rounded-full"
                        style={{ backgroundColor: preset.value }}
                      />
                      <span>{lang === 'ar' ? preset.labelAr : preset.labelEn}</span>
                    </button>
                  ))}
                  <input
                    type="color"
                    value={neonColor}
                    onChange={(e) => setNeonColor(e.target.value)}
                    aria-label={t.customColorAria}
                    className="w-9 h-8 rounded-lg bg-transparent border border-zinc-700 cursor-pointer"
                  />
                </div>
              </div>

              {/* Typewriter Welcome Messages */}
              <div className="space-y-2.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-zinc-300">
                    {t.welcomeMsgsLabel}
                  </label>
                  {welcomeMessages.length < 8 && (
                    <button
                      type="button"
                      onClick={() => setWelcomeMessages((prev) => [...prev, ''])}
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-xs text-zinc-200 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>{t.addMessage}</span>
                    </button>
                  )}
                </div>
                <div className="space-y-2">
                  {welcomeMessages.map((msg, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <input
                        type="text"
                        value={msg}
                        maxLength={160}
                        onChange={(e) =>
                          setWelcomeMessages((prev) =>
                            prev.map((item, i) => (i === idx ? e.target.value : item)),
                          )
                        }
                        className="flex-1 px-3.5 py-2 rounded-xl bg-zinc-900 border border-zinc-800 focus:border-purple-500 focus:outline-none text-sm text-white"
                        placeholder={t.welcomeMsgPlaceholder}
                      />
                      {welcomeMessages.length > 1 && (
                        <button
                          type="button"
                          onClick={() =>
                            setWelcomeMessages((prev) => prev.filter((_, i) => i !== idx))
                          }
                          aria-label={t.deleteMessageAria}
                          className="p-2 rounded-lg text-zinc-400 hover:text-rose-400 hover:bg-zinc-900 cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  type="submit"
                  disabled={saving}
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white text-sm font-bold transition-colors cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>{saving ? t.saving : t.saveChanges}</span>
                </button>
              </div>
            </form>
          )}

          {activeTab === 'links' && (permissions.isSuperAdmin || permissions.canEditLinks) && (
            <form onSubmit={handleSaveSiteConfig} className="space-y-4">
              <div className="flex items-center justify-between gap-2">
                <p className="text-xs text-zinc-400">{t.linksHelp}</p>
                {buttons.length < 8 && (
                  <button
                    type="button"
                    onClick={() =>
                      setButtons((prev) => [
                        ...prev,
                        {
                          id: `custom_${Date.now()}`,
                          label: t.newButtonDefaultLabel,
                          url: '',
                          icon: '🔗',
                          enabled: true,
                        },
                      ])
                    }
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-xs font-semibold text-white shrink-0 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>{t.addButton}</span>
                  </button>
                )}
              </div>

              <div className="space-y-3">
                {buttons.map((btn, idx) => (
                  <div
                    key={btn.id || idx}
                    className="p-3.5 rounded-xl bg-zinc-900/70 border border-zinc-800 space-y-3"
                  >
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2 flex-1">
                        <input
                          type="text"
                          value={btn.icon}
                          maxLength={10}
                          onChange={(e) =>
                            setButtons((prev) =>
                              prev.map((b, i) => (i === idx ? { ...b, icon: e.target.value } : b)),
                            )
                          }
                          className="w-12 text-center px-2 py-2 rounded-lg bg-black border border-zinc-800 text-base"
                          aria-label={t.buttonIconAria}
                        />
                        <input
                          type="text"
                          value={btn.label}
                          maxLength={60}
                          onChange={(e) =>
                            setButtons((prev) =>
                              prev.map((b, i) => (i === idx ? { ...b, label: e.target.value } : b)),
                            )
                          }
                          className="flex-1 px-3 py-2 rounded-lg bg-black border border-zinc-800 focus:border-purple-500 focus:outline-none text-sm text-white"
                          placeholder={t.buttonLabelPlaceholder}
                          required
                        />
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <label className="flex items-center gap-1.5 text-xs text-zinc-300 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={btn.enabled}
                            onChange={(e) =>
                              setButtons((prev) =>
                                prev.map((b, i) =>
                                  i === idx ? { ...b, enabled: e.target.checked } : b,
                                ),
                              )
                            }
                            className="accent-purple-500 w-4 h-4"
                          />
                          <span>{t.enabledLabel}</span>
                        </label>
                        {buttons.length > 1 && (
                          <button
                            type="button"
                            onClick={() =>
                              setButtons((prev) => prev.filter((_, i) => i !== idx))
                            }
                            aria-label={t.deleteButtonAria}
                            className="p-1.5 rounded-lg text-zinc-400 hover:text-rose-400 hover:bg-zinc-800 cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </div>

                    <input
                      type="text"
                      value={btn.url}
                      maxLength={500}
                      dir="ltr"
                      onChange={(e) =>
                        setButtons((prev) =>
                          prev.map((b, i) => (i === idx ? { ...b, url: e.target.value } : b)),
                        )
                      }
                      className="w-full px-3 py-2 rounded-lg bg-black border border-zinc-800 focus:border-purple-500 focus:outline-none text-xs text-zinc-200"
                      placeholder={t.buttonUrlPlaceholder}
                    />
                  </div>
                ))}
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  type="submit"
                  disabled={saving}
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white text-sm font-bold transition-colors cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>{saving ? t.saving : t.saveLinks}</span>
                </button>
              </div>
            </form>
          )}

          {activeTab === 'bot' && (permissions.isSuperAdmin || permissions.canEditBot) && (
            <form onSubmit={handleSaveBotInfo} className="space-y-6">
              {/* Section 1: Add & Manage Latest News */}
              <div className="space-y-3">
                <h3 className="text-sm font-bold text-white">{t.newsSectionHeading}</h3>
                <div className="p-3.5 rounded-xl bg-zinc-900/70 border border-zinc-800 space-y-2.5">
                  <input
                    type="text"
                    value={newNewsTitle}
                    maxLength={80}
                    onChange={(e) => setNewNewsTitle(e.target.value)}
                    placeholder={t.newsTitlePlaceholder}
                    className="w-full px-3.5 py-2 rounded-xl bg-black border border-zinc-800 focus:border-purple-500 focus:outline-none text-sm text-white"
                  />
                  <textarea
                    value={newNewsContent}
                    maxLength={300}
                    rows={2}
                    onChange={(e) => setNewNewsContent(e.target.value)}
                    placeholder={t.newsContentPlaceholder}
                    className="w-full px-3.5 py-2 rounded-xl bg-black border border-zinc-800 focus:border-purple-500 focus:outline-none text-sm text-white resize-none"
                  />
                  <div className="space-y-2">
                    <div className="flex flex-wrap items-center gap-2">
                      <input
                        type="text"
                        value={newNewsImageUrl}
                        maxLength={80000}
                        dir="ltr"
                        onChange={(e) => setNewNewsImageUrl(e.target.value)}
                        placeholder={t.newsImagePlaceholder}
                        className="flex-1 min-w-[160px] px-3 py-1.5 rounded-lg bg-black border border-zinc-800 focus:border-purple-500 focus:outline-none text-xs text-zinc-200"
                      />
                      <label className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 text-xs font-semibold text-zinc-100 cursor-pointer shrink-0">
                        <ImageIcon className="w-3.5 h-3.5 text-purple-400" />
                        <span>{t.uploadNewsImage}</span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={(e) => handleNewsImageUpload(e, (uri) => setNewNewsImageUrl(uri))}
                          className="hidden"
                        />
                      </label>
                      {newNewsImageUrl && (
                        <button
                          type="button"
                          onClick={() => setNewNewsImageUrl('')}
                          className="px-2.5 py-1.5 rounded-lg bg-rose-950/60 hover:bg-rose-900/70 border border-rose-500/30 text-xs text-rose-200 cursor-pointer"
                        >
                          {t.removeNewsImage}
                        </button>
                      )}
                    </div>
                    {newNewsImageUrl && (
                      <img
                        src={newNewsImageUrl}
                        alt="News preview"
                        referrerPolicy="no-referrer"
                        className="w-full max-h-36 object-cover rounded-lg border border-zinc-800 bg-black"
                      />
                    )}
                  </div>
                  <div className="flex justify-end">
                    <button
                      type="button"
                      disabled={saving}
                      onClick={handleAddNewsQuick}
                      className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-purple-600/25 hover:bg-purple-600/40 disabled:opacity-50 border border-purple-500/40 text-xs font-bold text-purple-100 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>{saving ? t.saving : t.addNewsToList}</span>
                    </button>
                  </div>
                </div>

                {newsItems.length === 0 ? (
                  <p className="text-xs text-zinc-400">{t.noNewsAdmin}</p>
                ) : (
                  <div className="space-y-2.5">
                    {newsItems.map((item, idx) => (
                      <div
                        key={item.id || idx}
                        className="p-3 rounded-xl bg-zinc-900/50 border border-zinc-800 space-y-2"
                      >
                        <div className="flex items-center gap-2">
                          <input
                            type="text"
                            value={item.title}
                            maxLength={80}
                            onChange={(e) =>
                              setNewsItems((prev) =>
                                prev.map((n, i) => (i === idx ? { ...n, title: e.target.value } : n)),
                              )
                            }
                            className="flex-1 px-3 py-1.5 rounded-lg bg-black border border-zinc-800 text-xs sm:text-sm text-white font-semibold"
                            placeholder={t.titlePlaceholderShort}
                          />
                          <input
                            type="text"
                            value={item.date}
                            maxLength={30}
                            dir="ltr"
                            onChange={(e) =>
                              setNewsItems((prev) =>
                                prev.map((n, i) => (i === idx ? { ...n, date: e.target.value } : n)),
                              )
                            }
                            className="w-28 px-2.5 py-1.5 rounded-lg bg-black border border-zinc-800 text-xs text-zinc-300 font-mono"
                            placeholder="2026-11-20"
                          />
                          <button
                            type="button"
                            onClick={() =>
                              setNewsItems((prev) => prev.filter((_, i) => i !== idx))
                            }
                            aria-label={t.deleteNewsAria}
                            className="p-1.5 rounded-lg text-zinc-400 hover:text-rose-400 hover:bg-zinc-800 cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                        <textarea
                          value={item.content}
                          maxLength={300}
                          rows={2}
                          onChange={(e) =>
                            setNewsItems((prev) =>
                              prev.map((n, i) => (i === idx ? { ...n, content: e.target.value } : n)),
                            )
                          }
                          className="w-full px-3 py-1.5 rounded-lg bg-black border border-zinc-800 text-xs text-zinc-200 resize-none"
                          placeholder={t.contentPlaceholderShort}
                        />
                        <div className="space-y-2">
                          <div className="flex flex-wrap items-center gap-2">
                            <input
                              type="text"
                              value={item.imageUrl || ''}
                              maxLength={80000}
                              dir="ltr"
                              onChange={(e) =>
                                setNewsItems((prev) =>
                                  prev.map((n, i) =>
                                    i === idx ? { ...n, imageUrl: e.target.value } : n,
                                  ),
                                )
                              }
                              className="flex-1 min-w-[140px] px-3 py-1.5 rounded-lg bg-black border border-zinc-800 text-xs text-zinc-300"
                              placeholder={t.newsImagePlaceholder}
                            />
                            <label className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-semibold text-zinc-200 cursor-pointer shrink-0">
                              <ImageIcon className="w-3.5 h-3.5 text-purple-400" />
                              <span>{t.uploadNewsImage}</span>
                              <input
                                type="file"
                                accept="image/*"
                                onChange={(e) =>
                                  handleNewsImageUpload(e, (uri) =>
                                    setNewsItems((prev) =>
                                      prev.map((n, i) => (i === idx ? { ...n, imageUrl: uri } : n)),
                                    ),
                                  )
                                }
                                className="hidden"
                              />
                            </label>
                            {item.imageUrl && (
                              <button
                                type="button"
                                onClick={() =>
                                  setNewsItems((prev) =>
                                    prev.map((n, i) => (i === idx ? { ...n, imageUrl: '' } : n)),
                                  )
                                }
                                className="px-2 py-1.5 rounded-lg bg-rose-950/60 hover:bg-rose-900/70 text-xs text-rose-200 cursor-pointer"
                              >
                                {t.removeNewsImage}
                              </button>
                            )}
                          </div>
                          {item.imageUrl && (
                            <img
                              src={item.imageUrl}
                              alt={item.title || 'News image'}
                              referrerPolicy="no-referrer"
                              className="w-full max-h-32 object-cover rounded-lg border border-zinc-800 bg-black"
                            />
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Section 2: Available Factions */}
              <div className="space-y-3 pt-4 border-t border-zinc-800/80">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-white">{t.factionsSectionHeading}</h3>
                  {factions.length < 12 && (
                    <button
                      type="button"
                      onClick={() =>
                        setFactions((prev) => [
                          ...prev,
                          {
                            id: `faction_${Date.now()}`,
                            name: t.newFactionDefaultName,
                            icon: '🛡️',
                            status: 'مفتوح',
                            description: '',
                          },
                        ])
                      }
                      className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-xs text-zinc-200 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>{t.addFaction}</span>
                    </button>
                  )}
                </div>

                <div className="space-y-2.5">
                  {factions.map((faction, idx) => (
                    <div
                      key={faction.id || idx}
                      className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 space-y-2"
                    >
                      <div className="flex flex-wrap items-center gap-2">
                        <input
                          type="text"
                          value={faction.icon}
                          maxLength={10}
                          onChange={(e) =>
                            setFactions((prev) =>
                              prev.map((f, i) => (i === idx ? { ...f, icon: e.target.value } : f)),
                            )
                          }
                          className="w-11 text-center px-2 py-1.5 rounded-lg bg-black border border-zinc-800 text-base"
                          aria-label={t.factionIconAria}
                        />
                        <input
                          type="text"
                          value={faction.name}
                          maxLength={50}
                          onChange={(e) =>
                            setFactions((prev) =>
                              prev.map((f, i) => (i === idx ? { ...f, name: e.target.value } : f)),
                            )
                          }
                          className="flex-1 min-w-[120px] px-3 py-1.5 rounded-lg bg-black border border-zinc-800 text-xs sm:text-sm text-white font-semibold"
                          placeholder={t.factionNamePlaceholder}
                          required
                        />
                        <select
                          value={faction.status}
                          onChange={(e) =>
                            setFactions((prev) =>
                              prev.map((f, i) =>
                                i === idx
                                  ? { ...f, status: e.target.value as FactionStatus }
                                  : f,
                              ),
                            )
                          }
                          className="px-3 py-1.5 rounded-lg bg-black border border-zinc-800 text-xs text-white"
                        >
                          <option value="مفتوح">{t.statusMap['مفتوح']}</option>
                          <option value="مغلق">{t.statusMap['مغلق']}</option>
                          <option value="قريباً">{t.statusMap['قريباً']}</option>
                        </select>
                        {factions.length > 1 && (
                          <button
                            type="button"
                            onClick={() =>
                              setFactions((prev) => prev.filter((_, i) => i !== idx))
                            }
                            aria-label={t.deleteFactionAria}
                            className="p-1.5 rounded-lg text-zinc-400 hover:text-rose-400 hover:bg-zinc-800 cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                      <input
                        type="text"
                        value={faction.description}
                        maxLength={200}
                        onChange={(e) =>
                          setFactions((prev) =>
                            prev.map((f, i) =>
                              i === idx ? { ...f, description: e.target.value } : f,
                            ),
                          )
                        }
                        className="w-full px-3 py-1.5 rounded-lg bg-black border border-zinc-800 text-xs text-zinc-200"
                        placeholder={t.factionDescPlaceholder}
                      />
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  type="submit"
                  disabled={saving}
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white text-sm font-bold transition-colors cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>{saving ? t.saving : t.saveNewsFactions}</span>
                </button>
              </div>
            </form>
          )}

          {activeTab === 'admins' && permissions.isSuperAdmin && (
            <div className="space-y-6">
              {/* Owner badge */}
              <div className="p-3.5 rounded-xl bg-purple-950/30 border border-purple-500/35 flex items-center justify-between gap-3">
                <div>
                  <p className="text-sm font-bold text-white">{t.ownerLabel}</p>
                </div>
                <span className="text-xs font-semibold text-purple-300">{t.fullPermissions}</span>
              </div>

              {/* Add Admin Form */}
              <form
                onSubmit={handleAddAdmin}
                className="p-4 rounded-xl bg-zinc-900/60 border border-zinc-800 space-y-3.5"
              >
                <h3 className="text-sm font-bold text-white">{t.addAdminHeading}</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input
                    type="email"
                    value={newAdminEmail}
                    onChange={(e) => setNewAdminEmail(e.target.value)}
                    dir="ltr"
                    placeholder="example@gmail.com"
                    className="px-3.5 py-2.5 rounded-xl bg-black border border-zinc-800 focus:border-purple-500 focus:outline-none text-sm text-white"
                    required
                  />
                  <input
                    type="text"
                    value={newAdminName}
                    maxLength={80}
                    onChange={(e) => setNewAdminName(e.target.value)}
                    placeholder={t.adminNamePlaceholder}
                    className="px-3.5 py-2.5 rounded-xl bg-black border border-zinc-800 focus:border-purple-500 focus:outline-none text-sm text-white"
                  />
                </div>
                <div className="flex flex-wrap items-center gap-4 pt-1">
                  <label className="flex items-center gap-2 text-xs sm:text-sm text-zinc-200 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newCanBranding}
                      onChange={(e) => setNewCanBranding(e.target.checked)}
                      className="accent-purple-500 w-4 h-4"
                    />
                    <span>{t.permEditBranding}</span>
                  </label>
                  <label className="flex items-center gap-2 text-xs sm:text-sm text-zinc-200 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newCanLinks}
                      onChange={(e) => setNewCanLinks(e.target.checked)}
                      className="accent-purple-500 w-4 h-4"
                    />
                    <span>{t.permEditLinks}</span>
                  </label>
                  <label className="flex items-center gap-2 text-xs sm:text-sm text-zinc-200 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newCanBot}
                      onChange={(e) => setNewCanBot(e.target.checked)}
                      className="accent-purple-500 w-4 h-4"
                    />
                    <span>{t.permEditBot}</span>
                  </label>
                </div>
                <div className="flex justify-end">
                  <button
                    type="submit"
                    disabled={adminSaving}
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white text-xs sm:text-sm font-bold cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>{adminSaving ? t.addingAdmin : t.addAdminBtn}</span>
                  </button>
                </div>
              </form>

              {/* Current Delegated Admins */}
              <div className="space-y-2.5">
                <h3 className="text-sm font-bold text-white">
                  {t.addedAdminsHeading} ({adminsList.length})
                </h3>
                {adminsList.length === 0 ? (
                  <p className="text-xs text-zinc-400 py-3">{t.noAddedAdmins}</p>
                ) : (
                  <div className="space-y-2.5">
                    {adminsList.map((admin) => {
                      const matchedUser = usersList.find(
                        (u) => u.email.toLowerCase() === admin.email.toLowerCase(),
                      );
                      const adminLabel =
                        admin.displayName?.trim() ||
                        (matchedUser ? getMemberUsername(matchedUser) : t.adminFallbackName);

                      return (
                        <div
                          key={admin.email}
                          className="p-3.5 rounded-xl bg-zinc-900/60 border border-zinc-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                        >
                          <div className="flex items-center gap-2">
                            <UserIcon className="w-4 h-4 text-purple-400 shrink-0" />
                            <p className="text-sm font-semibold text-white">{adminLabel}</p>
                          </div>
                          <div className="flex flex-wrap items-center gap-3">
                            <label className="flex items-center gap-1.5 text-xs text-zinc-300 cursor-pointer">
                              <input
                                type="checkbox"
                                checked={admin.canEditBranding}
                                onChange={() => handleToggleAdminPerm(admin, 'canEditBranding')}
                                className="accent-purple-500 w-4 h-4"
                              />
                              <span>{t.permShortBranding}</span>
                            </label>
                            <label className="flex items-center gap-1.5 text-xs text-zinc-300 cursor-pointer">
                              <input
                                type="checkbox"
                                checked={admin.canEditLinks}
                                onChange={() => handleToggleAdminPerm(admin, 'canEditLinks')}
                                className="accent-purple-500 w-4 h-4"
                              />
                              <span>{t.permShortLinks}</span>
                            </label>
                            <label className="flex items-center gap-1.5 text-xs text-zinc-300 cursor-pointer">
                              <input
                                type="checkbox"
                                checked={Boolean(admin.canEditBot)}
                                onChange={() => handleToggleAdminPerm(admin, 'canEditBot')}
                                className="accent-purple-500 w-4 h-4"
                              />
                              <span>{t.permShortBot}</span>
                            </label>
                            <button
                              type="button"
                              onClick={() => handleRemoveAdmin(admin.email)}
                              className="p-1.5 rounded-lg text-zinc-400 hover:text-rose-400 hover:bg-zinc-800 cursor-pointer"
                              aria-label={t.removeAdminAria}
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Registered Users List (Username only - emails hidden) */}
              <div className="space-y-2.5 pt-2 border-t border-zinc-800/80">
                <h3 className="text-sm font-bold text-white">
                  {t.registeredMembers} ({usersList.length})
                </h3>
                {usersList.length === 0 ? (
                  <p className="text-xs text-zinc-400">{t.noMembersYet}</p>
                ) : (
                  <div className="space-y-2 max-h-48 overflow-y-auto">
                    {usersList.map((u) => {
                      const memberUsername = getMemberUsername(u);
                      return (
                        <div
                          key={u.uid}
                          className="px-3.5 py-2.5 rounded-xl bg-zinc-900/40 border border-zinc-800/70 flex items-center justify-between gap-3"
                        >
                          <div className="min-w-0 flex items-center gap-2">
                            <UserIcon className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                            <p className="text-xs sm:text-sm font-semibold text-white truncate">
                              {memberUsername}
                            </p>
                          </div>
                          {u.email.toLowerCase() !== SUPER_ADMIN_EMAIL &&
                            !adminsList.some((a) => a.email === u.email.toLowerCase()) && (
                              <button
                                type="button"
                                onClick={() => {
                                  setNewAdminEmail(u.email.toLowerCase());
                                  setNewAdminName(memberUsername);
                                }}
                                className="px-2.5 py-1 rounded-lg bg-purple-600/20 hover:bg-purple-600/35 border border-purple-500/30 text-xs text-purple-200 whitespace-nowrap shrink-0 cursor-pointer"
                              >
                                {t.promoteAdmin}
                              </button>
                            )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
