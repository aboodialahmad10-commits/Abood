import { WifiOff } from 'lucide-react';
import { Language, TRANSLATIONS } from '../i18n';

interface OfflineIndicatorProps {
  isOnline: boolean;
  lang: Language;
}

export function OfflineIndicator({ isOnline, lang }: OfflineIndicatorProps) {
  if (isOnline) return null;
  const t = TRANSLATIONS[lang];

  return (
    <div
      role="status"
      className="mx-auto w-fit max-w-[92vw] px-3.5 py-1.5 rounded-xl bg-amber-950/90 border border-amber-500/50 text-amber-100 text-xs font-semibold flex items-center gap-2 backdrop-blur-md shadow-lg"
    >
      <WifiOff className="w-3.5 h-3.5 shrink-0 text-amber-400" />
      <span>{t.pwaOfflineBanner}</span>
    </div>
  );
}
