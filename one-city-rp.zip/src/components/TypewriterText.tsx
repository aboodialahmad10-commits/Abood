import { useEffect, useState } from 'react';

interface TypewriterTextProps {
  messages: string[];
  neonColor: string;
}

export function TypewriterText({ messages, neonColor }: TypewriterTextProps) {
  const cleanMessages = messages.filter((m) => m.trim().length > 0);
  const safeMessages =
    cleanMessages.length > 0 ? cleanMessages : ['مرحباً بكم في One City RP'];

  const [messageIndex, setMessageIndex] = useState(0);
  const [displayedCount, setDisplayedCount] = useState(0);
  const [isDeleting, setIsDeleting] = useState(false);

  const currentText = safeMessages[messageIndex % safeMessages.length];

  useEffect(() => {
    setMessageIndex(0);
    setDisplayedCount(0);
    setIsDeleting(false);
  }, [messages.join('|')]);

  useEffect(() => {
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReducedMotion) {
      setDisplayedCount(currentText.length);
      return;
    }

    let timeoutId: number;

    if (!isDeleting && displayedCount < currentText.length) {
      timeoutId = window.setTimeout(() => {
        setDisplayedCount((prev) => prev + 1);
      }, 48);
    } else if (!isDeleting && displayedCount >= currentText.length) {
      timeoutId = window.setTimeout(() => {
        if (safeMessages.length > 1) {
          setIsDeleting(true);
        }
      }, 2400);
    } else if (isDeleting && displayedCount > 0) {
      timeoutId = window.setTimeout(() => {
        setDisplayedCount((prev) => prev - 1);
      }, 24);
    } else {
      setIsDeleting(false);
      setMessageIndex((prev) => (prev + 1) % safeMessages.length);
    }

    return () => window.clearTimeout(timeoutId);
  }, [currentText, displayedCount, isDeleting, safeMessages.length]);

  const visibleSlice = currentText.slice(0, displayedCount);

  return (
    <div
      className="min-h-[3.25rem] flex items-center justify-center px-4 text-center"
      aria-live="polite"
    >
      <p
        className="text-sm sm:text-base font-medium text-zinc-200 tracking-wide leading-relaxed max-w-md"
        style={{
          textShadow: `0 0 14px ${neonColor}55`,
        }}
      >
        <span>{visibleSlice}</span>
        <span
          aria-hidden="true"
          className="inline-block w-[2px] h-[1.1em] align-middle mr-1.5 animate-cursor-blink rounded-full"
          style={{
            backgroundColor: neonColor,
            boxShadow: `0 0 8px ${neonColor}`,
          }}
        />
      </p>
    </div>
  );
}
