import { useEffect, useState } from 'react';
import {
  CheckCircle2,
  ExternalLink,
  Monitor,
  Share,
  Smartphone,
} from 'lucide-react';
import { Language, TRANSLATIONS } from '../i18n';

interface PWAInstallModalProps {
  isOpen: boolean;
  justInstalled: boolean;
  onClose: () => void;
  onOpenApp?: () => void;
  onInstallClick: () => Promise<'accepted' | 'dismissed' | 'unavailable'>;
  onDirectDownload: () => Promise<void> | void;
  canPromptNatively: boolean;
  isIOS: boolean;
  isAndroid: boolean;
  isInIframe: boolean;
  neonColor: string;
  lang: Language;
  inlineGate?: boolean;
}

type GuidePlatform = 'desktop' | 'android' | 'iphone';
type ModalViewStage = 'confirm' | 'installing' | 'installed' | 'guide';

export function PWAInstallModal({
  isOpen,
  justInstalled,
  onClose,
  onOpenApp,
  onInstallClick,
  onDirectDownload,
  canPromptNatively,
  isIOS,
  isAndroid,
  isInIframe,
  neonColor,
  lang,
  inlineGate = false,
}: PWAInstallModalProps) {
  const t = TRANSLATIONS[lang];
  const defaultPlatform: GuidePlatform = isIOS
    ? 'iphone'
    : isAndroid
      ? 'android'
      : 'desktop';
  const [stage, setStage] = useState<ModalViewStage>(justInstalled ? 'installed' : 'confirm');
  const [guidePlatform, setGuidePlatform] = useState<GuidePlatform>(defaultPlatform);

  useEffect(() => {
    if (isOpen) {
      setStage(justInstalled ? 'installed' : 'confirm');
      setGuidePlatform(defaultPlatform);
    }
  }, [isOpen, justInstalled, defaultPlatform]);

  if (!isOpen) return null;

  const handleInstallTap = async () => {
    if (canPromptNatively) {
      const outcome = await onInstallClick();
      if (outcome === 'accepted') {
        setStage('installed');
        return;
      }
      if (outcome === 'dismissed') {
        return;
      }
    }

    // Immediate download + Android-style installing -> installed -> Open flow
    setStage('installing');
    try {
      await onDirectDownload();
    } finally {
      window.setTimeout(() => {
        setStage('installed');
      }, 650);
    }
  };

  const handleOpenClick = () => {
    if (onOpenApp) {
      onOpenApp();
    } else {
      onClose();
    }
  };

  const steps =
    guidePlatform === 'iphone'
      ? t.pwaIphoneSteps
      : guidePlatform === 'android'
        ? t.pwaAndroidSteps
        : t.pwaDesktopSteps;

  const wrapperClass = inlineGate
    ? 'w-full flex items-center justify-center p-4'
    : 'fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm';

  return (
    <div
      className={wrapperClass}
      role="dialog"
      aria-modal={!inlineGate}
      aria-label={t.pwaAppName}
    >
      <div className="w-full max-w-[340px] rounded-[22px] bg-white text-zinc-900 shadow-[0_18px_50px_rgba(0,0,0,0.45)] overflow-hidden border border-zinc-200">
        {stage === 'confirm' && (
          <>
            <div className="px-6 pt-5 pb-4">
              <div className="flex items-center gap-3 mb-3.5">
                <img
                  src="/pwa-192x192.png"
                  alt={t.pwaAppName}
                  className="w-8 h-8 rounded-full object-contain bg-black p-0.5 border border-zinc-200 shrink-0"
                />
                <h2 className="text-[15px] font-bold text-zinc-900 tracking-tight truncate">
                  {t.pwaAppName}
                </h2>
              </div>

              <p className="text-[15px] font-medium text-zinc-700 leading-relaxed">
                {t.pwaQuestionOnly}
              </p>
            </div>

            <div className="grid grid-cols-2 border-t border-zinc-200 divide-x rtl:divide-x-reverse divide-zinc-200">
              <button
                type="button"
                onClick={handleInstallTap}
                className="py-3.5 px-4 text-sm font-bold text-[#0f9d58] hover:bg-emerald-50/70 active:bg-emerald-100/70 transition-colors cursor-pointer"
              >
                {t.pwaYesInstallBtn}
              </button>
              <button
                type="button"
                onClick={onClose}
                className="py-3.5 px-4 text-sm font-semibold text-zinc-600 hover:bg-zinc-100 active:bg-zinc-200 transition-colors cursor-pointer"
              >
                {t.pwaCancelBtn}
              </button>
            </div>
          </>
        )}

        {stage === 'installing' && (
          <div className="px-6 py-6 space-y-4">
            <div className="flex items-center gap-3">
              <img
                src="/pwa-192x192.png"
                alt={t.pwaAppName}
                className="w-8 h-8 rounded-full object-contain bg-black p-0.5 border border-zinc-200 shrink-0"
              />
              <h2 className="text-[15px] font-bold text-zinc-900 truncate">
                {t.pwaAppName}
              </h2>
            </div>

            <p className="text-sm font-medium text-zinc-600">{t.pwaInstallingLabel}</p>

            <div className="w-full h-1.5 rounded-full bg-zinc-200 overflow-hidden">
              <div className="h-full w-2/3 rounded-full bg-[#0f9d58] animate-pulse" />
            </div>
          </div>
        )}

        {stage === 'installed' && (
          <>
            <div className="px-6 pt-5 pb-4">
              <div className="flex items-center gap-3 mb-3.5">
                <img
                  src="/pwa-192x192.png"
                  alt={t.pwaAppName}
                  className="w-8 h-8 rounded-full object-contain bg-black p-0.5 border border-emerald-400 shrink-0"
                />
                <h2 className="text-[15px] font-bold text-zinc-900 truncate">
                  {t.pwaAppName}
                </h2>
              </div>

              <div className="flex items-center gap-2 text-[#0f9d58]">
                <CheckCircle2 className="w-5 h-5 shrink-0" />
                <p className="text-[15px] font-bold">{t.pwaReadyTitle}</p>
              </div>
              <p className="text-xs text-zinc-500 mt-1.5 leading-relaxed">
                {t.pwaReadyDesc}
              </p>

              <button
                type="button"
                onClick={() => setStage('guide')}
                className="mt-3 text-[11px] font-semibold text-zinc-500 hover:text-zinc-800 underline underline-offset-2 cursor-pointer"
              >
                {t.pwaShowStepsBtn}
              </button>
            </div>

            <div className="grid grid-cols-2 border-t border-zinc-200 divide-x rtl:divide-x-reverse divide-zinc-200">
              <button
                type="button"
                onClick={handleOpenClick}
                className="py-3.5 px-4 text-sm font-bold text-[#0f9d58] hover:bg-emerald-50/70 active:bg-emerald-100/70 transition-colors cursor-pointer"
              >
                {t.pwaOpenAppBtn}
              </button>
              <button
                type="button"
                onClick={onClose}
                className="py-3.5 px-4 text-sm font-semibold text-zinc-600 hover:bg-zinc-100 active:bg-zinc-200 transition-colors cursor-pointer"
              >
                {t.pwaDoneShort}
              </button>
            </div>
          </>
        )}

        {stage === 'guide' && (
          <>
            <div className="px-5 pt-5 pb-4 space-y-3">
              <div className="flex items-center gap-2.5">
                <img
                  src="/pwa-192x192.png"
                  alt={t.pwaAppName}
                  className="w-8 h-8 rounded-full object-contain bg-black p-0.5 border border-zinc-200 shrink-0"
                />
                <div className="min-w-0">
                  <h2 className="text-sm font-bold text-zinc-900 truncate">
                    {t.pwaGuideTitle}
                  </h2>
                  <p className="text-[11px] text-zinc-500 truncate">
                    {t.pwaAppName}
                  </p>
                </div>
              </div>

              {isInIframe && (
                <a
                  href={typeof window !== 'undefined' ? window.location.href : '/'}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-2 px-3 rounded-xl text-xs font-bold text-white bg-[#0f9d58] hover:brightness-110 flex items-center justify-center gap-1.5 transition-all"
                >
                  <ExternalLink className="w-3.5 h-3.5 shrink-0" />
                  <span>{t.pwaOpenBrowserBtn}</span>
                </a>
              )}

              <div className="grid grid-cols-3 gap-1 p-1 rounded-xl bg-zinc-100">
                <button
                  type="button"
                  onClick={() => setGuidePlatform('desktop')}
                  className={`flex items-center justify-center gap-1 py-1.5 px-1.5 rounded-lg text-[11px] font-bold transition-colors cursor-pointer ${
                    guidePlatform === 'desktop'
                      ? 'bg-white text-zinc-900 shadow-sm'
                      : 'text-zinc-500 hover:text-zinc-800'
                  }`}
                >
                  <Monitor className="w-3.5 h-3.5 shrink-0" />
                  <span>{t.pwaTabDesktop}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setGuidePlatform('android')}
                  className={`flex items-center justify-center gap-1 py-1.5 px-1.5 rounded-lg text-[11px] font-bold transition-colors cursor-pointer ${
                    guidePlatform === 'android'
                      ? 'bg-white text-zinc-900 shadow-sm'
                      : 'text-zinc-500 hover:text-zinc-800'
                  }`}
                >
                  <Smartphone className="w-3.5 h-3.5 shrink-0" />
                  <span>{t.pwaTabAndroid}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setGuidePlatform('iphone')}
                  className={`flex items-center justify-center gap-1 py-1.5 px-1.5 rounded-lg text-[11px] font-bold transition-colors cursor-pointer ${
                    guidePlatform === 'iphone'
                      ? 'bg-white text-zinc-900 shadow-sm'
                      : 'text-zinc-500 hover:text-zinc-800'
                  }`}
                >
                  <Share className="w-3.5 h-3.5 shrink-0" />
                  <span>{t.pwaTabIphone}</span>
                </button>
              </div>

              <ol className="space-y-1.5">
                {steps.map((step, idx) => (
                  <li
                    key={idx}
                    className="flex items-start gap-2 p-2 rounded-lg bg-zinc-50 border border-zinc-200/80 text-[11px] text-zinc-700 leading-relaxed"
                  >
                    <span
                      className="w-4 h-4 rounded-full flex items-center justify-center text-[10px] font-bold text-white shrink-0 mt-0.5"
                      style={{ backgroundColor: neonColor || '#0f9d58' }}
                    >
                      {idx + 1}
                    </span>
                    <span>{step}</span>
                  </li>
                ))}
              </ol>
            </div>

            <div className="grid grid-cols-2 border-t border-zinc-200 divide-x rtl:divide-x-reverse divide-zinc-200">
              <button
                type="button"
                onClick={handleOpenClick}
                className="py-3.5 px-4 text-sm font-bold text-[#0f9d58] hover:bg-emerald-50/70 transition-colors cursor-pointer"
              >
                {t.pwaOpenAppBtn}
              </button>
              <button
                type="button"
                onClick={onClose}
                className="py-3.5 px-4 text-sm font-semibold text-zinc-600 hover:bg-zinc-100 transition-colors cursor-pointer"
              >
                {t.pwaDoneShort}
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
