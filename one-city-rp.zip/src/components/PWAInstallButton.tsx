import { Download } from 'lucide-react';
import { Language, TRANSLATIONS } from '../i18n';

interface PWAInstallButtonProps {
  isInstalled: boolean;
  onClick: () => void;
  neonColor: string;
  lang: Language;
}

export function PWAInstallButton({
  isInstalled,
  onClick,
  neonColor,
  lang,
}: PWAInstallButtonProps) {
  if (isInstalled) return null;
  const t = TRANSLATIONS[lang];

  return (
    <button
      type="button"
      onClick={onClick}
      className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-black/65 hover:bg-zinc-900/90 border text-xs sm:text-sm font-semibold text-white transition-all duration-200 whitespace-nowrap shrink-0 cursor-pointer backdrop-blur-md"
      style={{
        borderColor: `${neonColor}70`,
        boxShadow: `0 0 16px ${neonColor}2a`,
      }}
    >
      <Download className="w-4 h-4 shrink-0" style={{ color: neonColor }} />
      <span>{t.pwaInstallBtn}</span>
    </button>
  );
}
