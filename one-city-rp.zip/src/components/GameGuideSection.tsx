import React, { useState } from 'react';
import { BookOpen, Compass, ShieldCheck, Briefcase } from 'lucide-react';
import { Language, TRANSLATIONS } from '../i18n';

interface GameGuideSectionProps {
  neonColor: string;
  lang: Language;
  siteName: string;
}

type GuideTab = 'overview' | 'start' | 'rules' | 'careers';

export const GameGuideSection: React.FC<GameGuideSectionProps> = ({
  neonColor,
  lang,
  siteName,
}) => {
  const [activeTab, setActiveTab] = useState<GuideTab>('overview');
  const t = TRANSLATIONS[lang];

  const tabs: Array<{ id: GuideTab; label: string; Icon: React.ComponentType<{ className?: string }> }> = [
    { id: 'overview', label: t.guideTabOverview, Icon: BookOpen },
    { id: 'start', label: t.guideTabStart, Icon: Compass },
    { id: 'rules', label: t.guideTabRules, Icon: ShieldCheck },
    { id: 'careers', label: t.guideTabCareers, Icon: Briefcase },
  ];

  return (
    <section
      id="game-guide"
      aria-labelledby="game-guide-heading"
      className="w-full max-w-4xl mt-8 rounded-2xl bg-[#050816]/82 backdrop-blur-xl border border-white/[0.1] overflow-hidden"
      style={{
        boxShadow: `0 18px 46px rgba(0,0,0,0.68), 0 0 28px ${neonColor}1c`,
      }}
    >
      {/* Header & Interactive Tab Selector */}
      <div className="px-6 py-6 sm:px-8 border-b border-white/[0.08] flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div className="min-w-0">
          <h2
            id="game-guide-heading"
            className="text-lg sm:text-2xl font-extrabold text-white text-balance"
          >
            {lang === 'ar' ? `شرح لعبة ${siteName || 'One City RP'}` : t.guideSectionTitle}
          </h2>
          <p className="mt-1 text-xs sm:text-sm text-zinc-400 leading-relaxed max-w-xl">
            {t.guideSectionSubtitle}
          </p>
        </div>

        <div
          role="tablist"
          aria-label={t.guideSectionTitle}
          className="flex flex-wrap sm:flex-nowrap items-center gap-1.5 p-1.5 rounded-xl bg-black/55 border border-white/[0.08] shrink-0"
        >
          {tabs.map(({ id, label, Icon }) => {
            const isActive = activeTab === id;
            return (
              <button
                key={id}
                type="button"
                role="tab"
                aria-selected={isActive}
                onClick={() => setActiveTab(id)}
                className={`inline-flex items-center gap-1.5 px-3 py-2 min-h-[38px] rounded-lg text-xs font-bold whitespace-nowrap shrink-0 transition-all duration-150 cursor-pointer ${
                  isActive
                    ? 'text-white'
                    : 'text-zinc-400 hover:text-white hover:bg-white/[0.05]'
                }`}
                style={
                  isActive
                    ? {
                        backgroundColor: `${neonColor}33`,
                        borderColor: `${neonColor}80`,
                        boxShadow: `0 0 16px ${neonColor}30`,
                      }
                    : undefined
                }
              >
                <Icon className="w-3.5 h-3.5 shrink-0" />
                <span>{label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Tab Panels */}
      <div className="p-6 sm:p-8" role="tabpanel">
        {activeTab === 'overview' && (
          <div className="space-y-6">
            <p className="text-sm sm:text-base text-zinc-200 leading-relaxed max-w-3xl">
              {t.guideOverviewLead}
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-white/[0.06]">
              {t.guideOverviewItems.map((item) => (
                <div
                  key={item.num}
                  className="p-4 rounded-xl bg-white/[0.025] border border-white/[0.07] transition-colors hover:border-white/20"
                >
                  <div className="flex items-baseline gap-2.5 mb-1.5">
                    <span
                      className="font-mono tabular-nums text-xs font-bold"
                      style={{ color: neonColor }}
                    >
                      {item.num}.
                    </span>
                    <h3 className="text-sm sm:text-base font-bold text-white">{item.title}</h3>
                  </div>
                  <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'start' && (
          <ol className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {t.guideStartSteps.map((step) => (
              <li
                key={step.num}
                className="p-4 rounded-xl bg-white/[0.025] border border-white/[0.07] transition-colors hover:border-white/20"
              >
                <div className="flex items-baseline gap-2.5 mb-1.5">
                  <span
                    className="font-mono tabular-nums text-sm font-extrabold"
                    style={{ color: neonColor }}
                  >
                    {step.num}
                  </span>
                  <h3 className="text-sm sm:text-base font-bold text-white">{step.title}</h3>
                </div>
                <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed">{step.desc}</p>
              </li>
            ))}
          </ol>
        )}

        {activeTab === 'rules' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {t.guideRules.map((rule) => (
              <div
                key={rule.code}
                className="p-4 rounded-xl bg-white/[0.025] border border-white/[0.07] transition-colors hover:border-white/20"
              >
                <div className="flex items-center justify-between gap-3 mb-1.5">
                  <h3 className="text-sm sm:text-base font-bold text-white">{rule.title}</h3>
                  <span
                    className="font-mono text-[11px] font-semibold shrink-0"
                    style={{ color: neonColor }}
                  >
                    {rule.code}
                  </span>
                </div>
                <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed">{rule.desc}</p>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'careers' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {t.guideCareers.map((career) => (
              <div
                key={career.code}
                className="p-4 rounded-xl bg-white/[0.025] border border-white/[0.07] transition-colors hover:border-white/20"
              >
                <div className="flex items-center justify-between gap-3 mb-1.5">
                  <h3 className="text-sm sm:text-base font-bold text-white">{career.title}</h3>
                  <span className="text-xs font-medium text-zinc-400 shrink-0">
                    {career.code}
                  </span>
                </div>
                <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed">{career.desc}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
};
