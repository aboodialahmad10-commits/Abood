# One City RP — Standalone Web Project

هذا مجلد مشروع ويب مستقل بالكامل مبني باستخدام **HTML + CSS + JavaScript** دون أي اعتماد على Google AI Studio.

## هيكل الملفات
- `index.html` — الصفحة الرئيسية وبوابة الأعضاء ولوحة الإدارة
- `css/style.css` — التصميم الكامل (الخلفية السوداء، التوهج البنفسجي، التجاوب، RTL/LTR)
- `js/config.js` — الإعدادات العامة، الروابط، الأخبار والفصائل الافتراضية، وإعدادات Firebase
- `js/i18n.js` — قاموس اللغة العربية والإنجليزية
- `js/starfield.js` — تأثير النجوم المتحركة بالخلفية
- `js/ai.js` — المساعد الذكي التفاعلي للأخبار والفصائل وأفكار الرول بلاي
- `js/app.js` — منطق الموقع الكامل وتسجيل الدخول وإدارة الصلاحيات
- `assets/logo.png` — شعار المدينة

## طريقة الرفع والاستضافة الخارجية
1. ارفع جميع محتويات هذا المجلد (بحيث يكون `index.html` في الجذر الرئيسي) إلى أي استضافة ويب مثل:
   - **Netlify Drop** (`app.netlify.com/drop`) — اسحب المجلد وأفلته مباشرة
   - **GitHub Pages**
   - **Cloudflare Pages**
   - **Vercel** أو أي استضافة cPanel / Apache / Nginx
2. لتفعيل تسجيل الدخول (Email/Password و Google) على الدومين الجديد:
   - افتح **Firebase Console** -> مشروع `restful-subject-jmn89`
   - اذهب إلى **Authentication -> Settings -> Authorized domains**
   - أضف رابط موقعك الجديد (مثل `yoursite.netlify.app`).
