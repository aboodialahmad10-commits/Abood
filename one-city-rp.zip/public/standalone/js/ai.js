import { AI_API_ENDPOINT } from './config.js';
import { DEFAULT_FACTION_EN_MAP, TRANSLATIONS } from './i18n.js';

function formatLinksList(buttons, isEn) {
  const active = (Array.isArray(buttons) ? buttons : []).filter(
    (b) => b && b.enabled && String(b.url || '').trim().length > 0,
  );
  if (active.length === 0) {
    return isEn
      ? '• Discord: https://discord.gg/aUzckMe3qY\n• TikTok: https://www.tiktok.com/@onecityrp8?_r=1&_t=ZS-9BZOJHD47RV'
      : '• سيرفر ديسكورد: https://discord.gg/aUzckMe3qY\n• حساب تيك توك: https://www.tiktok.com/@onecityrp8?_r=1&_t=ZS-9BZOJHD47RV';
  }
  return active
    .map((b) => {
      const raw = String(b.url).trim();
      const safe = /^https?:\/\//i.test(raw) ? raw : `https://${raw}`;
      return `${b.icon || '🔗'} ${b.label}: ${safe}`;
    })
    .join('\n');
}

function buildLocalAssistantReply(message, siteName, botInfo, buttons, lang) {
  const q = message.toLowerCase();
  const isEn = lang === 'en' && !/[\u0600-\u06FF]/.test(message);

  // 1. News & Updates queries
  if (
    q.includes('اخبار') ||
    q.includes('أخبار') ||
    q.includes('تحديث') ||
    q.includes('جديد') ||
    q.includes('news') ||
    q.includes('update') ||
    q.includes('latest')
  ) {
    const items = botInfo.news || [];
    if (items.length === 0) {
      return isEn
        ? `There are no published news updates on ${siteName} yet.`
        : `لا توجد أخبار أو تحديثات منشورة في ${siteName} حالياً.`;
    }
    const header = isEn ? `Latest updates on ${siteName}:` : `آخر أخبار وتحديثات ${siteName}:`;
    const list = items
      .slice(0, 6)
      .map((n, i) => `${i + 1}. ${n.title}${n.date ? ` (${n.date})` : ''}\n   ${n.content}`)
      .join('\n\n');
    return `${header}\n\n${list}`;
  }

  // 2. Factions queries
  if (
    q.includes('فصيل') ||
    q.includes('فصائل') ||
    q.includes('شرط') ||
    q.includes('طب') ||
    q.includes('جيش') ||
    q.includes('تقديم') ||
    q.includes('انضم') ||
    q.includes('faction') ||
    q.includes('police') ||
    q.includes('ems') ||
    q.includes('army') ||
    q.includes('join')
  ) {
    const factions = botInfo.factions || [];
    const statusMap = TRANSLATIONS[isEn ? 'en' : 'ar'].statusMap;
    const header = isEn
      ? `Available factions in ${siteName} (applications are handled through the official Discord server):`
      : `الفصائل المتاحة في ${siteName} (التقديم يتم عبر سيرفر الديسكورد الرسمي):`;
    const lines = factions
      .map((f) => {
        const enMatch = isEn ? DEFAULT_FACTION_EN_MAP[f.id] : null;
        const name = enMatch && f.name === enMatch.arName ? enMatch.name : f.name;
        const desc = enMatch && f.description === enMatch.arDesc ? enMatch.description : f.description;
        const status = statusMap[f.status] || f.status;
        return `${f.icon || '🛡️'} ${name} — (${status})${desc ? `\n   ${desc}` : ''}`;
      })
      .join('\n\n');
    return `${header}\n\n${lines}`;
  }

  // 3. RP Character / Backstory ideas
  if (
    q.includes('شخصي') ||
    q.includes('قصة') ||
    q.includes('رول') ||
    q.includes('فكرة') ||
    q.includes('character') ||
    q.includes('idea') ||
    q.includes('backstory')
  ) {
    const ideasAr = [
      `• مسعف طموح انضم حديثاً إلى ${siteName} ويسعى لإنقاذ الأرواح وبناء فريق إسعاف سريع الاستجابة.`,
      `• ضابط شرطة هادئ ومحنك متخصص في التحقيقات والتفاوض السلمي وحفظ أمن المدينة.`,
      `• عضو مجتهد يبدأ مسيرته في ${siteName} بتأسيس مشروعه التجاري القانوني وبناء شبكة علاقات قوية.`,
    ];
    const ideasEn = [
      `• A dedicated paramedic who joined ${siteName} to build a rapid-response medical team.`,
      `• A calm detective focused on investigation, peaceful negotiation, and city safety.`,
      `• An ambitious citizen starting a legal business in ${siteName} and building strong community ties.`,
    ];
    return isEn
      ? `Here are 3 RP character ideas for ${siteName}:\n\n${ideasEn.join('\n')}`
      : `إليك 3 أفكار لشخصيات رول بلاي مميزة في ${siteName}:\n\n${ideasAr.join('\n')}`;
  }

  // 4. Discord / TikTok / Links queries
  if (
    q.includes('ديسكورد') ||
    q.includes('تيك') ||
    q.includes('رابط') ||
    q.includes('روابط') ||
    q.includes('حساب') ||
    q.includes('discord') ||
    q.includes('tiktok') ||
    q.includes('link')
  ) {
    const linksText = formatLinksList(buttons, isEn);
    return isEn
      ? `Official ${siteName} links:\n\n${linksText}`
      : `الروابط الرسمية لمجتمع ${siteName}:\n\n${linksText}`;
  }

  // 5. About One City RP queries (strictly One City RP only, zero external game mentions)
  if (
    q.includes('ون سيتي') ||
    q.includes('ون ستي') ||
    q.includes('one city') ||
    q.includes('onecity') ||
    q.includes('ما هو') ||
    q.includes('شنو') ||
    q.includes('وش') ||
    q.includes('تعريف') ||
    q.includes('about')
  ) {
    const linksText = formatLinksList(buttons, isEn);
    return isEn
      ? `${siteName} is an integrated real-life roleplay community offering organized factions (Police, EMS, Army), continuous updates, and an active Discord community.\n\nOfficial links:\n${linksText}`
      : `${siteName} هو مجتمع وسيرفر حياة واقعية متكامل يضم قطاعات رسمية منظمة (الشرطة، الطب، الجيش) وتحديثات مستمرة وأجواء احترافية.\n\nالروابط الرسمية:\n${linksText}`;
  }

  // 6. General fallback
  return isEn
    ? `Welcome to ${siteName}! Ask me about ${siteName}, the latest updates, available factions (Police, EMS, Army), official links, or character ideas.`
    : `أهلاً بك في ${siteName}! يمكنك سؤالي عن ${siteName}، آخر الأخبار والتحديثات، الفصائل المتاحة (الشرطة، الطب، الجيش)، الروابط الرسمية، أو أفكار الشخصيات.`;
}

export async function askAssistant(message, history, { siteName, botInfo, buttons, lang }) {
  const endpoint = (AI_API_ENDPOINT || '').trim();
  if (endpoint) {
    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message,
          history,
          siteName,
          botContext: {
            news: botInfo.news,
            factions: botInfo.factions,
            links: (Array.isArray(buttons) ? buttons : [])
              .filter((b) => b && b.enabled && String(b.url || '').trim().length > 0)
              .map((b) => ({ label: b.label, url: String(b.url).trim(), icon: b.icon })),
          },
        }),
      });
      if (response.ok) {
        const data = await response.json();
        if (data && typeof data.reply === 'string' && data.reply.trim()) {
          return data.reply.trim();
        }
      }
    } catch {
      // Gracefully fall back to built-in offline/static assistant
    }
  }

  return buildLocalAssistantReply(message, siteName, botInfo, buttons, lang);
}
