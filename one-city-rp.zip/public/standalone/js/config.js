export const FIREBASE_CONFIG = {
  projectId: 'restful-subject-jmn89',
  appId: '1:1056900357351:web:2ed1df0ea7bbce5a9b9642',
  apiKey: 'AIzaSyByekX1Gip_KiMAme7WC4_rlOkHpe3tSoE',
  authDomain: 'restful-subject-jmn89.firebaseapp.com',
  firestoreDatabaseId: 'ai-studio-6005a356-06a5-43ca-b9b0-f4178128a37a',
  storageBucket: 'restful-subject-jmn89.firebasestorage.app',
  messagingSenderId: '1056900357351',
};

export const SUPER_ADMIN_EMAIL = 'aboodialahmad10@gmail.com';

// Optional external AI API endpoint (never hardcode Google AI Studio URLs here).
// Leave empty for pure static hosting so the built-in smart RP/News/Factions assistant responds offline & online.
export const AI_API_ENDPOINT = '';

export const DEFAULT_LOGO_PATH = './assets/logo.png';

export const DEFAULT_SITE_CONFIG = {
  siteName: 'One City RP',
  siteSubtitle: 'عالم الحياة الواقعية',
  logoUrl: DEFAULT_LOGO_PATH,
  neonColor: '#a855f7',
  welcomeMessages: [
    'مرحباً بكم في One City RP — تجربة حياة واقعية متكاملة',
    'انضم إلى مجتمعنا الآن واكتشف مدينة بلا حدود',
    'أجواء سينمائية واحترافية في انتظارك',
  ],
  buttons: [
    {
      id: 'discord',
      label: 'دخول إلى ديسكورد',
      url: 'https://discord.gg/aUzckMe3qY',
      icon: '🌐',
      enabled: true,
    },
    {
      id: 'tiktok',
      label: 'موقع التيك توك',
      url: 'https://www.tiktok.com/@onecityrp8?_r=1&_t=ZS-9BZOJHD47RV',
      icon: '🎵',
      enabled: true,
    },
    {
      id: 'game',
      label: 'دخول إلى اللعبة',
      url: '',
      icon: '🎮',
      enabled: true,
    },
  ],
};

export const DEFAULT_BOT_INFO = {
  news: [
    {
      id: 'news_1',
      title: 'افتتاح التقديم على الفصائل الرسمية',
      content: 'التقديم متاح الآن لقطاعات الشرطة والطب والجيش عبر سيرفر الديسكورد الرسمي.',
      date: '2026-11-20',
    },
    {
      id: 'news_2',
      title: 'تحديث المساعد الذكي لمجتمع One City RP',
      content: 'يمكنك الآن متابعة آخر الأخبار والتحديثات ومعرفة الفصائل المتاحة مباشرة.',
      date: '2026-11-20',
    },
  ],
  factions: [
    {
      id: 'police',
      name: 'الشرطة',
      icon: '🚓',
      status: 'مفتوح',
      description: 'حفظ الأمن والنظام داخل المدينة وملاحقة الخارجين عن القانون.',
    },
    {
      id: 'ems',
      name: 'الطب',
      icon: '🚑',
      status: 'مفتوح',
      description: 'تقديم الإسعافات الأولية والرعاية الطبية العاجلة لجميع المواطنين.',
    },
    {
      id: 'army',
      name: 'الجيش',
      icon: '🪖',
      status: 'مفتوح',
      description: 'حماية الحدود والمناطق الاستراتيجية ومساندة القوات الأمنية.',
    },
  ],
};
