export function initStarfield(canvas) {
  if (!canvas) return () => {};
  const ctx = canvas.getContext('2d');
  if (!ctx) return () => {};

  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  let width = 0;
  let height = 0;
  let stars = [];
  let animId = 0;

  function buildStars() {
    const count = Math.min(220, Math.max(90, Math.floor((width * height) / 7500)));
    stars = Array.from({ length: count }, () => {
      const layer = Math.random();
      return {
        x: Math.random() * width,
        y: Math.random() * height,
        r: layer < 0.65 ? 0.7 + Math.random() * 0.75 : 1.35 + Math.random() * 1.1,
        a: 0.25 + Math.random() * 0.75,
        da: (Math.random() * 0.015 + 0.004) * (Math.random() > 0.5 ? 1 : -1),
        vx: (Math.random() - 0.5) * (layer < 0.65 ? 0.14 : 0.32),
        vy: -(0.08 + Math.random() * (layer < 0.65 ? 0.18 : 0.36)),
      };
    });
  }

  function resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    width = window.innerWidth;
    height = window.innerHeight;
    canvas.width = Math.floor(width * dpr);
    canvas.height = Math.floor(height * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    buildStars();
    if (reducedMotion) renderFrame(false);
  }

  function renderFrame(step) {
    ctx.fillStyle = '#000000';
    ctx.fillRect(0, 0, width, height);

    for (let i = 0; i < stars.length; i++) {
      const s = stars[i];
      if (step) {
        s.x += s.vx;
        s.y += s.vy;
        s.a += s.da;
        if (s.a >= 1 || s.a <= 0.18) s.da *= -1;
        if (s.y < -4) {
          s.y = height + 4;
          s.x = Math.random() * width;
        }
        if (s.x < -4) s.x = width + 4;
        if (s.x > width + 4) s.x = -4;
      }
      ctx.beginPath();
      ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(255,255,255,${Math.max(0.15, Math.min(1, s.a)).toFixed(3)})`;
      ctx.fill();
    }
  }

  function loop() {
    renderFrame(true);
    animId = window.requestAnimationFrame(loop);
  }

  resize();
  window.addEventListener('resize', resize);
  if (!reducedMotion) {
    animId = window.requestAnimationFrame(loop);
  }

  return () => {
    window.removeEventListener('resize', resize);
    if (animId) window.cancelAnimationFrame(animId);
  };
}
