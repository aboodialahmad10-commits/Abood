import { initializeApp } from 'https://www.gstatic.com/firebasejs/11.10.0/firebase-app.js';
import {
  createUserWithEmailAndPassword,
  getAuth,
  getRedirectResult,
  GoogleAuthProvider,
  onAuthStateChanged,
  sendEmailVerification,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signInWithPopup,
  signInWithRedirect,
  signOut,
  updateProfile,
} from 'https://www.gstatic.com/firebasejs/11.10.0/firebase-auth.js';
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getFirestore,
  onSnapshot,
  serverTimestamp,
  setDoc,
  updateDoc,
} from 'https://www.gstatic.com/firebasejs/11.10.0/firebase-firestore.js';
import { askAssistant } from './ai.js';
import {
  DEFAULT_BOT_INFO,
  DEFAULT_LOGO_PATH,
  DEFAULT_SITE_CONFIG,
  FIREBASE_CONFIG,
  SUPER_ADMIN_EMAIL,
} from './config.js';
import {
  DEFAULT_BUTTON_EN_MAP,
  DEFAULT_FACTION_EN_MAP,
  TRANSLATIONS,
} from './i18n.js';
import { initStarfield } from './starfield.js';

const NEON_PRESETS = [
  { labelAr: 'بنفسجي ملكي', labelEn: 'Royal Purple', value: '#a855f7' },
  { labelAr: 'أرجواني نيون', labelEn: 'Neon Violet', value: '#c084fc' },
  { labelAr: 'نيلي عميق', labelEn: 'Deep Indigo', value: '#818cf8' },
  { labelAr: 'وردي نيون', labelEn: 'Neon Pink', value: '#ec4899' },
  { labelAr: 'سماوي فضائي', labelEn: 'Cosmic Cyan', value: '#38bdf8' },
];

const NO_PERMS = {
  isSuperAdmin: false,
  isAdmin: false,
  canEditBranding: false,
  canEditLinks: false,
  canEditBot: false,
  canManageAdmins: false,
};

const state = {
  lang: (() => {
    try {
      return localStorage.getItem('onecity_lang') === 'en' ? 'en' : 'ar';
    } catch {
      return 'ar';
    }
  })(),
  siteConfig: structuredClone(DEFAULT_SITE_CONFIG),
  configExistsInDb: false,
  botInfo: structuredClone(DEFAULT_BOT_INFO),
  botInfoExistsInDb: false,
  user: null,
  permissions: { ...NO_PERMS },
  activeView: 'home',
  guideTab: 'overview',
  loginMode: 'signin',
  adminTab: 'branding',
  draftConfig: structuredClone(DEFAULT_SITE_CONFIG),
  draftBotInfo: structuredClone(DEFAULT_BOT_INFO),
  adminsList: [],
  usersList: [],
  aiHistory: [],
  aiSending: false,
};

let firebaseReady = false;
let auth = null;
let db = null;
let googleProvider = null;

try {
  const fbApp = initializeApp(FIREBASE_CONFIG);
  auth = getAuth(fbApp);
  db = getFirestore(fbApp, FIREBASE_CONFIG.firestoreDatabaseId);
  googleProvider = new GoogleAuthProvider();
  googleProvider.setCustomParameters({ prompt: 'select_account' });
  firebaseReady = true;
} catch (err) {
  console.warn('Firebase init fallback (static offline mode):', err);
}

// DOM Helpers
const $ = (id) => document.getElementById(id);

function escapeText(value) {
  return String(value ?? '');
}

function resolveLogoSrc(rawUrl) {
  const trimmed = String(rawUrl || '').trim();
  if (
    !trimmed ||
    trimmed === './assets/crest.jpg' ||
    trimmed.startsWith('/src/assets/images/') ||
    trimmed.startsWith('/assets/aistudio/')
  ) {
    return DEFAULT_LOGO_PATH;
  }
  return trimmed;
}

function sanitizeUrl(raw) {
  const trimmed = String(raw || '').trim();
  if (!trimmed) return '';
  if (/^https?:\/\//i.test(trimmed)) return trimmed;
  return `https://${trimmed}`;
}

function sanitizeNewsImageUrl(raw) {
  const trimmed = String(raw || '').trim();
  if (!trimmed) return '';
  if (
    /^https?:\/\//i.test(trimmed) ||
    trimmed.startsWith('/assets/') ||
    trimmed.startsWith('./assets/') ||
    /^data:image\/(?:png|jpeg|jpg|webp|gif);base64,/i.test(trimmed)
  ) {
    return trimmed;
  }
  return '';
}

let toastTimer = null;
function showToast(msg) {
  const el = $('toast');
  if (!el) return;
  el.textContent = msg;
  el.classList.remove('hidden');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.add('hidden'), 3200);
}

// Starfield Init
initStarfield($('starfield'));

// Typewriter Controller
let typewriterTimer = null;
let typewriterMessages = [];
let twIdx = 0;
let twPos = 0;
let twDeleting = false;

function startTypewriter(messages) {
  const el = $('typewriter-text');
  if (!el) return;
  typewriterMessages = messages && messages.length > 0 ? messages : ['One City RP'];
  twIdx = 0;
  twPos = 0;
  twDeleting = false;
  clearTimeout(typewriterTimer);

  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (reduced) {
    el.textContent = typewriterMessages[0];
    return;
  }

  function step() {
    const cur = typewriterMessages[twIdx % typewriterMessages.length] || '';
    if (!twDeleting) {
      if (twPos < cur.length) {
        twPos++;
        el.textContent = cur.slice(0, twPos);
        typewriterTimer = setTimeout(step, 46);
      } else if (typewriterMessages.length > 1) {
        twDeleting = true;
        typewriterTimer = setTimeout(step, 2400);
      }
    } else {
      if (twPos > 0) {
        twPos--;
        el.textContent = cur.slice(0, twPos);
        typewriterTimer = setTimeout(step, 24);
      } else {
        twDeleting = false;
        twIdx = (twIdx + 1) % typewriterMessages.length;
        typewriterTimer = setTimeout(step, 260);
      }
    }
  }

  step();
}

function getButtonLabel(btn) {
  const t = TRANSLATIONS[state.lang];
  const map = DEFAULT_BUTTON_EN_MAP[btn.id];
  if (map) {
    if (state.lang === 'en' && map.ar.includes(btn.label)) {
      return map.en;
    }
    if (state.lang === 'ar' && btn.id === 'discord' && btn.label === 'سيرفر ديسكورد') {
      return t.discordDefaultCta;
    }
    if (state.lang === 'ar' && btn.id === 'tiktok' && btn.label === 'حساب تيك توك') {
      return t.tiktokDefaultCta;
    }
    if (state.lang === 'ar' && btn.id === 'game' && btn.label === 'One City RP') {
      return t.gameCardCta;
    }
  }
  return btn.label;
}

function createHeroSvgIcon(type) {
  const ns = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(ns, 'svg');
  svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('width', '20');
  svg.setAttribute('height', '20');
  svg.setAttribute('aria-hidden', 'true');

  if (type === 'discord') {
    svg.setAttribute('fill', 'currentColor');
    const p = document.createElementNS(ns, 'path');
    p.setAttribute(
      'd',
      'M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994.021-.041.001-.09-.041-.106a13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.061 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.028ZM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418Zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418Z',
    );
    svg.appendChild(p);
    return svg;
  }

  const paths = [
    {
      fill: '#25F4EE',
      d: 'M16.6 5.82s.51.5 0 0A4.278 4.278 0 0 1 15.54 3h-3.09v12.4a2.592 2.592 0 0 1-2.59 2.5c-1.42 0-2.6-1.16-2.6-2.6 0-1.72 1.66-3.01 3.37-2.48V9.66c-3.45-.46-6.47 2.22-6.47 5.64 0 3.33 2.76 5.7 5.69 5.7 3.14 0 5.69-2.55 5.69-5.7V9.01a7.35 7.35 0 0 0 4.3 1.38V7.3s-1.88.09-3.24-1.48z',
      transform: 'translate(-0.7 -0.6)',
    },
    {
      fill: '#FE2C55',
      d: 'M16.6 5.82s.51.5 0 0A4.278 4.278 0 0 1 15.54 3h-3.09v12.4a2.592 2.592 0 0 1-2.59 2.5c-1.42 0-2.6-1.16-2.6-2.6 0-1.72 1.66-3.01 3.37-2.48V9.66c-3.45-.46-6.47 2.22-6.47 5.64 0 3.33 2.76 5.7 5.69 5.7 3.14 0 5.69-2.55 5.69-5.7V9.01a7.35 7.35 0 0 0 4.3 1.38V7.3s-1.88.09-3.24-1.48z',
      transform: 'translate(0.7 0.6)',
    },
    {
      fill: '#FFFFFF',
      d: 'M16.6 5.82s.51.5 0 0A4.278 4.278 0 0 1 15.54 3h-3.09v12.4a2.592 2.592 0 0 1-2.59 2.5c-1.42 0-2.6-1.16-2.6-2.6 0-1.72 1.66-3.01 3.37-2.48V9.66c-3.45-.46-6.47 2.22-6.47 5.64 0 3.33 2.76 5.7 5.69 5.7 3.14 0 5.69-2.55 5.69-5.7V9.01a7.35 7.35 0 0 0 4.3 1.38V7.3s-1.88.09-3.24-1.48z',
    },
  ];
  paths.forEach((info) => {
    const p = document.createElementNS(ns, 'path');
    p.setAttribute('fill', info.fill);
    p.setAttribute('d', info.d);
    if (info.transform) p.setAttribute('transform', info.transform);
    svg.appendChild(p);
  });
  return svg;
}

// Render Site Home & Theme
function renderSite() {
  const t = TRANSLATIONS[state.lang];
  const cfg = state.siteConfig;
  const neon = /^#[0-9a-fA-F]{6}$/.test(cfg.neonColor) ? cfg.neonColor : '#a855f7';

  document.documentElement.style.setProperty('--neon', neon);
  document.title = cfg.siteName || 'One City RP';

  const resolvedLogo = resolveLogoSrc(cfg.logoUrl);
  const logoImg = $('site-logo');
  const logoFallback = $('logo-fallback');
  if (logoImg && logoFallback) {
    logoImg.classList.remove('hidden');
    logoFallback.classList.add('hidden');
    logoImg.src = resolvedLogo;
    logoImg.alt = cfg.siteName || 'One City RP';
    logoImg.onerror = () => {
      logoImg.classList.add('hidden');
      logoFallback.classList.remove('hidden');
    };
  }

  const headerLogo = $('header-brand-logo');
  if (headerLogo) {
    headerLogo.src = resolvedLogo;
    headerLogo.alt = cfg.siteName || 'One City RP';
    headerLogo.onerror = () => headerLogo.classList.add('hidden');
  }

  const siteDisplayName = cfg.siteName || 'One City RP';
  $('site-name').textContent = siteDisplayName;
  $('footer-site-name').textContent = siteDisplayName;
  const headerBrandText = $('header-brand-text');
  if (headerBrandText) headerBrandText.textContent = siteDisplayName;

  const subtitleEl = $('site-subtitle');
  const rawSub = String(cfg.siteSubtitle || '').trim();
  const isCustomSub =
    Boolean(rawSub) && rawSub !== t.defaultSubtitleAr && rawSub !== t.defaultSubtitleEn;
  subtitleEl.textContent = isCustomSub ? rawSub : t.heroSubline;

  const arrowGlyph = state.lang === 'ar' ? '←' : '→';
  const enabledBtns = (cfg.buttons || []).filter((b) => b.enabled);
  const discordBtn = enabledBtns.find((b) => b.id === 'discord');
  const tiktokBtn = enabledBtns.find((b) => b.id === 'tiktok');
  const gameBtn = enabledBtns.find((b) => b.id === 'game');
  const extraBtns = enabledBtns.filter(
    (b) => b.id !== 'discord' && b.id !== 'tiktok' && b.id !== 'game',
  );

  const stack = $('buttons-stack');
  stack.innerHTML = '';
  stack.classList.toggle('hidden', !discordBtn && !tiktokBtn);

  const buildPrimaryAction = (btn, type) => {
    const safeUrl = sanitizeUrl(btn.url);
    const label = getButtonLabel(btn);
    const el = safeUrl ? document.createElement('a') : document.createElement('button');
    if (safeUrl) {
      el.href = safeUrl;
      el.target = '_blank';
      el.rel = 'noopener noreferrer';
    } else {
      el.type = 'button';
      el.addEventListener('click', () => {
        showToast(`${t.pendingLinkPrefix} "${label}" ${t.pendingLinkSuffix}`);
      });
    }
    el.className = `hero-action-btn ${type === 'discord' ? 'discord-btn' : 'tiktok-btn'}`;

    const sheen = document.createElement('span');
    sheen.className = 'hero-btn-sheen';
    sheen.setAttribute('aria-hidden', 'true');

    const iconWrap = document.createElement('span');
    iconWrap.className = 'hero-btn-icon';
    iconWrap.appendChild(createHeroSvgIcon(type));

    const labelSpan = document.createElement('span');
    labelSpan.className = 'hero-btn-label';
    labelSpan.textContent = label;

    const arrowSpan = document.createElement('span');
    arrowSpan.className = 'hero-btn-arrow';
    arrowSpan.setAttribute('aria-hidden', 'true');
    arrowSpan.textContent = arrowGlyph;

    el.append(sheen, iconWrap, labelSpan, arrowSpan);
    return el;
  };

  if (discordBtn) stack.appendChild(buildPrimaryAction(discordBtn, 'discord'));
  if (tiktokBtn) stack.appendChild(buildPrimaryAction(tiktokBtn, 'tiktok'));

  const extraRow = $('extra-buttons-row');
  if (extraRow) {
    extraRow.innerHTML = '';
    extraRow.classList.toggle('hidden', extraBtns.length === 0);
    extraBtns.forEach((btn) => {
      const safeUrl = sanitizeUrl(btn.url);
      const label = getButtonLabel(btn);
      const el = safeUrl ? document.createElement('a') : document.createElement('button');
      if (safeUrl) {
        el.href = safeUrl;
        el.target = '_blank';
        el.rel = 'noopener noreferrer';
      } else {
        el.type = 'button';
        el.addEventListener('click', () => {
          showToast(`${t.pendingLinkPrefix} "${label}" ${t.pendingLinkSuffix}`);
        });
      }
      el.className = 'extra-link-chip';
      const ic = document.createElement('span');
      ic.setAttribute('aria-hidden', 'true');
      ic.textContent = btn.icon || '🔗';
      const lb = document.createElement('span');
      lb.textContent = label;
      el.append(ic, lb);
      extraRow.appendChild(el);
    });
  }

  const gameCard = $('game-showcase-card');
  if (gameCard) {
    gameCard.innerHTML = '';
    gameCard.classList.toggle('hidden', !gameBtn);
    if (gameBtn) {
      const grid = document.createElement('div');
      grid.className = 'game-showcase-grid';

      const visual = document.createElement('div');
      visual.className = 'game-showcase-visual';
      const glow = document.createElement('div');
      glow.className = 'game-showcase-glow';
      glow.setAttribute('aria-hidden', 'true');

      const skySvg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      skySvg.setAttribute('viewBox', '0 0 600 220');
      skySvg.setAttribute('preserveAspectRatio', 'none');
      skySvg.setAttribute('class', 'game-showcase-skyline');
      skySvg.setAttribute('aria-hidden', 'true');
      const cityPath = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      cityPath.setAttribute(
        'd',
        'M0 220V165h28v-35h22v35h16V98h34v67h18v-48h26v48h20V72h42v93h16v-55h30v55h22V86h36v79h18v-42h28v42h20V60h40v105h18v-44h28v44h22v-65h34v65h24v-28h30v55H0Z',
      );
      cityPath.setAttribute('fill', '#090d1f');
      const horizon = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      horizon.setAttribute('d', 'M0 206h600');
      horizon.setAttribute('stroke', neon);
      horizon.setAttribute('stroke-width', '2');
      horizon.setAttribute('stroke-opacity', '0.65');
      skySvg.append(cityPath, horizon);

      const crest = document.createElement('img');
      crest.className = 'game-showcase-crest';
      crest.src = resolvedLogo;
      crest.alt = '';
      crest.setAttribute('aria-hidden', 'true');
      crest.onerror = () => crest.remove();
      visual.append(glow, skySvg, crest);

      const content = document.createElement('div');
      content.className = 'game-showcase-content';

      const eyebrow = document.createElement('span');
      eyebrow.className = 'game-showcase-eyebrow';
      eyebrow.textContent = siteDisplayName;

      const makeSlashes = (dimFirst) => {
        const wrap = document.createElement('span');
        wrap.className = 'game-slashes';
        wrap.setAttribute('aria-hidden', 'true');
        const b1 = document.createElement('span');
        b1.className = `game-slash-bar${dimFirst ? ' dim' : ''}`;
        const b2 = document.createElement('span');
        b2.className = `game-slash-bar${dimFirst ? '' : ' dim'}`;
        wrap.append(b1, b2);
        return wrap;
      };

      const headingRow = document.createElement('div');
      headingRow.className = 'game-showcase-heading';
      const h2 = document.createElement('h2');
      h2.textContent = t.gameCardTitle;
      headingRow.append(makeSlashes(false), h2, makeSlashes(true));

      const desc = document.createElement('p');
      desc.className = 'game-showcase-desc';
      desc.textContent = t.gameCardDesc;

      const safeGameUrl = sanitizeUrl(gameBtn.url);
      const gameCtaLabel = getButtonLabel(gameBtn) || t.gameCardCta;
      const cta = safeGameUrl ? document.createElement('a') : document.createElement('button');
      cta.className = 'game-enter-btn';
      if (safeGameUrl) {
        cta.href = safeGameUrl;
        cta.target = '_blank';
        cta.rel = 'noopener noreferrer';
      } else {
        cta.type = 'button';
        cta.addEventListener('click', () => {
          showToast(`${t.pendingLinkPrefix} "${gameCtaLabel}" ${t.pendingLinkSuffix}`);
        });
      }

      const ctaSheen = document.createElement('span');
      ctaSheen.className = 'hero-btn-sheen';
      ctaSheen.setAttribute('aria-hidden', 'true');
      ctaSheen.style.animationDelay = '0.8s';
      const ctaLabel = document.createElement('span');
      ctaLabel.className = 'hero-btn-label';
      ctaLabel.textContent = gameCtaLabel;
      const ctaArrow = document.createElement('span');
      ctaArrow.className = 'hero-btn-arrow';
      ctaArrow.setAttribute('aria-hidden', 'true');
      ctaArrow.textContent = arrowGlyph;
      cta.append(ctaSheen, ctaLabel, ctaArrow);

      content.append(eyebrow, headingRow, desc, cta);
      grid.append(visual, content);
      gameCard.appendChild(grid);
    }
  }

  renderGameGuide();
}

function renderGameGuide() {
  const container = $('game-guide');
  if (!container) return;
  const t = TRANSLATIONS[state.lang];
  const siteDisplayName = state.siteConfig.siteName || 'One City RP';
  container.innerHTML = '';

  const header = document.createElement('div');
  header.className = 'game-guide-header';

  const titleBlock = document.createElement('div');
  const h2 = document.createElement('h2');
  h2.className = 'game-guide-title';
  h2.textContent = state.lang === 'ar' ? `شرح لعبة ${siteDisplayName}` : t.guideSectionTitle;
  const sub = document.createElement('p');
  sub.className = 'game-guide-subtitle';
  sub.textContent = t.guideSectionSubtitle;
  titleBlock.append(h2, sub);

  const tabBar = document.createElement('div');
  tabBar.className = 'game-guide-tabs';
  tabBar.setAttribute('role', 'tablist');

  const tabs = [
    { id: 'overview', icon: '📖', label: t.guideTabOverview },
    { id: 'start', icon: '🧭', label: t.guideTabStart },
    { id: 'rules', icon: '🛡️', label: t.guideTabRules },
    { id: 'careers', icon: '💼', label: t.guideTabCareers },
  ];

  tabs.forEach((tab) => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = `guide-tab-btn${state.guideTab === tab.id ? ' active' : ''}`;
    btn.setAttribute('role', 'tab');
    btn.setAttribute('aria-selected', state.guideTab === tab.id ? 'true' : 'false');
    const ic = document.createElement('span');
    ic.setAttribute('aria-hidden', 'true');
    ic.textContent = tab.icon;
    const lb = document.createElement('span');
    lb.textContent = tab.label;
    btn.append(ic, lb);
    btn.addEventListener('click', () => {
      state.guideTab = tab.id;
      renderGameGuide();
    });
    tabBar.appendChild(btn);
  });

  header.append(titleBlock, tabBar);

  const body = document.createElement('div');
  body.className = 'game-guide-body';
  body.setAttribute('role', 'tabpanel');

  if (state.guideTab === 'overview') {
    const lead = document.createElement('p');
    lead.className = 'game-guide-lead';
    lead.textContent = t.guideOverviewLead;
    body.appendChild(lead);

    const grid = document.createElement('div');
    grid.className = 'game-guide-grid';
    (t.guideOverviewItems || []).forEach((item) => {
      const card = document.createElement('div');
      card.className = 'game-guide-item';
      const head = document.createElement('div');
      head.className = 'game-guide-item-head';
      const wrap = document.createElement('div');
      wrap.className = 'game-guide-item-title-wrap';
      const num = document.createElement('span');
      num.className = 'game-guide-num';
      num.textContent = `${item.num}.`;
      const h3 = document.createElement('h3');
      h3.textContent = item.title;
      wrap.append(num, h3);
      head.appendChild(wrap);
      const p = document.createElement('p');
      p.textContent = item.desc;
      card.append(head, p);
      grid.appendChild(card);
    });
    body.appendChild(grid);
  } else if (state.guideTab === 'start') {
    const grid = document.createElement('div');
    grid.className = 'game-guide-grid';
    (t.guideStartSteps || []).forEach((step) => {
      const card = document.createElement('div');
      card.className = 'game-guide-item';
      const head = document.createElement('div');
      head.className = 'game-guide-item-head';
      const wrap = document.createElement('div');
      wrap.className = 'game-guide-item-title-wrap';
      const num = document.createElement('span');
      num.className = 'game-guide-num';
      num.textContent = step.num;
      const h3 = document.createElement('h3');
      h3.textContent = step.title;
      wrap.append(num, h3);
      head.appendChild(wrap);
      const p = document.createElement('p');
      p.textContent = step.desc;
      card.append(head, p);
      grid.appendChild(card);
    });
    body.appendChild(grid);
  } else if (state.guideTab === 'rules') {
    const grid = document.createElement('div');
    grid.className = 'game-guide-grid';
    (t.guideRules || []).forEach((rule) => {
      const card = document.createElement('div');
      card.className = 'game-guide-item';
      const head = document.createElement('div');
      head.className = 'game-guide-item-head';
      const h3 = document.createElement('h3');
      h3.textContent = rule.title;
      const code = document.createElement('span');
      code.className = 'game-guide-code';
      code.textContent = rule.code;
      head.append(h3, code);
      const p = document.createElement('p');
      p.textContent = rule.desc;
      card.append(head, p);
      grid.appendChild(card);
    });
    body.appendChild(grid);
  } else {
    const grid = document.createElement('div');
    grid.className = 'game-guide-grid';
    (t.guideCareers || []).forEach((career) => {
      const card = document.createElement('div');
      card.className = 'game-guide-item';
      const head = document.createElement('div');
      head.className = 'game-guide-item-head';
      const h3 = document.createElement('h3');
      h3.textContent = career.title;
      const tag = document.createElement('span');
      tag.className = 'game-guide-tag';
      tag.textContent = career.code;
      head.append(h3, tag);
      const p = document.createElement('p');
      p.textContent = career.desc;
      card.append(head, p);
      grid.appendChild(card);
    });
    body.appendChild(grid);
  }

  container.append(header, body);
}

// Render News View
function renderNews() {
  const t = TRANSLATIONS[state.lang];
  const news = state.botInfo.news || [];
  $('news-count').textContent = `${news.length} ${t.newsCountUnit}`;
  const list = $('news-list');
  list.innerHTML = '';

  if (news.length === 0) {
    const empty = document.createElement('p');
    empty.className = 'empty-msg';
    empty.textContent = t.newsEmpty;
    list.appendChild(empty);
    return;
  }

  news.forEach((item) => {
    const card = document.createElement('article');
    card.className = 'news-article-row';

    const safeImg = sanitizeNewsImageUrl(item.imageUrl);
    if (safeImg) {
      const imgWrap = document.createElement('div');
      imgWrap.className = 'news-img-wrap';

      const img = document.createElement('img');
      img.className = 'news-card-img';
      img.src = safeImg;
      img.alt = escapeText(item.title);
      img.referrerPolicy = 'no-referrer';
      img.loading = 'lazy';
      img.onerror = () => imgWrap.remove();

      const scrim = document.createElement('div');
      scrim.className = 'news-img-scrim';
      scrim.setAttribute('aria-hidden', 'true');

      imgWrap.append(img, scrim);
      card.appendChild(imgWrap);
    }

    const top = document.createElement('div');
    top.className = 'info-item-top';

    const h3 = document.createElement('h3');
    h3.textContent = escapeText(item.title);
    top.appendChild(h3);

    if (item.date) {
      const time = document.createElement('time');
      time.className = 'info-item-date';
      time.textContent = escapeText(item.date);
      top.appendChild(time);
    }

    const body = document.createElement('p');
    body.className = 'info-item-body';
    body.textContent = escapeText(item.content);

    card.append(top, body);
    list.appendChild(card);
  });
}

// Render Factions View
function renderFactions() {
  const t = TRANSLATIONS[state.lang];
  const factions = state.botInfo.factions || [];
  $('factions-count').textContent = `${factions.length} ${t.factionsCountUnit}`;
  const list = $('factions-list');
  list.innerHTML = '';

  if (factions.length === 0) {
    const empty = document.createElement('p');
    empty.className = 'empty-msg';
    empty.textContent = t.factionsEmpty;
    list.appendChild(empty);
    return;
  }

  factions.forEach((f) => {
    const card = document.createElement('div');
    card.className = 'faction-card-item';

    const top = document.createElement('div');
    top.className = 'info-item-top';

    const titleWrap = document.createElement('div');
    titleWrap.className = 'card-title-row';

    const iconSpan = document.createElement('span');
    iconSpan.className = 'faction-icon-box';
    iconSpan.setAttribute('aria-hidden', 'true');
    iconSpan.textContent = f.icon || '🛡️';

    const enMatch = state.lang === 'en' ? DEFAULT_FACTION_EN_MAP[f.id] : null;
    const displayName = enMatch && f.name === enMatch.arName ? enMatch.name : f.name;
    const displayDesc =
      enMatch && f.description === enMatch.arDesc ? enMatch.description : f.description;

    const h3 = document.createElement('h3');
    h3.textContent = escapeText(displayName);
    titleWrap.append(iconSpan, h3);

    const statusBadge = document.createElement('span');
    const statusClass =
      f.status === 'مفتوح' ? 'status-open' : f.status === 'مغلق' ? 'status-closed' : 'status-soon';
    const glyph = f.status === 'مفتوح' ? '●' : f.status === 'مغلق' ? '✖' : '▲';
    statusBadge.className = `status-badge ${statusClass}`;
    statusBadge.textContent = `${glyph} ${t.applyStatusPrefix} ${t.statusMap[f.status] || f.status}`;

    top.append(titleWrap, statusBadge);
    card.appendChild(top);

    if (displayDesc) {
      const desc = document.createElement('p');
      desc.className = 'info-item-body';
      desc.textContent = escapeText(displayDesc);
      card.appendChild(desc);
    }

    list.appendChild(card);
  });
}

// Render AI Assistant
function renderAiPanel() {
  const t = TRANSLATIONS[state.lang];
  const siteName = state.siteConfig.siteName || 'One City RP';
  $('ai-title').textContent = `${siteName} AI`;
  $('ai-subtitle').textContent = t.aiSubtitle;

  const box = $('ai-messages');
  box.innerHTML = '';

  const allMessages = [{ role: 'model', text: t.aiWelcome(siteName) }, ...state.aiHistory];
  allMessages.forEach((m) => {
    const row = document.createElement('div');
    row.className = `ai-bubble-row ${m.role}`;
    const bubble = document.createElement('div');
    bubble.className = 'ai-bubble';
    bubble.textContent = m.text;
    row.appendChild(bubble);
    box.appendChild(row);
  });

  if (state.aiSending) {
    const row = document.createElement('div');
    row.className = 'ai-bubble-row model';
    const bubble = document.createElement('div');
    bubble.className = 'ai-bubble';
    bubble.textContent = t.aiThinking;
    row.appendChild(bubble);
    box.appendChild(row);
  }

  const promptsEl = $('ai-prompts');
  promptsEl.innerHTML = '';
  if (state.aiHistory.length === 0) {
    promptsEl.classList.remove('hidden');
    t.aiPrompts.forEach((prompt) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'prompt-chip';
      btn.textContent = `✨ ${prompt}`;
      btn.addEventListener('click', () => handleAiSend(prompt));
      promptsEl.appendChild(btn);
    });
  } else {
    promptsEl.classList.add('hidden');
  }

  box.scrollTop = box.scrollHeight;
}

async function handleAiSend(rawText) {
  const text = String(rawText || '').trim();
  if (!text || state.aiSending) return;

  state.aiHistory.push({ role: 'user', text });
  $('ai-input').value = '';
  state.aiSending = true;
  renderAiPanel();

  try {
    const reply = await askAssistant(text, state.aiHistory.slice(-10), {
      siteName: state.siteConfig.siteName,
      botInfo: state.botInfo,
      buttons: state.siteConfig.buttons,
      lang: state.lang,
    });
    state.aiHistory.push({ role: 'model', text: reply });
  } finally {
    state.aiSending = false;
    renderAiPanel();
  }
}

const IS_LOCAL_FILE = window.location.protocol === 'file:';

// Switch Views & Header State
function setActiveView(view) {
  const allowed = state.user || IS_LOCAL_FILE ? view : 'home';
  state.activeView = allowed;

  ['home', 'news', 'factions', 'ai'].forEach((v) => {
    const el = $(`view-${v}`);
    if (el) el.classList.toggle('hidden', v !== allowed);
  });

  document.querySelectorAll('#member-nav .nav-tab').forEach((btn) => {
    btn.classList.toggle('active', btn.dataset.view === allowed);
  });

  if (allowed === 'news') renderNews();
  if (allowed === 'factions') renderFactions();
  if (allowed === 'ai') renderAiPanel();
}

let syncPortalGateHook = null;

function updateAuthUI() {
  const loggedIn = Boolean(state.user);
  $('login-open-btn').classList.toggle('hidden', loggedIn || IS_LOCAL_FILE);
  $('logout-btn').classList.toggle('hidden', !loggedIn);
  $('member-nav').classList.toggle('hidden', !(loggedIn || IS_LOCAL_FILE));
  $('admin-open-btn').classList.toggle('hidden', !(loggedIn && state.permissions.isAdmin));
  const verifyBanner = $('verify-banner');
  if (verifyBanner) {
    verifyBanner.classList.toggle('hidden', !(loggedIn && state.user && !state.user.emailVerified));
  }

  if (!loggedIn && !IS_LOCAL_FILE) {
    $('admin-modal').classList.add('hidden');
    setActiveView('home');
  }

  if (typeof syncPortalGateHook === 'function') {
    syncPortalGateHook();
  }
}

// Language Sync
function applyLanguage() {
  const t = TRANSLATIONS[state.lang];
  document.documentElement.lang = state.lang;
  document.documentElement.dir = state.lang === 'ar' ? 'rtl' : 'ltr';
  try {
    localStorage.setItem('onecity_lang', state.lang);
  } catch {
    // Ignore storage errors
  }

  $('lang-toggle-label').textContent = t.switchLang;

  document.querySelectorAll('[data-i18n]').forEach((el) => {
    const key = el.getAttribute('data-i18n');
    if (key && typeof t[key] === 'string') {
      el.textContent = t[key];
    }
  });

  document.querySelectorAll('[data-i18n-placeholder]').forEach((el) => {
    const key = el.getAttribute('data-i18n-placeholder');
    if (key && typeof t[key] === 'string') {
      el.setAttribute('placeholder', t[key]);
    }
  });

  renderSite();
  renderNews();
  renderFactions();
  renderAiPanel();
}

function isInsideIframe() {
  try {
    return window.self !== window.top;
  } catch {
    return true;
  }
}

function hideLoginRecoveryLinks() {
  $('login-firebase-console-link')?.classList.add('hidden');
  $('login-open-browser-link')?.classList.add('hidden');
}

function showLoginRecoveryLinks(code) {
  const ar = state.lang === 'ar';
  const fbLink = $('login-firebase-console-link');
  const openLink = $('login-open-browser-link');
  if (fbLink) {
    fbLink.textContent = ar
      ? 'فتح إعدادات Firebase لتفعيل Email/Password ←'
      : 'Open Firebase Console to Enable Email/Password ->';
    fbLink.classList.toggle('hidden', code !== 'auth/operation-not-allowed');
  }
  if (openLink) {
    const showOpen =
      isInsideIframe() &&
      (code === 'auth/popup-blocked' ||
        code === 'auth/internal-error' ||
        code === 'auth/operation-not-supported-in-this-environment' ||
        code === 'auth/cancelled-popup-request');
    if (showOpen) {
      openLink.href = window.location.href;
      openLink.textContent = ar
        ? 'فتح في نافذة متصفح مستقلة لتسجيل الدخول بـ Google'
        : 'Open in Standalone Browser Tab for Google Sign-In';
    }
    openLink.classList.toggle('hidden', !showOpen);
  }
}

// Login Modal Logic
function setLoginMode(mode) {
  state.loginMode = mode;
  const isSignup = mode === 'signup';
  const ar = state.lang === 'ar';
  const card = document.querySelector('#login-modal .login-card');
  if (card) card.setAttribute('dir', ar ? 'rtl' : 'ltr');

  $('login-title').textContent = isSignup
    ? ar
      ? 'إنشاء حساب جديد'
      : 'Create Account'
    : ar
    ? 'تسجيل الدخول'
    : 'Sign In';
  $('login-submit-btn').textContent = isSignup
    ? ar
      ? 'إنشاء الحساب'
      : 'Create Account'
    : ar
    ? 'تسجيل الدخول'
    : 'Sign In';
  $('login-tab-signin').textContent = ar ? 'تسجيل الدخول' : 'Sign In';
  $('login-tab-signup').textContent = ar ? 'إنشاء حساب' : 'Create Account';
  $('login-tab-signin').classList.toggle('active', !isSignup);
  $('login-tab-signup').classList.toggle('active', isSignup);

  $('auth-username-label').innerHTML = `${ar ? 'اسم المستخدم' : 'Username'} <span class="req">*</span>`;
  $('auth-email-label').innerHTML = `${ar ? 'البريد الإلكتروني' : 'Email'} <span class="req">*</span>`;
  $('auth-password-label').innerHTML = `${ar ? 'كلمة المرور' : 'Password'} <span class="req">*</span>`;
  $('auth-username').placeholder = ar ? 'اكتب اسمك في السيرفر' : 'Your username';
  $('forgot-password-btn').textContent = ar ? 'نسيت كلمة المرور؟' : 'Forgot password?';
  $('forgot-password-btn').classList.toggle('hidden', isSignup);
  $('login-or-label').textContent = ar ? 'أو' : 'or';
  const gSpan = $('google-signin-btn')?.querySelector('span');
  if (gSpan) gSpan.textContent = ar ? 'المتابعة باستخدام Google' : 'Continue with Google';

  $('login-username-group').classList.toggle('hidden', !isSignup);
  $('auth-username').required = isSignup;
  $('auth-password').setAttribute('autocomplete', isSignup ? 'new-password' : 'current-password');
  $('login-error').classList.add('hidden');
  $('login-info').classList.add('hidden');
  hideLoginRecoveryLinks();
}

function mapAuthError(err) {
  const code = err && err.code ? String(err.code) : '';
  const ar = state.lang === 'ar';
  switch (code) {
    case 'auth/invalid-credential':
    case 'auth/wrong-password':
    case 'auth/user-not-found':
      return ar ? 'البريد الإلكتروني أو كلمة المرور غير صحيحة.' : 'Invalid email or password.';
    case 'auth/invalid-email':
      return ar ? 'يرجى إدخال بريد إلكتروني صحيح.' : 'Please enter a valid email address.';
    case 'auth/email-already-in-use':
      return ar
        ? 'يوجد حساب مسجل بهذا البريد الإلكتروني بالفعل.'
        : 'An account with this email already exists.';
    case 'auth/weak-password':
      return ar
        ? 'كلمة المرور ضعيفة جداً — 6 أحرف على الأقل.'
        : 'Password must be at least 6 characters.';
    case 'auth/operation-not-allowed':
      return ar
        ? 'مزوّد البريد وكلمة المرور غير مفعّل في مشروع Firebase حتى الآن. فعّل خيار Email/Password من إعدادات Firebase بالأسفل، أو سجّل الدخول مباشرة باستخدام زر Google.'
        : 'Email/Password sign-in is disabled in Firebase Console. Enable Email/Password below, or sign in immediately with Google.';
    case 'auth/popup-blocked':
      return ar
        ? 'المتصفح منع فتح نافذة تسجيل الدخول عبر Google. افتح الصفحة في نافذة متصفح مستقلة أو اسمح بالنوافذ المنبثقة ثم حاول مجدداً.'
        : 'Popup was blocked by your browser. Open in a standalone browser tab or allow popups and try again.';
    case 'auth/popup-closed-by-user':
    case 'auth/cancelled-popup-request':
      return ar
        ? 'تم إغلاق نافذة Google قبل إكمال تسجيل الدخول. حاول مرة أخرى.'
        : 'Google sign-in popup was closed before completing sign-in.';
    case 'auth/unauthorized-domain':
      return ar
        ? `النطاق "${window.location.hostname}" غير مضاف في Authorized domains داخل Firebase Console.`
        : `Domain "${window.location.hostname}" is not authorized in Firebase Console -> Authentication -> Settings -> Authorized domains.`;
    case 'auth/operation-not-supported-in-this-environment':
      return ar
        ? 'يرجى فتح الموقع عبر HTTPS في Chrome أو Safari لتسجيل الدخول.'
        : 'Please open the site over HTTPS (not file://) in Chrome or Safari to sign in.';
    case 'auth/network-request-failed':
      return ar
        ? 'خطأ في الاتصال بالإنترنت. تحقق من الشبكة وحاول مجدداً.'
        : 'Network error. Please check your internet connection and try again.';
    case 'auth/internal-error':
      return ar
        ? 'المتصفح حظر نافذة Google داخل المعاينة المدمجة — اضغط الزر أدناه لفتح الصفحة في المتصفح وإكمال الدخول بـ Google.'
        : 'Browser blocked Google sign-in inside the embedded preview frame. Tap below to open in a browser tab.';
    default: {
      const raw = err && err.message ? String(err.message) : '';
      if (raw) return code ? `${raw} (${code})` : raw;
      return ar ? 'فشل تسجيل الدخول.' : 'Authentication failed.';
    }
  }
}

// Admin Modal Logic
let unsubAdminAdmins = null;
let unsubAdminUsers = null;

function setAdminFeedback(type, msg) {
  const box = $('admin-feedback');
  box.className = `alert-box ${type === 'success' ? 'alert-success' : 'alert-error'}`;
  box.textContent = msg;
  box.classList.remove('hidden');
}

function compressNewsImage(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Read failed'));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error('Invalid image'));
      img.onload = () => {
        const maxSize = 640;
        const scale = Math.min(1, maxSize / Math.max(img.width, img.height));
        const w = Math.max(1, Math.round(img.width * scale));
        const h = Math.max(1, Math.round(img.height * scale));
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, w, h);
        for (const q of [0.78, 0.62, 0.45]) {
          const webp = canvas.toDataURL('image/webp', q);
          if (webp.length <= 75000) {
            resolve(webp);
            return;
          }
        }
        resolve(canvas.toDataURL('image/jpeg', 0.52));
      };
      img.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  });
}

function compressImage(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Read failed'));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error('Invalid image'));
      img.onload = () => {
        const maxSize = 320;
        const scale = Math.min(1, maxSize / Math.max(img.width, img.height));
        const w = Math.max(1, Math.round(img.width * scale));
        const h = Math.max(1, Math.round(img.height * scale));
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, w, h);
        const webp = canvas.toDataURL('image/webp', 0.86);
        resolve(webp.length > 220000 ? canvas.toDataURL('image/jpeg', 0.78) : webp);
      };
      img.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  });
}

function switchAdminTab(tab) {
  state.adminTab = tab;
  document.querySelectorAll('#admin-tabs .admin-tab-btn').forEach((btn) => {
    btn.classList.toggle('active', btn.dataset.adminTab === tab);
  });
  document.querySelectorAll('.admin-tab-panel').forEach((panel) => {
    panel.classList.toggle('hidden', panel.dataset.panel !== tab);
  });
}

function renderAdminBranding() {
  const d = state.draftConfig;
  $('cfg-site-name').value = d.siteName;
  $('cfg-site-subtitle').value = d.siteSubtitle;
  $('cfg-logo-url').value = d.logoUrl;
  $('cfg-logo-preview').src = resolveLogoSrc(d.logoUrl);
  $('cfg-neon-color').value = d.neonColor;

  const presetsEl = $('neon-presets');
  presetsEl.innerHTML = '';
  NEON_PRESETS.forEach((p) => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = `preset-btn ${d.neonColor.toLowerCase() === p.value ? 'active' : ''}`;
    btn.innerHTML = `<span class="preset-dot" style="background:${p.value}"></span><span></span>`;
    btn.children[1].textContent = state.lang === 'ar' ? p.labelAr : p.labelEn;
    btn.addEventListener('click', () => {
      state.draftConfig.neonColor = p.value;
      renderAdminBranding();
    });
    presetsEl.appendChild(btn);
  });

  const welList = $('cfg-welcome-list');
  welList.innerHTML = '';
  d.welcomeMessages.forEach((msg, idx) => {
    const row = document.createElement('div');
    row.className = 'inline-row';
    const inp = document.createElement('input');
    inp.type = 'text';
    inp.maxLength = 160;
    inp.value = msg;
    inp.addEventListener('input', (e) => {
      state.draftConfig.welcomeMessages[idx] = e.target.value;
    });
    row.appendChild(inp);

    if (d.welcomeMessages.length > 1) {
      const del = document.createElement('button');
      del.type = 'button';
      del.className = 'danger-icon-btn';
      del.textContent = '🗑';
      del.addEventListener('click', () => {
        state.draftConfig.welcomeMessages.splice(idx, 1);
        renderAdminBranding();
      });
      row.appendChild(del);
    }
    welList.appendChild(row);
  });
}

function renderAdminLinks() {
  const t = TRANSLATIONS[state.lang];
  const list = $('cfg-buttons-list');
  list.innerHTML = '';
  state.draftConfig.buttons.forEach((btn, idx) => {
    const card = document.createElement('div');
    card.className = 'subcard form-stack';

    const topRow = document.createElement('div');
    topRow.className = 'inline-row';

    const iconIn = document.createElement('input');
    iconIn.type = 'text';
    iconIn.maxLength = 10;
    iconIn.className = 'icon-input';
    iconIn.value = btn.icon;
    iconIn.addEventListener('input', (e) => {
      state.draftConfig.buttons[idx].icon = e.target.value;
    });

    const labelIn = document.createElement('input');
    labelIn.type = 'text';
    labelIn.maxLength = 60;
    labelIn.required = true;
    labelIn.value = btn.label;
    labelIn.addEventListener('input', (e) => {
      state.draftConfig.buttons[idx].label = e.target.value;
    });

    const enWrap = document.createElement('label');
    enWrap.className = 'checkbox-label';
    const enChk = document.createElement('input');
    enChk.type = 'checkbox';
    enChk.checked = Boolean(btn.enabled);
    enChk.addEventListener('change', (e) => {
      state.draftConfig.buttons[idx].enabled = e.target.checked;
    });
    const enSpan = document.createElement('span');
    enSpan.textContent = t.enabledLabel;
    enWrap.append(enChk, enSpan);

    topRow.append(iconIn, labelIn, enWrap);

    if (state.draftConfig.buttons.length > 1) {
      const del = document.createElement('button');
      del.type = 'button';
      del.className = 'danger-icon-btn';
      del.textContent = '🗑';
      del.addEventListener('click', () => {
        state.draftConfig.buttons.splice(idx, 1);
        renderAdminLinks();
      });
      topRow.appendChild(del);
    }

    const urlIn = document.createElement('input');
    urlIn.type = 'text';
    urlIn.dir = 'ltr';
    urlIn.maxLength = 500;
    urlIn.value = btn.url;
    urlIn.placeholder = 'https://...';
    urlIn.addEventListener('input', (e) => {
      state.draftConfig.buttons[idx].url = e.target.value;
    });

    card.append(topRow, urlIn);
    list.appendChild(card);
  });
}

function renderAdminBot() {
  const t = TRANSLATIONS[state.lang];
  const newsList = $('admin-news-list');
  newsList.innerHTML = '';
  state.draftBotInfo.news.forEach((n, idx) => {
    const card = document.createElement('div');
    card.className = 'subcard form-stack';

    const top = document.createElement('div');
    top.className = 'inline-row';

    const titleIn = document.createElement('input');
    titleIn.type = 'text';
    titleIn.maxLength = 80;
    titleIn.value = n.title;
    titleIn.addEventListener('input', (e) => {
      state.draftBotInfo.news[idx].title = e.target.value;
    });

    const dateIn = document.createElement('input');
    dateIn.type = 'text';
    dateIn.dir = 'ltr';
    dateIn.className = 'date-input';
    dateIn.maxLength = 30;
    dateIn.value = n.date;
    dateIn.addEventListener('input', (e) => {
      state.draftBotInfo.news[idx].date = e.target.value;
    });

    const del = document.createElement('button');
    del.type = 'button';
    del.className = 'danger-icon-btn';
    del.textContent = '🗑';
    del.addEventListener('click', () => {
      state.draftBotInfo.news.splice(idx, 1);
      renderAdminBot();
    });

    top.append(titleIn, dateIn, del);

    const contentIn = document.createElement('textarea');
    contentIn.rows = 2;
    contentIn.maxLength = 300;
    contentIn.value = n.content;
    contentIn.addEventListener('input', (e) => {
      state.draftBotInfo.news[idx].content = e.target.value;
    });

    const imgRow = document.createElement('div');
    imgRow.className = 'row-actions';
    const imgUrlIn = document.createElement('input');
    imgUrlIn.type = 'text';
    imgUrlIn.dir = 'ltr';
    imgUrlIn.maxLength = 80000;
    imgUrlIn.style.flex = '1';
    imgUrlIn.style.minWidth = '140px';
    imgUrlIn.value = n.imageUrl || '';
    imgUrlIn.placeholder = t.newsImagePlaceholder;

    const previewImg = document.createElement('img');
    previewImg.className = 'news-admin-preview' + (n.imageUrl ? '' : ' hidden');
    if (n.imageUrl) previewImg.src = sanitizeNewsImageUrl(n.imageUrl);

    const removeImgBtn = document.createElement('button');
    removeImgBtn.type = 'button';
    removeImgBtn.className = 'secondary-btn' + (n.imageUrl ? '' : ' hidden');
    removeImgBtn.textContent = t.removeNewsImage;
    removeImgBtn.addEventListener('click', () => {
      state.draftBotInfo.news[idx].imageUrl = '';
      imgUrlIn.value = '';
      previewImg.classList.add('hidden');
      removeImgBtn.classList.add('hidden');
    });

    imgUrlIn.addEventListener('input', (e) => {
      const val = e.target.value;
      state.draftBotInfo.news[idx].imageUrl = val;
      const safe = sanitizeNewsImageUrl(val);
      previewImg.classList.toggle('hidden', !safe);
      removeImgBtn.classList.toggle('hidden', !val);
      if (safe) previewImg.src = safe;
    });

    const uploadLbl = document.createElement('label');
    uploadLbl.className = 'secondary-btn file-label';
    const uploadSpan = document.createElement('span');
    uploadSpan.textContent = t.uploadNewsImage;
    const uploadIn = document.createElement('input');
    uploadIn.type = 'file';
    uploadIn.accept = 'image/*';
    uploadIn.className = 'hidden';
    uploadIn.addEventListener('change', async (e) => {
      const file = e.target.files?.[0];
      if (!file) return;
      try {
        const uri = await compressNewsImage(file);
        if (uri.length > 78000) {
          setAdminFeedback('error', t.fbImageTooLarge);
          return;
        }
        state.draftBotInfo.news[idx].imageUrl = uri;
        imgUrlIn.value = uri;
        previewImg.src = uri;
        previewImg.classList.remove('hidden');
        removeImgBtn.classList.remove('hidden');
        setAdminFeedback('success', t.newsImageReady);
      } catch {
        setAdminFeedback('error', t.fbImageTooLarge);
      }
      e.target.value = '';
    });
    uploadLbl.append(uploadSpan, uploadIn);
    imgRow.append(imgUrlIn, uploadLbl, removeImgBtn);

    card.append(top, contentIn, imgRow, previewImg);
    newsList.appendChild(card);
  });

  const facList = $('admin-factions-list');
  facList.innerHTML = '';
  state.draftBotInfo.factions.forEach((f, idx) => {
    const card = document.createElement('div');
    card.className = 'subcard form-stack';

    const top = document.createElement('div');
    top.className = 'inline-row';

    const iconIn = document.createElement('input');
    iconIn.type = 'text';
    iconIn.maxLength = 10;
    iconIn.className = 'icon-input';
    iconIn.value = f.icon;
    iconIn.addEventListener('input', (e) => {
      state.draftBotInfo.factions[idx].icon = e.target.value;
    });

    const nameIn = document.createElement('input');
    nameIn.type = 'text';
    nameIn.maxLength = 50;
    nameIn.value = f.name;
    nameIn.addEventListener('input', (e) => {
      state.draftBotInfo.factions[idx].name = e.target.value;
    });

    const statusSel = document.createElement('select');
    statusSel.style.width = '110px';
    ['مفتوح', 'مغلق', 'قريباً'].forEach((st) => {
      const opt = document.createElement('option');
      opt.value = st;
      opt.textContent = t.statusMap[st];
      opt.selected = f.status === st;
      statusSel.appendChild(opt);
    });
    statusSel.addEventListener('change', (e) => {
      state.draftBotInfo.factions[idx].status = e.target.value;
    });

    top.append(iconIn, nameIn, statusSel);

    if (state.draftBotInfo.factions.length > 1) {
      const del = document.createElement('button');
      del.type = 'button';
      del.className = 'danger-icon-btn';
      del.textContent = '🗑';
      del.addEventListener('click', () => {
        state.draftBotInfo.factions.splice(idx, 1);
        renderAdminBot();
      });
      top.appendChild(del);
    }

    const descIn = document.createElement('input');
    descIn.type = 'text';
    descIn.maxLength = 200;
    descIn.value = f.description;
    descIn.addEventListener('input', (e) => {
      state.draftBotInfo.factions[idx].description = e.target.value;
    });

    card.append(top, descIn);
    facList.appendChild(card);
  });
}

function getMemberUsername(u) {
  const t = TRANSLATIONS[state.lang];
  return (u.username || '').trim() || (u.displayName || '').trim() || t.memberFallbackName;
}

function renderAdminsAndMembers() {
  const t = TRANSLATIONS[state.lang];
  $('admins-list-heading').textContent = `${t.addedAdminsHeading} (${state.adminsList.length})`;
  $('members-list-heading').textContent = `${t.registeredMembers} (${state.usersList.length})`;

  const adminsEl = $('admins-list');
  adminsEl.innerHTML = '';
  if (state.adminsList.length === 0) {
    const p = document.createElement('p');
    p.className = 'help-text';
    p.textContent = t.noAddedAdmins;
    adminsEl.appendChild(p);
  } else {
    state.adminsList.forEach((adm) => {
      const matched = state.usersList.find(
        (u) => (u.email || '').toLowerCase() === (adm.email || '').toLowerCase(),
      );
      const label = (adm.displayName || '').trim() || (matched ? getMemberUsername(matched) : 'Admin');

      const row = document.createElement('div');
      row.className = 'member-row';

      const nameEl = document.createElement('strong');
      nameEl.textContent = `👤 ${label}`;

      const controls = document.createElement('div');
      controls.className = 'row-actions';

      [
        ['canEditBranding', t.tabBranding],
        ['canEditLinks', t.tabLinks],
        ['canEditBot', t.tabBot],
      ].forEach(([field, txt]) => {
        const lbl = document.createElement('label');
        lbl.className = 'checkbox-label';
        const chk = document.createElement('input');
        chk.type = 'checkbox';
        chk.checked = Boolean(adm[field]);
        chk.addEventListener('change', async () => {
          if (!db || !state.user) return;
          await updateDoc(doc(db, 'admins', adm.email), {
            [field]: !Boolean(adm[field]),
            addedBy: state.user.uid,
            updatedAt: serverTimestamp(),
          });
        });
        const sp = document.createElement('span');
        sp.textContent = txt;
        lbl.append(chk, sp);
        controls.appendChild(lbl);
      });

      const del = document.createElement('button');
      del.type = 'button';
      del.className = 'danger-icon-btn';
      del.textContent = '🗑';
      del.addEventListener('click', async () => {
        if (!db) return;
        await deleteDoc(doc(db, 'admins', adm.email));
        setAdminFeedback('success', t.fbAdminRemoved);
      });
      controls.appendChild(del);

      row.append(nameEl, controls);
      adminsEl.appendChild(row);
    });
  }

  // Registered Members: Username ONLY (never display emails)
  const membersEl = $('members-list');
  membersEl.innerHTML = '';
  if (state.usersList.length === 0) {
    const p = document.createElement('p');
    p.className = 'help-text';
    p.textContent = t.noMembersYet;
    membersEl.appendChild(p);
  } else {
    state.usersList.forEach((u) => {
      const uname = getMemberUsername(u);
      const row = document.createElement('div');
      row.className = 'member-row';

      const nameEl = document.createElement('span');
      nameEl.textContent = `👤 ${uname}`;
      row.appendChild(nameEl);

      const lower = (u.email || '').toLowerCase();
      if (lower && lower !== SUPER_ADMIN_EMAIL && !state.adminsList.some((a) => a.email === lower)) {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'secondary-btn';
        btn.textContent = t.promoteAdmin;
        btn.addEventListener('click', () => {
          $('new-admin-email').value = lower;
          $('new-admin-name').value = uname;
        });
        row.appendChild(btn);
      }
      membersEl.appendChild(row);
    });
  }
}

function openAdminModal() {
  state.draftConfig = structuredClone(state.siteConfig);
  state.draftBotInfo = structuredClone(state.botInfo);
  $('admin-feedback').classList.add('hidden');

  const p = state.permissions;
  document.querySelector('[data-admin-tab="branding"]').classList.toggle('hidden', !(p.isSuperAdmin || p.canEditBranding));
  document.querySelector('[data-admin-tab="links"]').classList.toggle('hidden', !(p.isSuperAdmin || p.canEditLinks));
  document.querySelector('[data-admin-tab="bot"]').classList.toggle('hidden', !(p.isSuperAdmin || p.canEditBot));
  document.querySelector('[data-admin-tab="admins"]').classList.toggle('hidden', !p.isSuperAdmin);

  const firstTab =
    p.isSuperAdmin || p.canEditBranding
      ? 'branding'
      : p.canEditLinks
      ? 'links'
      : p.canEditBot
      ? 'bot'
      : 'admins';
  switchAdminTab(firstTab);

  renderAdminBranding();
  renderAdminLinks();
  renderAdminBot();
  renderAdminsAndMembers();

  if (db && p.isSuperAdmin) {
    unsubAdminAdmins?.();
    unsubAdminUsers?.();
    unsubAdminAdmins = onSnapshot(collection(db, 'admins'), (snap) => {
      state.adminsList = snap.docs.map((d) => d.data());
      renderAdminsAndMembers();
    });
    unsubAdminUsers = onSnapshot(collection(db, 'users'), (snap) => {
      state.usersList = snap.docs.map((d) => d.data());
      renderAdminsAndMembers();
    });
  }

  $('admin-modal').classList.remove('hidden');
}

function closeAdminModal() {
  $('admin-modal').classList.add('hidden');
  unsubAdminAdmins?.();
  unsubAdminUsers?.();
  unsubAdminAdmins = null;
  unsubAdminUsers = null;
}

// Wire Events
$('lang-toggle-btn').addEventListener('click', () => {
  state.lang = state.lang === 'ar' ? 'en' : 'ar';
  applyLanguage();
});

document.querySelectorAll('#member-nav .nav-tab[data-view]').forEach((btn) => {
  btn.addEventListener('click', () => setActiveView(btn.dataset.view));
});

$('nav-guide-btn')?.addEventListener('click', () => {
  setActiveView('home');
  setTimeout(() => {
    $('game-guide')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }, 60);
});

$('ai-form').addEventListener('submit', (e) => {
  e.preventDefault();
  handleAiSend($('ai-input').value);
});

$('header-brand-btn')?.addEventListener('click', () => setActiveView('home'));

$('login-open-btn').addEventListener('click', () => {
  setLoginMode('signin');
  $('login-modal').classList.remove('hidden');
});
$('login-close-btn').addEventListener('click', () => $('login-modal').classList.add('hidden'));
$('login-tab-signin').addEventListener('click', () => setLoginMode('signin'));
$('login-tab-signup').addEventListener('click', () => setLoginMode('signup'));
$('toggle-password-btn').addEventListener('click', () => {
  const pw = $('auth-password');
  pw.type = pw.type === 'password' ? 'text' : 'password';
});
$('forgot-password-btn').addEventListener('click', async () => {
  const errBox = $('login-error');
  const infoBox = $('login-info');
  errBox.classList.add('hidden');
  infoBox.classList.add('hidden');
  hideLoginRecoveryLinks();
  if (!firebaseReady || !auth) return;
  const email = $('auth-email').value.trim().toLowerCase();
  if (!email) {
    errBox.textContent =
      state.lang === 'ar'
        ? 'اكتب بريدك الإلكتروني أولاً لاستعادة كلمة المرور.'
        : 'Enter your email above first to reset your password.';
    errBox.classList.remove('hidden');
    return;
  }
  try {
    await sendPasswordResetEmail(auth, email);
    infoBox.textContent =
      state.lang === 'ar'
        ? 'تم إرسال رابط إعادة تعيين كلمة المرور لبريدك.'
        : 'Password reset link sent to your inbox.';
    infoBox.classList.remove('hidden');
  } catch (err) {
    errBox.textContent = mapAuthError(err);
    errBox.classList.remove('hidden');
    showLoginRecoveryLinks(err && err.code ? String(err.code) : '');
  }
});

$('login-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errBox = $('login-error');
  const infoBox = $('login-info');
  errBox.classList.add('hidden');
  infoBox.classList.add('hidden');
  hideLoginRecoveryLinks();

  if (!firebaseReady || !auth) {
    errBox.textContent = 'Please host the site over HTTPS/HTTP (not file://) to sign in.';
    errBox.classList.remove('hidden');
    return;
  }

  const email = $('auth-email').value.trim().toLowerCase();
  const password = $('auth-password').value;
  const username = $('auth-username').value.trim().slice(0, 32);

  if (state.loginMode === 'signup' && username.length < 2) {
    errBox.textContent =
      state.lang === 'ar'
        ? 'اسم المستخدم يجب أن يكون حرفين على الأقل.'
        : 'Username must be at least 2 characters.';
    errBox.classList.remove('hidden');
    return;
  }

  try {
    let verificationPending = false;
    if (state.loginMode === 'signin') {
      const cred = await signInWithEmailAndPassword(auth, email, password);
      verificationPending = !cred.user.emailVerified;
    } else {
      const cred = await createUserWithEmailAndPassword(auth, email, password);
      try {
        localStorage.setItem(`onecity_pending_username_${cred.user.uid}`, username);
      } catch {
        // Ignore
      }
      try {
        await updateProfile(cred.user, { displayName: username });
        await cred.user.reload();
      } catch {
        // Non-fatal
      }
      try {
        await sendEmailVerification(cred.user);
      } catch {
        // Non-fatal
      }
      verificationPending = !cred.user.emailVerified;
    }
    $('login-modal').classList.add('hidden');
    setActiveView('news');
    showToast(
      verificationPending
        ? TRANSLATIONS[state.lang].verifyResentToast
        : TRANSLATIONS[state.lang].loginWelcomeToast,
    );
  } catch (err) {
    errBox.textContent = mapAuthError(err);
    errBox.classList.remove('hidden');
    showLoginRecoveryLinks(err && err.code ? String(err.code) : '');
  }
});

$('google-signin-btn').addEventListener('click', async () => {
  const errBox = $('login-error');
  const gBtn = $('google-signin-btn');
  const gLabel = gBtn.querySelector('span');
  errBox.classList.add('hidden');
  hideLoginRecoveryLinks();

  if (!firebaseReady || !auth || !googleProvider) {
    errBox.textContent = 'Please host the site over HTTPS/HTTP (not file://) to sign in with Google.';
    errBox.classList.remove('hidden');
    return;
  }

  gBtn.disabled = true;
  if (gLabel) gLabel.textContent = state.lang === 'ar' ? 'جاري الاتصال بـ Google...' : 'Connecting to Google...';

  try {
    await signInWithPopup(auth, googleProvider);
    $('login-modal').classList.add('hidden');
    setActiveView('news');
    showToast(TRANSLATIONS[state.lang].loginWelcomeToast);
  } catch (err) {
    console.error('Google Sign-In error:', err);
    const code = err && err.code ? String(err.code) : '';
    const insideFrame = isInsideIframe();
    const canUseRedirect = window.location.protocol.startsWith('http') && !insideFrame;
    if (
      (code === 'auth/popup-blocked' ||
        code === 'auth/operation-not-supported-in-this-environment' ||
        code === 'auth/internal-error' ||
        code === 'auth/cancelled-popup-request') &&
      canUseRedirect
    ) {
      try {
        await signInWithRedirect(auth, googleProvider);
        return;
      } catch (redirectErr) {
        const rCode = redirectErr && redirectErr.code ? String(redirectErr.code) : '';
        errBox.textContent = mapAuthError(redirectErr);
        errBox.classList.remove('hidden');
        showLoginRecoveryLinks(rCode);
        return;
      }
    }
    errBox.textContent = mapAuthError(err);
    errBox.classList.remove('hidden');
    showLoginRecoveryLinks(code);
  } finally {
    gBtn.disabled = false;
    if (gLabel) gLabel.textContent = state.lang === 'ar' ? 'المتابعة باستخدام Google' : 'Continue with Google';
  }
});

$('verify-resend-btn')?.addEventListener('click', async () => {
  if (!auth?.currentUser) return;
  try {
    await sendEmailVerification(auth.currentUser);
    showToast(TRANSLATIONS[state.lang].verifyResentToast);
  } catch (err) {
    showToast(err instanceof Error ? err.message : TRANSLATIONS[state.lang].fbSaveError);
  }
});

$('verify-refresh-btn')?.addEventListener('click', async () => {
  if (!auth?.currentUser) return;
  try {
    await auth.currentUser.reload();
    await auth.currentUser.getIdToken(true);
    state.user = auth.currentUser;
    updateAuthUI();
    if (auth.currentUser.emailVerified) {
      showToast(TRANSLATIONS[state.lang].verifyConfirmedToast);
    } else {
      showToast(TRANSLATIONS[state.lang].verifyStillPendingToast);
    }
  } catch (err) {
    showToast(err instanceof Error ? err.message : TRANSLATIONS[state.lang].fbSaveError);
  }
});

$('logout-btn').addEventListener('click', async () => {
  if (auth) await signOut(auth);
  closeAdminModal();
  setActiveView('home');
});

$('admin-open-btn').addEventListener('click', openAdminModal);
$('admin-close-btn').addEventListener('click', closeAdminModal);
document.querySelectorAll('#admin-tabs .admin-tab-btn').forEach((btn) => {
  btn.addEventListener('click', () => switchAdminTab(btn.dataset.adminTab));
});

$('cfg-site-name').addEventListener('input', (e) => {
  state.draftConfig.siteName = e.target.value;
});
$('cfg-site-subtitle').addEventListener('input', (e) => {
  state.draftConfig.siteSubtitle = e.target.value;
});
$('cfg-logo-url').addEventListener('input', (e) => {
  state.draftConfig.logoUrl = e.target.value;
  $('cfg-logo-preview').src = resolveLogoSrc(e.target.value);
});
$('cfg-logo-reset').addEventListener('click', () => {
  state.draftConfig.logoUrl = DEFAULT_LOGO_PATH;
  $('cfg-logo-url').value = DEFAULT_LOGO_PATH;
  $('cfg-logo-preview').src = DEFAULT_LOGO_PATH;
});
$('cfg-logo-upload').addEventListener('change', async (e) => {
  const file = e.target.files?.[0];
  if (!file) return;
  const t = TRANSLATIONS[state.lang];
  try {
    const uri = await compressImage(file);
    if (uri.length > 240000) {
      setAdminFeedback('error', t.fbImageTooLarge);
      return;
    }
    state.draftConfig.logoUrl = uri;
    $('cfg-logo-url').value = uri;
    $('cfg-logo-preview').src = uri;
    setAdminFeedback('success', t.fbImageReady);
  } catch {
    setAdminFeedback('error', t.fbImageTooLarge);
  }
});
$('cfg-neon-color').addEventListener('input', (e) => {
  state.draftConfig.neonColor = e.target.value;
});
$('cfg-add-welcome-btn').addEventListener('click', () => {
  if (state.draftConfig.welcomeMessages.length < 8) {
    state.draftConfig.welcomeMessages.push('');
    renderAdminBranding();
  }
});
$('cfg-add-btn').addEventListener('click', () => {
  if (state.draftConfig.buttons.length < 8) {
    state.draftConfig.buttons.push({
      id: `custom_${Date.now()}`,
      label: state.lang === 'en' ? 'New Link' : 'رابط جديد',
      url: '',
      icon: '🔗',
      enabled: true,
    });
    renderAdminLinks();
  }
});

async function saveSiteConfig(e) {
  e.preventDefault();
  if (!db || !state.user) return;
  const t = TRANSLATIONS[state.lang];
  const d = state.draftConfig;

  const cleanName = d.siteName.trim().slice(0, 60) || 'One City RP';
  const cleanSubtitle = d.siteSubtitle.trim().slice(0, 80);
  const cleanLogo = (d.logoUrl.trim() || DEFAULT_LOGO_PATH).slice(0, 250000);
  const cleanNeon = /^#[0-9a-fA-F]{6}$/.test(d.neonColor) ? d.neonColor : '#a855f7';
  const cleanMessages = d.welcomeMessages.map((m) => m.trim().slice(0, 160)).filter(Boolean).slice(0, 8);
  if (cleanMessages.length === 0) cleanMessages.push('مرحباً بكم في One City RP');

  const cleanButtons = d.buttons
    .map((b, i) => {
      const rawUrl = b.url.trim().slice(0, 500);
      const normalizedUrl = rawUrl
        ? /^https?:\/\//i.test(rawUrl)
          ? rawUrl
          : `https://${rawUrl}`
        : '';
      return {
        id: (b.id || `btn_${i + 1}`).replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 40) || `btn_${i + 1}`,
        label: b.label.trim().slice(0, 60) || 'Link',
        url: normalizedUrl.slice(0, 500),
        icon: (b.icon.trim() || '🔗').slice(0, 20),
        enabled: Boolean(b.enabled),
      };
    })
    .slice(0, 8);

  const ref = doc(db, 'site_config', 'main');
  try {
    if (!state.configExistsInDb) {
      await setDoc(ref, {
        siteName: cleanName,
        siteSubtitle: cleanSubtitle,
        logoUrl: cleanLogo,
        neonColor: cleanNeon,
        welcomeMessages: cleanMessages,
        buttons: cleanButtons,
        updatedAt: serverTimestamp(),
        updatedBy: state.user.uid,
      });
    } else {
      const payload = { updatedAt: serverTimestamp(), updatedBy: state.user.uid };
      if (state.permissions.isSuperAdmin || state.permissions.canEditBranding) {
        payload.siteName = cleanName;
        payload.siteSubtitle = cleanSubtitle;
        payload.logoUrl = cleanLogo;
        payload.neonColor = cleanNeon;
        payload.welcomeMessages = cleanMessages;
      }
      if (state.permissions.isSuperAdmin || state.permissions.canEditLinks) {
        payload.buttons = cleanButtons;
      }
      await updateDoc(ref, payload);
    }
    if (state.permissions.isSuperAdmin || state.permissions.canEditLinks) {
      state.draftConfig.buttons = cleanButtons;
      renderAdminLinks();
    }
    setAdminFeedback('success', t.fbConfigSaved);
  } catch (err) {
    console.error('Failed to save site_config/main:', err);
    setAdminFeedback('error', t.fbSaveError);
  }
}

$('admin-branding-form').addEventListener('submit', saveSiteConfig);
$('admin-links-form').addEventListener('submit', saveSiteConfig);

async function persistBotInfoToFirestore(successMsg) {
  if (!db || !state.user) return false;
  const t = TRANSLATIONS[state.lang];
  const cleanNews = state.draftBotInfo.news
    .filter((n) => n.title.trim() && n.content.trim())
    .map((n, i) => {
      const cleanImg = sanitizeNewsImageUrl((n.imageUrl || '').slice(0, 80000));
      const base = {
        id: (n.id || `news_${i + 1}`).replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 40) || `news_${i + 1}`,
        title: n.title.trim().slice(0, 80),
        content: n.content.trim().slice(0, 300),
        date: (n.date || new Date().toISOString().slice(0, 10)).trim().slice(0, 30),
      };
      if (cleanImg) base.imageUrl = cleanImg;
      return base;
    })
    .slice(0, 15);

  const cleanFactions = state.draftBotInfo.factions
    .filter((f) => f.name.trim())
    .map((f, i) => ({
      id: (f.id || `faction_${i + 1}`).replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 40) || `faction_${i + 1}`,
      name: f.name.trim().slice(0, 50),
      icon: (f.icon.trim() || '🛡️').slice(0, 16),
      status: ['مفتوح', 'مغلق', 'قريباً'].includes(f.status) ? f.status : 'مفتوح',
      description: f.description.trim().slice(0, 200),
    }))
    .slice(0, 12);

  const ref = doc(db, 'site_config', 'bot_info');
  try {
    if (!state.botInfoExistsInDb) {
      await setDoc(ref, {
        news: cleanNews,
        factions: cleanFactions,
        updatedAt: serverTimestamp(),
        updatedBy: state.user.uid,
      });
    } else {
      await updateDoc(ref, {
        news: cleanNews,
        factions: cleanFactions,
        updatedAt: serverTimestamp(),
        updatedBy: state.user.uid,
      });
    }
    state.draftBotInfo.news = cleanNews;
    state.draftBotInfo.factions = cleanFactions;
    renderAdminBot();
    setAdminFeedback('success', successMsg);
    return true;
  } catch (err) {
    console.error('Failed to save site_config/bot_info:', err);
    setAdminFeedback('error', t.fbSaveError);
    return false;
  }
}

$('new-news-image-url')?.addEventListener('input', (e) => {
  const val = e.target.value;
  const safe = sanitizeNewsImageUrl(val);
  const prev = $('new-news-image-preview');
  const clr = $('new-news-image-clear');
  if (prev) {
    prev.classList.toggle('hidden', !safe);
    if (safe) prev.src = safe;
  }
  if (clr) clr.classList.toggle('hidden', !val);
});

$('new-news-image-upload')?.addEventListener('change', async (e) => {
  const file = e.target.files?.[0];
  if (!file) return;
  const t = TRANSLATIONS[state.lang];
  try {
    const uri = await compressNewsImage(file);
    if (uri.length > 78000) {
      setAdminFeedback('error', t.fbImageTooLarge);
      return;
    }
    $('new-news-image-url').value = uri;
    $('new-news-image-preview').src = uri;
    $('new-news-image-preview').classList.remove('hidden');
    $('new-news-image-clear').classList.remove('hidden');
    setAdminFeedback('success', t.newsImageReady);
  } catch {
    setAdminFeedback('error', t.fbImageTooLarge);
  }
  e.target.value = '';
});

$('new-news-image-clear')?.addEventListener('click', () => {
  $('new-news-image-url').value = '';
  $('new-news-image-preview').classList.add('hidden');
  $('new-news-image-clear').classList.add('hidden');
});

$('add-news-quick-btn').addEventListener('click', async () => {
  const t = TRANSLATIONS[state.lang];
  const title = $('new-news-title').value.trim();
  const content = $('new-news-content').value.trim();
  const imgUrl = sanitizeNewsImageUrl(($('new-news-image-url')?.value || '').slice(0, 80000));
  if (!title || !content) {
    setAdminFeedback('error', t.fbNewsRequired);
    return;
  }
  const previousNews = [...state.draftBotInfo.news];
  state.draftBotInfo.news.unshift({
    id: `news_${Date.now()}`,
    title: title.slice(0, 80),
    content: content.slice(0, 300),
    date: new Date().toISOString().slice(0, 10),
    ...(imgUrl ? { imageUrl: imgUrl } : {}),
  });
  const ok = await persistBotInfoToFirestore(t.fbNewsQueued);
  if (ok) {
    $('new-news-title').value = '';
    $('new-news-content').value = '';
    if ($('new-news-image-url')) $('new-news-image-url').value = '';
    $('new-news-image-preview')?.classList.add('hidden');
    $('new-news-image-clear')?.classList.add('hidden');
  } else {
    state.draftBotInfo.news = previousNews;
  }
});

$('add-faction-btn').addEventListener('click', () => {
  if (state.draftBotInfo.factions.length < 12) {
    state.draftBotInfo.factions.push({
      id: `faction_${Date.now()}`,
      name: state.lang === 'en' ? 'New Faction' : 'فصيل جديد',
      icon: '🛡️',
      status: 'مفتوح',
      description: '',
    });
    renderAdminBot();
  }
});

$('admin-bot-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const t = TRANSLATIONS[state.lang];
  const pendingTitle = $('new-news-title').value.trim();
  const pendingContent = $('new-news-content').value.trim();
  const pendingImg = sanitizeNewsImageUrl(($('new-news-image-url')?.value || '').slice(0, 80000));
  if ((pendingTitle && !pendingContent) || (!pendingTitle && pendingContent)) {
    setAdminFeedback('error', t.fbNewsRequired);
    return;
  }
  const previousNews = [...state.draftBotInfo.news];
  if (pendingTitle && pendingContent) {
    state.draftBotInfo.news.unshift({
      id: `news_${Date.now()}`,
      title: pendingTitle.slice(0, 80),
      content: pendingContent.slice(0, 300),
      date: new Date().toISOString().slice(0, 10),
      ...(pendingImg ? { imageUrl: pendingImg } : {}),
    });
  }
  const ok = await persistBotInfoToFirestore(t.fbBotSaved);
  if (ok && pendingTitle && pendingContent) {
    $('new-news-title').value = '';
    $('new-news-content').value = '';
    if ($('new-news-image-url')) $('new-news-image-url').value = '';
    $('new-news-image-preview')?.classList.add('hidden');
    $('new-news-image-clear')?.classList.add('hidden');
  } else if (!ok) {
    state.draftBotInfo.news = previousNews;
  }
});

$('add-admin-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  if (!db || !state.user || !state.permissions.isSuperAdmin) return;
  const t = TRANSLATIONS[state.lang];
  const email = $('new-admin-email').value.trim().toLowerCase();
  if (!/^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$/.test(email)) {
    setAdminFeedback('error', t.fbInvalidEmail);
    return;
  }
  if (email === SUPER_ADMIN_EMAIL) return;

  const matched = state.usersList.find((u) => (u.email || '').toLowerCase() === email);
  const label = $('new-admin-name').value.trim().slice(0, 80) || (matched ? getMemberUsername(matched) : '');
  const ref = doc(db, 'admins', email);
  const exists = state.adminsList.some((a) => a.email === email);

  const data = {
    displayName: label,
    canEditBranding: $('new-can-branding').checked,
    canEditLinks: $('new-can-links').checked,
    canEditBot: $('new-can-bot').checked,
    addedBy: state.user.uid,
    updatedAt: serverTimestamp(),
  };

  if (exists) {
    await updateDoc(ref, data);
  } else {
    await setDoc(ref, { email, ...data, createdAt: serverTimestamp() });
  }
  $('new-admin-email').value = '';
  $('new-admin-name').value = '';
  setAdminFeedback('success', t.fbAdminGranted);
});

// Firestore Live Listeners + Auth
if (firebaseReady && db && auth) {
  getRedirectResult(auth)
    .then((res) => {
      if (res && res.user) {
        setActiveView('news');
        showToast(TRANSLATIONS[state.lang].loginWelcomeToast);
      }
    })
    .catch((err) => {
      console.warn('Redirect sign-in note:', err);
    });

  onSnapshot(doc(db, 'site_config', 'main'), (snap) => {
    if (snap.exists()) {
      const data = snap.data();
      state.configExistsInDb = true;
      state.siteConfig = {
        siteName: data.siteName || DEFAULT_SITE_CONFIG.siteName,
        siteSubtitle: data.siteSubtitle ?? DEFAULT_SITE_CONFIG.siteSubtitle,
        logoUrl: data.logoUrl || DEFAULT_SITE_CONFIG.logoUrl,
        neonColor: data.neonColor || DEFAULT_SITE_CONFIG.neonColor,
        welcomeMessages:
          Array.isArray(data.welcomeMessages) && data.welcomeMessages.length > 0
            ? data.welcomeMessages
            : DEFAULT_SITE_CONFIG.welcomeMessages,
        buttons:
          Array.isArray(data.buttons) && data.buttons.length > 0
            ? data.buttons
            : DEFAULT_SITE_CONFIG.buttons,
      };
      renderSite();
    }
  });

  onSnapshot(doc(db, 'site_config', 'bot_info'), (snap) => {
    if (snap.exists()) {
      const data = snap.data();
      state.botInfoExistsInDb = true;
      state.botInfo = {
        news: Array.isArray(data.news) ? data.news : DEFAULT_BOT_INFO.news,
        factions:
          Array.isArray(data.factions) && data.factions.length > 0
            ? data.factions
            : DEFAULT_BOT_INFO.factions,
      };
      if (state.activeView === 'news') renderNews();
      if (state.activeView === 'factions') renderFactions();
    }
  });

  let unsubRole = null;
  onAuthStateChanged(auth, async (fbUser) => {
    unsubRole?.();
    unsubRole = null;
    state.user = fbUser;

    if (!fbUser || !fbUser.email || !fbUser.emailVerified) {
      state.permissions = { ...NO_PERMS };
      updateAuthUI();
      return;
    }

    const lower = fbUser.email.toLowerCase();
    let pendingName = '';
    try {
      pendingName = (localStorage.getItem(`onecity_pending_username_${fbUser.uid}`) || '').trim();
    } catch {
      // Ignore
    }
    try {
      const uRef = doc(db, 'users', fbUser.uid);
      const uSnap = await getDoc(uRef);
      const prev = uSnap.exists() ? uSnap.data() : null;
      const username = (
        pendingName ||
        fbUser.displayName?.trim() ||
        prev?.username?.trim() ||
        lower.split('@')[0] ||
        'member'
      ).slice(0, 50);

      if (uSnap.exists()) {
        await updateDoc(uRef, {
          username,
          email: lower.slice(0, 128),
          displayName: (fbUser.displayName || username).slice(0, 100),
          photoURL: (fbUser.photoURL || '').slice(0, 500),
          lastLoginAt: serverTimestamp(),
        });
      } else {
        await setDoc(uRef, {
          uid: fbUser.uid,
          username,
          email: lower.slice(0, 128),
          displayName: (fbUser.displayName || username).slice(0, 100),
          photoURL: (fbUser.photoURL || '').slice(0, 500),
          createdAt: serverTimestamp(),
          lastLoginAt: serverTimestamp(),
        });
      }
      if (pendingName) {
        try {
          localStorage.removeItem(`onecity_pending_username_${fbUser.uid}`);
        } catch {
          // Ignore
        }
      }
    } catch (e) {
      console.warn('User profile sync skipped:', e);
    }

    if (lower === SUPER_ADMIN_EMAIL) {
      state.permissions = {
        isSuperAdmin: true,
        isAdmin: true,
        canEditBranding: true,
        canEditLinks: true,
        canEditBot: true,
        canManageAdmins: true,
      };
      updateAuthUI();
    } else {
      unsubRole = onSnapshot(doc(db, 'admins', lower), (snap) => {
        if (snap.exists()) {
          const d = snap.data();
          const any = Boolean(d.canEditBranding || d.canEditLinks || d.canEditBot);
          state.permissions = {
            isSuperAdmin: false,
            isAdmin: any,
            canEditBranding: Boolean(d.canEditBranding),
            canEditLinks: Boolean(d.canEditLinks),
            canEditBot: Boolean(d.canEditBot),
            canManageAdmins: false,
          };
        } else {
          state.permissions = { ...NO_PERMS };
        }
        updateAuthUI();
      });
    }
  });
}

// Standalone PWA Installation Controller (One City RP)
(function initStandalonePwa() {
  const INSTALLED_KEY = 'onecity_pwa_installed';
  const DISMISSED_KEY = 'onecity_pwa_prompt_dismissed_session';
  let deferredPrompt = null;

  const isStandalone =
    window.matchMedia('(display-mode: standalone)').matches ||
    window.navigator.standalone === true;
  const isIOS =
    /iPhone|iPad|iPod/i.test(navigator.userAgent) ||
    (navigator.platform === 'MacIntel' && (navigator.maxTouchPoints || 0) > 1);

  let isInstalled = isStandalone;
  let justInstalled = false;
  let sessionPortalOpened = false;
  let gateCancelled = false;

  if (!IS_LOCAL_FILE) {
    if (!isInstalled) {
      try {
        isInstalled = localStorage.getItem(INSTALLED_KEY) === 'true';
      } catch {
        isInstalled = false;
      }
    } else {
      try {
        localStorage.setItem(INSTALLED_KEY, 'true');
      } catch {
        // Ignore
      }
    }
  }

  const isAndroid = /Android/i.test(navigator.userAgent);
  const isInIframe = window.self !== window.top;
  let guidePlatform = isIOS ? 'iphone' : isAndroid ? 'android' : 'desktop';

  function shouldShowFullPortal() {
    if (IS_LOCAL_FILE) {
      return Boolean(sessionPortalOpened || state.user);
    }
    return Boolean(isStandalone || (isInstalled && !justInstalled) || sessionPortalOpened || state.user);
  }

  function showInstStage(stage) {
    $('inst-confirm-view')?.classList.toggle('hidden', stage !== 'confirm');
    $('inst-installing-view')?.classList.toggle('hidden', stage !== 'installing');
    $('inst-installed-view')?.classList.toggle('hidden', stage !== 'installed');
    $('inst-guide-view')?.classList.toggle('hidden', stage !== 'guide');
  }

  function renderGuideSteps() {
    const t = TRANSLATIONS[state.lang];
    const steps =
      guidePlatform === 'iphone'
        ? t.pwaIphoneSteps
        : guidePlatform === 'android'
          ? t.pwaAndroidSteps
          : t.pwaDesktopSteps;
    $('inst-tab-desktop')?.classList.toggle('active', guidePlatform === 'desktop');
    $('inst-tab-iphone')?.classList.toggle('active', guidePlatform === 'iphone');
    $('inst-tab-android')?.classList.toggle('active', guidePlatform === 'android');
    const openLink = $('inst-open-browser-link');
    if (openLink) {
      openLink.classList.toggle('hidden', !isInIframe || IS_LOCAL_FILE);
      openLink.href = window.location.href;
    }
    const list = $('inst-steps-list');
    if (!list) return;
    list.innerHTML = '';
    steps.forEach((step, idx) => {
      const li = document.createElement('li');
      const num = document.createElement('span');
      num.className = 'android-guide-num';
      num.textContent = String(idx + 1);
      const txt = document.createElement('span');
      txt.textContent = step;
      li.append(num, txt);
      list.appendChild(li);
    });
  }

  function syncPortalGate() {
    const showPortal = shouldShowFullPortal();
    $('portal-main')?.classList.toggle('hidden', !showPortal);
    $('site-footer')?.classList.toggle('hidden', !showPortal);
    $('installer-gate-main')?.classList.toggle('hidden', showPortal);
    $('pwa-install-btn')?.classList.toggle('hidden', !showPortal || isInstalled || IS_LOCAL_FILE);
    $('member-nav')?.classList.toggle('hidden', !showPortal || !(Boolean(state.user) || IS_LOCAL_FILE));
    document.querySelector('.top-header')?.classList.toggle('hidden', IS_LOCAL_FILE && !showPortal);

    if (!showPortal) {
      $('installer-reopen-btn')?.classList.toggle('hidden', !gateCancelled || justInstalled);
      $('android-installer-card')?.classList.toggle('hidden', gateCancelled && !justInstalled);
    }
  }

  syncPortalGateHook = syncPortalGate;

  function markInstalled(showOpenStep = false) {
    isInstalled = true;
    deferredPrompt = null;
    if (!IS_LOCAL_FILE) {
      try {
        localStorage.setItem(INSTALLED_KEY, 'true');
      } catch {
        // Ignore
      }
    }
    if (showOpenStep) {
      justInstalled = true;
      gateCancelled = false;
      showInstStage('installed');
    }
    syncPortalGate();
  }

  function openFullPortal() {
    sessionPortalOpened = true;
    justInstalled = false;
    gateCancelled = false;
    syncPortalGate();
  }

  function handleDoneAction() {
    if (justInstalled || isInstalled) {
      if (IS_LOCAL_FILE && !sessionPortalOpened) {
        justInstalled = false;
        gateCancelled = true;
        syncPortalGate();
      } else {
        openFullPortal();
      }
      return;
    }
    gateCancelled = true;
    syncPortalGate();
  }

  async function toDataUri(url) {
    const trimmed = String(url || '').trim();
    if (!trimmed || trimmed.startsWith('data:')) return trimmed;
    try {
      const res = await fetch(trimmed);
      if (!res.ok) return trimmed;
      const blob = await res.blob();
      return await new Promise((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(typeof reader.result === 'string' ? reader.result : trimmed);
        reader.onerror = () => resolve(trimmed);
        reader.readAsDataURL(blob);
      });
    } catch {
      return trimmed;
    }
  }

  function stripStandaloneModule(source) {
    const externalImports = [];
    let cleaned = source.replace(
      /^import\s+[\s\S]*?\s+from\s+['"](https?:\/\/[^'"]+)['"];?\s*$/gm,
      (full) => {
        externalImports.push(full.trim());
        return '';
      },
    );
    cleaned = cleaned.replace(/^import\s+[\s\S]*?\s+from\s+['"]\.\/[^'"]+['"];?\s*$/gm, '');
    cleaned = cleaned.replace(/^export\s+(?=(?:const|let|var|function|async\s+function)\b)/gm, '');
    return { externalImports, body: cleaned.trim() };
  }

  async function buildFullBundleHtml() {
    const base = window.location.pathname.includes('/standalone') ? '.' : '/standalone';
    const [htmlRes, cssRes, i18nRes, starRes, aiRes, appRes] = await Promise.all([
      fetch(`${base}/index.html`),
      fetch(`${base}/css/style.css`),
      fetch(`${base}/js/i18n.js`),
      fetch(`${base}/js/starfield.js`),
      fetch(`${base}/js/ai.js`),
      fetch(`${base}/js/app.js`),
    ]);
    if (!htmlRes.ok || !cssRes.ok || !i18nRes.ok || !starRes.ok || !aiRes.ok || !appRes.ok) {
      throw new Error('Template fetch failed');
    }
    const [tplHtml, tplCss, i18nJs, starJs, aiJs, appJs, embeddedLogo, embeddedIcon] = await Promise.all([
      htmlRes.text(),
      cssRes.text(),
      i18nRes.text(),
      starRes.text(),
      aiRes.text(),
      appRes.text(),
      toDataUri(resolveLogoSrc(state.siteConfig.logoUrl)),
      toDataUri(`${base}/assets/pwa-192x192.png`),
    ]);

    const safeJson = (val) => JSON.stringify(val, null, 2).replace(/<\//g, '<\\/');
    const liveConfig = {
      ...state.siteConfig,
      logoUrl: embeddedLogo || DEFAULT_LOGO_PATH,
    };
    const configCode = [
      `const FIREBASE_CONFIG = ${safeJson(FIREBASE_CONFIG)};`,
      `const SUPER_ADMIN_EMAIL = ${safeJson(SUPER_ADMIN_EMAIL)};`,
      `const AI_API_ENDPOINT = '';`,
      `const DEFAULT_LOGO_PATH = ${safeJson(embeddedLogo || DEFAULT_LOGO_PATH)};`,
      `const DEFAULT_SITE_CONFIG = ${safeJson(liveConfig)};`,
      `const DEFAULT_BOT_INFO = ${safeJson(state.botInfo)};`,
    ].join('\n');

    const pI18n = stripStandaloneModule(i18nJs);
    const pStar = stripStandaloneModule(starJs);
    const pAi = stripStandaloneModule(aiJs);
    const pApp = stripStandaloneModule(appJs);
    const imports = [
      ...pI18n.externalImports,
      ...pStar.externalImports,
      ...pAi.externalImports,
      ...pApp.externalImports,
    ].join('\n');

    const mergedScript = [imports, configCode, pI18n.body, pStar.body, pAi.body, pApp.body]
      .join('\n\n')
      .replace(/<\/script/gi, '<\\/script');
    const safeCss = tplCss.replace(/<\/style/gi, '<\\/style');
    const finalIcon = embeddedIcon || embeddedLogo || DEFAULT_LOGO_PATH;

    let out = tplHtml;
    out = out.replace(/<link\s+rel="manifest"[^>]*>/i, '');
    out = out.replace(/\.\/assets\/pwa-192x192\.png/g, finalIcon);
    out = out.replace(/\.\/assets\/apple-touch-icon\.png/g, finalIcon);
    out = out.replace(/\.\/assets\/pwa-512x512\.png/g, finalIcon);
    out = out.replace(/\.\/assets\/logo\.png/g, embeddedLogo || DEFAULT_LOGO_PATH);
    out = out.replace(
      /<link\s+rel="stylesheet"\s+href="\.\/css\/style\.css"\s*\/?>/i,
      () => `<style>\n${safeCss}\n</style>`,
    );
    out = out.replace(
      /<script\s+type="module"\s+src="\.\/js\/app\.js"><\/script>/i,
      () => `<script type="module">\n${mergedScript}\n</script>`,
    );
    return out;
  }

  async function downloadStandaloneAppDirect() {
    let html = '';
    try {
      html = await buildFullBundleHtml();
    } catch {
      const clone = document.documentElement.cloneNode(true);
      clone.querySelector('#login-modal')?.classList.add('hidden');
      clone.querySelector('#admin-modal')?.classList.add('hidden');
      html = '<!doctype html>\n' + clone.outerHTML;
    }
    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'One-City-RP.html';
    a.rel = 'noopener noreferrer';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 10000);
    showToast(TRANSLATIONS[state.lang].pwaDownloadedToast);
  }

  async function handleInstallTap() {
    if (IS_LOCAL_FILE) {
      showInstStage('installing');
      setTimeout(() => {
        markInstalled(true);
        showToast(TRANSLATIONS[state.lang].pwaInstalledToast);
      }, 700);
      return;
    }

    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      deferredPrompt = null;
      if (outcome === 'accepted') {
        markInstalled(true);
        showToast(TRANSLATIONS[state.lang].pwaInstalledToast);
      }
      return;
    }

    showInstStage('installing');
    try {
      await downloadStandaloneAppDirect();
    } finally {
      setTimeout(() => {
        markInstalled(true);
      }, 650);
    }
  }

  if ('serviceWorker' in navigator && window.location.protocol.startsWith('http')) {
    (async () => {
      const candidates = window.location.pathname.includes('/standalone')
        ? ['./sw.js']
        : ['/sw.js', '/dev-sw.js?dev-sw'];
      for (const swPath of candidates) {
        try {
          const probe = await fetch(swPath, { method: 'HEAD' });
          const ct = probe.headers.get('content-type') || '';
          if (probe.ok && /javascript|ecmascript/i.test(ct)) {
            await navigator.serviceWorker.register(
              swPath,
              swPath.includes('dev-sw') ? { type: 'module' } : undefined,
            );
            break;
          }
        } catch {
          // Try next SW endpoint
        }
      }
    })();
  }

  if (!IS_LOCAL_FILE && !isInstalled && 'getInstalledRelatedApps' in navigator) {
    try {
      navigator.getInstalledRelatedApps().then((apps) => {
        if (Array.isArray(apps) && apps.length > 0) {
          markInstalled(false);
        }
      }).catch(() => {});
    } catch {
      // Ignore
    }
  }

  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
  });

  window.addEventListener('appinstalled', () => {
    markInstalled(true);
    showToast(TRANSLATIONS[state.lang].pwaInstalledToast);
  });

  const syncOffline = () => {
    $('offline-banner')?.classList.toggle('hidden', navigator.onLine);
  };
  window.addEventListener('online', syncOffline);
  window.addEventListener('offline', syncOffline);
  syncOffline();

  $('pwa-install-btn')?.addEventListener('click', () => {
    if (deferredPrompt) {
      handleInstallTap();
    } else {
      sessionPortalOpened = false;
      gateCancelled = false;
      justInstalled = false;
      showInstStage('confirm');
      syncPortalGate();
    }
  });
  $('installer-reopen-btn')?.addEventListener('click', () => {
    gateCancelled = false;
    justInstalled = false;
    showInstStage('confirm');
    syncPortalGate();
  });
  $('inst-yes-btn')?.addEventListener('click', handleInstallTap);
  $('inst-cancel-btn')?.addEventListener('click', () => {
    gateCancelled = true;
    syncPortalGate();
  });
  $('inst-steps-toggle-btn')?.addEventListener('click', () => {
    renderGuideSteps();
    showInstStage('guide');
  });
  $('inst-open-btn')?.addEventListener('click', openFullPortal);
  $('inst-done-btn')?.addEventListener('click', handleDoneAction);
  $('inst-guide-open-btn')?.addEventListener('click', openFullPortal);
  $('inst-guide-done-btn')?.addEventListener('click', handleDoneAction);
  $('inst-tab-desktop')?.addEventListener('click', () => {
    guidePlatform = 'desktop';
    renderGuideSteps();
  });
  $('inst-tab-iphone')?.addEventListener('click', () => {
    guidePlatform = 'iphone';
    renderGuideSteps();
  });
  $('inst-tab-android')?.addEventListener('click', () => {
    guidePlatform = 'android';
    renderGuideSteps();
  });

  showInstStage('confirm');
  syncPortalGate();
})();

applyLanguage();
updateAuthUI();
