import 'dotenv/config';
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

interface ChatMessageInput {
  role: 'user' | 'model';
  text: string;
}

interface NewsContextInput {
  title: string;
  content: string;
  date?: string;
}

interface FactionContextInput {
  name: string;
  status: string;
  description?: string;
}

interface LinkContextInput {
  label: string;
  url: string;
  icon?: string;
}

let primaryCooldownUntil = 0;

function isRateLimitError(error: unknown): boolean {
  const msg = error instanceof Error ? error.message : String(error);
  return msg.includes('429') || msg.includes('RESOURCE_EXHAUSTED') || msg.includes('Quota exceeded');
}

async function startServer() {
  const app = express();
  const port = Number(process.env.PORT) || 3000;

  app.use(express.json({ limit: '1mb' }));

  app.post('/api/ai/chat', async (req, res) => {
    try {
      const { message, history, siteName, botContext } = req.body as {
        message?: unknown;
        history?: unknown;
        siteName?: unknown;
        botContext?: {
          news?: unknown;
          factions?: unknown;
          links?: unknown;
        };
      };

      if (typeof message !== 'string' || message.trim().length === 0) {
        return res.status(400).json({ error: 'يرجى كتابة رسالة صالحة.' });
      }

      if (message.trim().length > 2000) {
        return res.status(400).json({ error: 'الرسالة طويلة جداً (الحد الأقصى 2000 حرف).' });
      }

      if (!process.env.GEMINI_API_KEY) {
        return res.status(500).json({
          error: 'مفتاح Gemini API غير مضبوط في إعدادات الخادم (Secrets).',
        });
      }

      const safeSiteName =
        typeof siteName === 'string' && siteName.trim().length > 0
          ? siteName.trim().slice(0, 60)
          : 'One City RP';

      const cleanHistory: ChatMessageInput[] = Array.isArray(history)
        ? history
            .filter(
              (item): item is ChatMessageInput =>
                Boolean(item) &&
                (item.role === 'user' || item.role === 'model') &&
                typeof item.text === 'string' &&
                item.text.trim().length > 0,
            )
            .slice(-10)
        : [];

      // Ensure conversation contents start with a user turn when possible
      while (cleanHistory.length > 0 && cleanHistory[0].role !== 'user') {
        cleanHistory.shift();
      }

      const safeNews: NewsContextInput[] = Array.isArray(botContext?.news)
        ? (botContext.news as NewsContextInput[])
            .filter((n) => n && typeof n.title === 'string' && typeof n.content === 'string')
            .slice(0, 15)
        : [];

      const safeFactions: FactionContextInput[] = Array.isArray(botContext?.factions)
        ? (botContext.factions as FactionContextInput[])
            .filter((f) => f && typeof f.name === 'string' && typeof f.status === 'string')
            .slice(0, 12)
        : [];

      const safeLinks: LinkContextInput[] = Array.isArray(botContext?.links)
        ? (botContext.links as LinkContextInput[])
            .filter(
              (l) =>
                l &&
                typeof l.label === 'string' &&
                typeof l.url === 'string' &&
                l.url.trim().length > 0,
            )
            .slice(0, 8)
        : [];

      const newsSummary =
        safeNews.length > 0
          ? safeNews
              .map((n, i) => `${i + 1}. [${n.date || 'تحديث'}] ${n.title}: ${n.content}`)
              .join('\n')
          : 'لا توجد أخبار منشورة حالياً.';

      const factionsSummary =
        safeFactions.length > 0
          ? safeFactions
              .map(
                (f, i) =>
                  `${i + 1}. ${f.name} (الحالة: ${f.status})${
                    f.description ? ` — ${f.description}` : ''
                  }`,
              )
              .join('\n')
          : 'الشرطة، الطب، الجيش';

      const linksSummary =
        safeLinks.length > 0
          ? safeLinks
              .map((l) => `- ${l.label.slice(0, 60)}: ${l.url.slice(0, 500)}`)
              .join('\n')
          : '- سيرفر ديسكورد: https://discord.gg/aUzckMe3qY\n- حساب تيك توك: https://www.tiktok.com/@onecityrp8?_r=1&_t=ZS-9BZOJHD47RV';

      const contents = [
        ...cleanHistory.map((item) => ({
          role: item.role,
          parts: [{ text: item.text.slice(0, 2000) }],
        })),
        {
          role: 'user' as const,
          parts: [{ text: message.trim() }],
        },
      ];

      const systemInstruction = `أنت المساعد الذكي داخل موقع "${safeSiteName}".
أجب على أي سؤال يطرحه المستخدم بنفس لغته (العربية أو الإنجليزية) بوضوح ولطف.

معلومات "${safeSiteName}" الرسمية:
- الاسم الرسمي الوحيد للمجتمع والسيرفر هو: "${safeSiteName}".
- الروابط الرسمية الحالية في الموقع:
${linksSummary}

آخر الأخبار والتحديثات:
${newsSummary}

الفصائل المتاحة:
${factionsSummary}

قواعد صارمة جداً (يجب الالتزام بها دائماً):
1. ممنوع منعاً باتاً ذكر أو ربط "${safeSiteName}" بلعبة GTA أو FiveM أو SA-MP أو MTA أو RedM أو أي لعبة أخرى عند الحديث عن "${safeSiteName}"! إذا سأل المستخدم عن "${safeSiteName}" أو ماهيته أو طريقة الدخول، عرّفه فقط باسم "${safeSiteName}" واذكر الروابط الرسمية والفصائل والأخبار المتوفرة أعلاه دون الإشارة إلى أي لعبة خارجية نهائياً.
2. إذا طلب المستخدم الروابط (ديسكورد، تيك توك، روابط الموقع)، أرسله الروابط الرسمية المحدّثة المذكورة أعلاه بدقة.
3. ممنوع ذكر أو اختراع أي أسماء شخصية حقيقية.`;

      let response;
      const now = Date.now();
      if (now < primaryCooldownUntil) {
        response = await ai.models.generateContent({
          model: 'gemini-3.1-flash-lite',
          contents,
          config: { systemInstruction },
        });
      } else {
        try {
          response = await ai.models.generateContent({
            model: 'gemini-4-hydrogen',
            contents,
            config: { systemInstruction },
          });
        } catch (primaryError) {
          if (isRateLimitError(primaryError)) {
            primaryCooldownUntil = Date.now() + 10 * 60 * 1000;
          }
          response = await ai.models.generateContent({
            model: 'gemini-3.1-flash-lite',
            contents,
            config: { systemInstruction },
          });
        }
      }

      const replyText = response.text?.trim();
      if (!replyText) {
        return res.status(502).json({ error: 'لم يرد نموذج الذكاء الاصطناعي بنص صالح.' });
      }

      return res.json({ reply: replyText });
    } catch (error) {
      const rawMsg = error instanceof Error ? error.message : String(error);
      console.error('Gemini API Error:', rawMsg);

      if (isRateLimitError(error)) {
        return res.status(429).json({
          error:
            'تم استهلاك الحد اليومي المجاني لطلبات الذكاء الاصطناعي (Quota exceeded). يمكنك تفعيل مفتاح مدفوع من Settings > Secrets لزيادة الحد أو المحاولة لاحقاً.',
        });
      }

      if (rawMsg.includes('PERMISSION_DENIED') || rawMsg.includes('API_KEY_INVALID')) {
        return res.status(403).json({
          error:
            'تعذر التحقق من مفتاح Gemini API. يرجى التأكد من صحة المفتاح في Settings > Secrets.',
        });
      }

      return res.status(500).json({
        error: 'حدث خطأ مؤقت أثناء الاتصال بالذكاء الاصطناعي. يرجى المحاولة مرة أخرى.',
      });
    }
  });

  app.use((req, res, next) => {
    if (req.path === '/standalone') {
      return res.redirect(301, '/standalone/');
    }
    return next();
  });

  if (process.env.NODE_ENV !== 'production') {
    app.get('/standalone/', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'public', 'standalone', 'index.html'));
    });
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('/standalone/', (_req, res) => {
      res.sendFile(path.join(distDir, 'standalone', 'index.html'));
    });
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${port}`);
  });
}

void startServer();
